# 수정사항

1. AdminOrdersPage, AdminStatsPage 삭제
