// src/routes/AdminRoute.jsx
import { Navigate, Outlet, useLocation } from "react-router-dom";
import toast from "react-hot-toast";

import useAuthStore from "@/stores/authStore";

// ✅ 다양한 role 포맷 대응
function getRole(user) {
  if (!user) return "GUEST";

  const raw = user.role ?? user.roles ?? user.authorities;

  if (typeof raw === "string") {
    if (raw === "ROLE_ADMIN") return "ADMIN";
    if (raw === "ADMIN") return "ADMIN";
    return raw;
  }

  if (Array.isArray(raw)) {
    if (raw.includes("ADMIN") || raw.includes("ROLE_ADMIN")) return "ADMIN";
    return raw[0] ?? "USER";
  }

  if (Array.isArray(user.authorities)) {
    const arr = user.authorities.map((a) => a?.authority).filter(Boolean);
    if (arr.includes("ROLE_ADMIN") || arr.includes("ADMIN")) return "ADMIN";
    return arr[0] ?? "USER";
  }

  return "USER";
}

/**
 * ✅ toast가 라우트 가드 리렌더에서 반복 호출되는 걸 막기 위한 유틸 (추가)
 * - location.key 기준으로 "해당 네비게이션에서 한 번만" 뜨게
 */
function toastOnce(key, msg) {
  const id = `adminroute:${key}:${msg}`;
  if (toast.isActive(id)) return;
  toast.error(msg, { id });
}

export default function AdminRoute() {
  const location = useLocation();
  const { isAuthenticated, user, isInitializing, isAdmin } = useAuthStore();

  // ✅ initialize 끝날 때까지 대기 (화면 깜빡임 방지)
  if (isInitializing) return null;

  // ✅ 로그인 안 됨
  if (!isAuthenticated) {
    toastOnce(location.key, "로그인이 필요합니다.");
    return <Navigate to="/login" replace state={{ from: location.pathname }} />;
  }

  // ✅ 관리자 체크
  // - authStore에 isAdmin이 있으면 그걸 우선 사용
  // - 없거나 false면 role 파싱으로 fallback
  const role = getRole(user);
  const computedIsAdmin = Boolean(isAdmin) || role === "ADMIN";

  if (!computedIsAdmin) {
    toastOnce(location.key, "관리자만 접근할 수 있습니다.");
    return <Navigate to="/bogam" replace />;
  }

  return <Outlet />;
}