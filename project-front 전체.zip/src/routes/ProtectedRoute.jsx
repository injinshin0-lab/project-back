import { Navigate, Outlet, useLocation } from "react-router-dom";
import useAuthStore from "@/stores/authStore";

export default function ProtectedRoute({ children }) {
  const { isAuthenticated, isInitializing } = useAuthStore();
  const location = useLocation();

  // 🔹 로그인 복원 중에는 아무것도 렌더링하지 않음
  if (isInitializing) return null;

  // 🔹 로그인 안 됐으면 로그인 페이지로
  if (!isAuthenticated) {
    return (
      <Navigate
        to="/login"
        replace
        state={{ from: location.pathname }}
      />
    );
  }

  return children ? children : <Outlet />;
}