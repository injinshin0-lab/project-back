/**
 * @typedef {Object} LoginRequest
 * @property {string} email
 * @property {string} password
 */

/**
 * @typedef {Object} User
 * @property {number} [id]
 * @property {string} email
 */

/**
 * @typedef {Object} LoginResponse
 * @property {string} accessToken
 * @property {User} user
 */
export {};