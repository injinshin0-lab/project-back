// src/App.jsx
import { useEffect, useRef } from "react";
import AppRouter from "@/routes/AppRouter";
import useAuthStore from "@/stores/authStore";

export default function App() {
  const initialize = useAuthStore((s) => s.initialize);
  const ranRef = useRef(false);

  useEffect(() => {
    if (ranRef.current) return;
    ranRef.current = true;

    initialize().catch((e) => {
      console.error("[App] initialize error:", e);
    });
  }, [initialize]);
  return <AppRouter />;
}