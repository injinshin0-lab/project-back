// src/hooks/useRecentViewTracker.js
import { useEffect, useRef } from "react";
import useAuthStore from "@/stores/authStore";
import { addRecentViewApi } from "@/api/recentViewApi";

/**
 * 상품 상세 진입 시 "최근 본 상품" 기록
 * - 로그인 상태일 때만 기록
 * - StrictMode(개발) 2번 호출 방지: ref로 1회만 처리
 */
export default function useRecentViewTracker(productId) {
  const { isAuthenticated, user } = useAuthStore();
  const userId = user?.id ?? user?.userId ?? user?.memberId ?? user?.uid;
  console.log("최근본상품 등록 유저ID:", userId); // 이게 undefined면 API 호출 자체가 실패함
  const doneRef = useRef(false);

  useEffect(() => {
    if (doneRef.current) return;
    if (!isAuthenticated) return;
    if (!userId) return;
    if (!productId) return;

    doneRef.current = true;

    // 최근 본 기록
    addRecentViewApi(userId, productId).catch(() => {
      // 최근 본 실패는 UX에 치명적이지 않으니 조용히 무시
    });
  }, [isAuthenticated, userId, productId]);
}