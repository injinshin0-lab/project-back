import { useState, useCallback } from "react";

export default function useApi(apiFunc) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const run = useCallback(
    async (...args) => {
      setLoading(true);
      setError(null);
      try {
        const res = await apiFunc(...args);
        return res;
      } catch (e) {
        const msg = e?.response?.data?.message || e?.message || "요청 실패";
        setError(msg);
        throw e;
      } finally {
        setLoading(false);
      }
    },
    [apiFunc]
  );

  return { run, loading, error };
}