// src/api/orderApi.js
import axiosInstance from "@/api/axiosInstance";

/**
 * 주문 생성
 * (가정) POST /api/v1/orders
 * payload 예:
 * {
 *   items: [{ productId, quantity, cartId? }],
 *   postcode, address1, address2,
 *   memo
 * }
 */
// export const createOrderApi = (payload) => axiosInstance.post("/orders", payload);
export async function createOrderApi(payload) {
  const { data } = await axiosInstance.post("/orders", payload);
  return data;
}

/**
 * 마이페이지 주문 내역 조회
 * GET /api/v1/mypage/orders
 */
export async function getMyOrdersApi(params = {}) {
  const { page = 1, size = 10 } = params;

  const { data } = await axiosInstance.get("/mypage/orders", {
    params: { page, size },
  });

  return data;
}

/**
 * ✅ (마이페이지) 내 주문 내역 조회
 * GET /api/v1/users/orders/user/{userId}
 * params 예: { page, size, sort }
 */
export const getUserOrdersApi = (userId, params = {}) =>
  axiosInstance.get(`/users/orders/user/${userId}`, { params });

/**
 * 마이페이지 주문 상세 조회
 * GET /api/v1/mypage/orders/{orderId}
 */
export async function getMyOrderDetailApi(orderId) {
  if (!orderId) throw new Error("orderId is required");

  const { data } = await axiosInstance.get(
    `/mypage/orders/${orderId}`
  );

  return data;
}

/**
 * ✅ 주문 상세 조회 (백엔드에 있으면 사용)
 * GET /api/v1/orders/{orderId}
 */
export const getOrderDetailApi = (orderId) =>
  axiosInstance.get(`/orders/${orderId}`);

/**
 * 주문 취소 / 교환 / 반품 신청
 * POST /api/v1/mypage/orders/{orderId}/cancellation
 */
export async function createOrderCancellationApi(orderId, payload) {
  if (!orderId) throw new Error("orderId is required");

  const { data } = await axiosInstance.post(
    `/mypage/orders/${orderId}/cancellation`,
    payload
  );

  return data;
}