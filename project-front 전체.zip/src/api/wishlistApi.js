// src/api/wishlistApi.js
import axiosInstance from "@/api/axiosInstance";

/**
 * 찜 목록 조회
 * GET /api/v1/wishlist
 */
export const getWishlistApi = () => axiosInstance.get("/wishlist");

/**
 * 찜 추가
 * POST /api/v1/wishlist/{productId}
 */
export const addWishlistApi = (productId) =>
  axiosInstance.post(`/wishlist/${productId}`);

/**
 * 찜 삭제
 * DELETE /api/v1/wishlist/{productId}
 */
export const deleteWishlistApi = (productId) =>
  axiosInstance.delete(`/wishlist/${productId}`);