// src/api/reviewApi.js
import axiosInstance from "@/api/axiosInstance";

/**
 * 상품 리뷰 목록 조회
 * GET /api/v1/products/{productId}/reviews
 *
 * @param {string|number} productId
 * @param {object} params
 * @param {"latest"|"rating_desc"|"rating_asc"} params.sort
 * @param {boolean} params.photoOnly
 * @param {number} params.page   // 백엔드가 0-based라면 그대로 사용
 * @param {number} params.size
 */
export const getProductReviewsApi = (productId, params = {}) => {
  const {
    sort = "latest",
    photoOnly = false,
    page = 0,
    size = 10,
  } = params;

  return axiosInstance.get(`/products/${productId}/reviews`, {
    params: {
      sort,
      photoOnly,
      page,
      size,
    },
  });
};

/**
 * 상품 리뷰 작성 (회원)
 * POST /api/v1/products/{productId}/reviews
 * multipart/form-data
 *
 * @param {string|number} productId
 * @param {FormData} formData
 */
export const createProductReviewApi = (productId, formData) =>
  axiosInstance.post(
    `/products/${productId}/reviews`,
    formData,
    {
      headers: { "Content-Type": "multipart/form-data" },
    }
  );

/**
 * 상품 리뷰 수정 (본인)
 * PUT /api/v1/products/{productId}/reviews/{reviewId}
 *
 * @param {string|number} productId
 * @param {string|number} reviewId
 * @param {{ rating:number, content:string }} payload
 */
export const updateProductReviewApi = (productId, reviewId, payload) =>
  axiosInstance.put(
    `/products/${productId}/reviews/${reviewId}`,
    payload
  );

/**
 * 상품 리뷰 삭제 (본인)
 * DELETE /api/v1/products/{productId}/reviews/{reviewId}
 *
 * @param {string|number} productId
 * @param {string|number} reviewId
 */
export const deleteProductReviewApi = (productId, reviewId) =>
  axiosInstance.delete(
    `/products/${productId}/reviews/${reviewId}`
  );