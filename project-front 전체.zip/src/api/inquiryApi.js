// src/api/inquiryApi.js
import axiosInstance from "@/api/axiosInstance";

/*
 * 1:1 문의 조회(관리자)
 * GET /api/v1/admin/inquiries
 * params: { page, size, keyword, status ... } (백엔드 DTO에 맞게)
 */
export const getAdminInquiriesApi = (params = {}) =>
  axiosInstance.get("/admin/inquiries", { params });

/**
 * 1:1 문의 답변 등록/수정(관리자)
 * PATCH /api/v1/admin/inquiries/{inquiriesId}/reply
 * body: { content } 또는 { replyContent } 등 (DTO에 맞게)
 */
export const replyAdminInquiryApi = (inquiriesId, payload) =>
  axiosInstance.patch(`/admin/inquiries/${inquiriesId}/reply`, payload);