// src/api/productApi.js
import axiosInstance from "@/api/axiosInstance";

/**
 * 상품 목록 조회
 * 예상: GET /api/v1/products
 * params: { page, size, keyword, sort, order, categoryId }
 */
export async function getProductsApi(params = {}) {
  const { data } = await axiosInstance.get("/products", { params });
  return data;
}

/**
 * 상품 상세 조회
 * 예상: GET /api/v1/products/:productId
 */
export async function getProductDetailApi(productId) {
  const { data } = await axiosInstance.get(`/products/${productId}`);
  return data;
}