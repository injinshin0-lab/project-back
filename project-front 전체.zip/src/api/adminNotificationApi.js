// src/api/adminNotificationApi.js
import axiosInstance from "@/api/axiosInstance";

/**
 * 관리자 알림 발송
 * POST /api/v1/admin/notifications/send
 *
 * body 예시(프론트 제안 payload):
 * {
 *   targetType: "ALL" | "GROUP" | "USER",
 *   userIds?: number[],
 *   groupKey?: string,   // 예: "CATEGORY:15" or "ROLE:USER"
 *   title?: string,
 *   message: string
 * }
 *
 * ⚠️ 실제 백엔드 Request DTO 필드명은 다를 수 있으니,
 * 네트워크로 DTO 보고 맞춰주면 됨.
 */
export const sendAdminNotificationApi = (payload) =>
  axiosInstance.post("/admin/notifications/send", payload);