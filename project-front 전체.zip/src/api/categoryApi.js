// src/api/categoryApi.js
import axiosInstance from "@/api/axiosInstance";

// 카테고리 목록
// 예상: GET /api/v1/categories
export const getCategoriesApi = () => axiosInstance.get("/categories");