// src/api/authApi.js
import axiosInstance from "@/api/axiosInstance";

// ✅ 로그인: 백엔드가 loginId를 요구할 수 있고 userId를 요구할 수도 있어서 둘 다 보냄
export const loginApi = ({ loginId, password }) =>
  axiosInstance.post("/auth/login", {
    loginId,          // ✅ 서버가 loginId를 필수로 보는 경우 대응
    userId: loginId,  // ✅ 서버가 userId로 받는 경우 대응(호환)
    password,
  });

// ✅ 회원가입 (프로젝트에서 registerApi 사용한다고 했으니 유지)
export const registerApi = (payload) =>
  axiosInstance.post("/auth/register", payload);

// ✅ 자동 로그인 (너 백엔드 기준 /auth/auto-login)
export const meApi = () =>
  axiosInstance.post("/auth/auto-login");

// ✅ 로그아웃
export const logoutApi = () =>
  axiosInstance.post("/auth/logout");

// ✅ 이메일 인증
export const sendEmailCodeApi = (email) =>
  axiosInstance.post("/auth/email/send-code", { email });

export const verifyEmailCodeApi = ({ email, code }) =>
  axiosInstance.post("/auth/email/verify-code", { 
    email, 
    authCode : code 
  });

// ✅ 아이디 중복체크 (너가 정리한대로 RequestBody로 loginId)
export const checkLoginIdApi = (loginId) =>
  axiosInstance.post("/auth/check-username", { loginId });