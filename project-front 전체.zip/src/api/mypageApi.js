// src/api/mypageApi.js
import axiosInstance from "@/api/axiosInstance";

/**
 * [회원]
 * 비밀번호 변경
 * PATCH /api/v1/users/{userId}/password-change
 */
export const changePasswordApi = (userId, payload) =>
  axiosInstance.patch(`/users/${userId}/password-change`, payload);

/**
 * [회원]
 * 회원 정보 수정 (비밀번호 제외)
 * PATCH /api/v1/users/{userId}
 */
export const updateMyInfoApi = (userId, payload) =>
  axiosInstance.patch(`/users/${userId}`, payload);

/**
 * [회원]
 * 회원 탈퇴
 * POST /api/v1/users/{userId}/delete
 */
export const deleteAccountApi = (userId, payload = {}) =>
  axiosInstance.post(`/users/${userId}/delete`, payload);

/**
 * [회원]
 * 내가 쓴 리뷰
 * GET /api/v1/users/{userId}/reviews
 */
export const getMyReviewsApi = (userId, params = {}) =>
  axiosInstance.get(`/users/${userId}/reviews`, { params });

/**
 * [회원]
 * 주소록(배송지) 목록 조회
 * GET /api/v1/users/{userId}/addresses
 */
export const getAddressesApi = (userId) =>
  axiosInstance.get(`/users/${userId}/addresses`);

/**
 * [회원]
 * 주소록(배송지) 추가
 * POST /api/v1/users/{userId}/addresses
 */
export const createAddressApi = (userId, payload) =>
  axiosInstance.post(`/users/${userId}/addresses`, payload);

/**
 * [회원]
 * 주소록(배송지) 수정
 * PATCH /api/v1/users/{userId}/addresses/{id}
 */
export const updateAddressApi = (userId, addressId, payload) =>
  axiosInstance.patch(`/users/${userId}/addresses/${addressId}`, payload);

/**
 * [회원]
 * 주소록(배송지) 삭제
 * DELETE /api/v1/users/{userId}/addresses/{id}
 */
export const deleteAddressApi = (userId, addressId) =>
  axiosInstance.delete(`/users/${userId}/addresses/${addressId}`);

/**
 * [회원]
 * 알림 설정
 * PUT /api/v1/users/settings/{userId}
 */
export const updateNotificationSettingsApi = (userId, payload) =>
  axiosInstance.put(`/users/settings/${userId}`, payload);

/**
 * [회원]
 * 알림 목록 조회
 * GET /api/v1/users/notifications/user/{userId}
 */
export const getNotificationsApi = (userId, params = {}) =>
  axiosInstance.get(`/users/notifications/user/${userId}`, { params });

/**
 * [회원]
 * 알림 읽음 처리
 * PATCH /api/v1/users/notifications/{notificationsId}/read
 */
export const readNotificationApi = (notificationId) =>
  axiosInstance.patch(`/users/notifications/${notificationId}/read`);

/**
 * [회원]
 * 알림 전체 읽음 처리
 * PATCH /api/v1/users/notifications/user/{userId}/read-all
 */
export const readAllNotificationsApi = (userId) =>
  axiosInstance.patch(`/users/notifications/user/${userId}/read-all`);

/**
 * [회원]
 * 알림 삭제
 * DELETE /api/v1/users/notifications/{notificationsId}
 */
export const deleteNotificationApi = (notificationId) =>
  axiosInstance.delete(`/users/notifications/${notificationId}`);

/**
 * [회원]
 * 주문 내역 조회
 * GET /api/v1/users/orders/user/{userId}
 */
export const getMyOrdersByUserApi = (userId, params = {}) =>
  axiosInstance.get(`/users/orders/user/${userId}`, { params });