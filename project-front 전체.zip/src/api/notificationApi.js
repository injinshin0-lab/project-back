// src/api/notificationApi.js
import axiosInstance from "@/api/axiosInstance";

/**
 * 유저 알림 목록 조회
 * GET /api/v1/users/notifications/user/{userId}
 * params: { page, size } (백엔드가 지원하면)
 */
export const getUserNotificationsApi = (userId, params = {}) =>
  axiosInstance.get(`/users/notifications/user/${userId}`, { params });

/**
 * 유저 알림 단건 읽음 처리
 * PATCH /api/v1/users/notifications/user/{userId}/read
 * body: { notificationsId } (백엔드 DTO 키에 맞춰 조정)
 */
export const readUserNotificationApi = (userId, payload) =>
  axiosInstance.patch(`/users/notifications/user/${userId}/read`, payload);

/**
 * 유저 알림 전체 읽음 처리
 * PATCH /api/v1/users/notifications/user/{userId}/read-all
 */
export const readAllUserNotificationsApi = (userId) =>
  axiosInstance.patch(`/users/notifications/user/${userId}/read-all`);

/**
 * 유저 알림 삭제
 * DELETE /api/v1/users/notifications/{notificationsId}
 */
export const deleteUserNotificationApi = (notificationsId) =>
  axiosInstance.delete(`/users/notifications/${notificationsId}`);

/**
 * 유저 알림 설정 저장
 * PUT /api/v1/users/settings/{userId}/notifications
 * body 예시: { enabled: true } 또는 { isEnabled: true } 등
 */
export const updateUserNotificationSettingsApi = (userId, payload) =>
  axiosInstance.put(`/users/settings/${userId}/notifications`, payload);