// src/api/paymentApi.js
import axiosInstance from "@/api/axiosInstance";

/**
 * 결제 준비(가정)
 * POST /api/v1/payments/ready
 * payload: { orderId, amount }
 * 응답 예: { redirectUrl } or { paymentId }
 */
export const readyPaymentApi = (payload) =>
  axiosInstance.post("/payments/ready", payload);

/**
 * 결제 확정(가정)
 * POST /api/v1/payments/confirm
 * payload: { orderId, paymentId }
 */
export const confirmPaymentApi = (payload) =>
  axiosInstance.post("/payments/confirm", payload);