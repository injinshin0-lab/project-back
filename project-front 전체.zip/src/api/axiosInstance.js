// src/api/axiosInstance.js
import axios from "axios";
import toast from "react-hot-toast";

const axiosInstance = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL || "http://localhost:8080/api/v1",
  timeout: 15000,

  // ✅ 세션/쿠키 기반이면 필수 (로그인 쿠키, JSESSIONID 등)
  withCredentials: true,

  headers: {
    "Content-Type": "application/json",
  },
});

// -------------------------
// logging (원하면 유지)
// -------------------------
axiosInstance.interceptors.request.use(
  (config) => {
    const url = `${config.baseURL}${config.url}`;
    console.log("[REQ]", config.method?.toUpperCase(), url);
    if (config.data) console.log("[REQ DATA]", config.data);
    return config;
  },
  (error) => Promise.reject(error)
);

// -------------------------
// response handling
// -------------------------
axiosInstance.interceptors.response.use(
  (res) => res,
  (error) => {
    const status = error?.response?.status;
    const url = error?.config?.url ?? "";

    // ✅ auth 계열은 조용히 (너가 이미 그렇게 정리했었지)
    const isAuthEndpoint =
      url.includes("/auth/login") ||
      url.includes("/auth/register") ||
      url.includes("/auth/auto-login") ||
      url.includes("/auth/email");

    if (!isAuthEndpoint) {
      if (status >= 500) toast.error("서버 오류가 발생했습니다.");
    }

    return Promise.reject(error);
  }
);

export default axiosInstance;