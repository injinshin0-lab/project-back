// src/api/faqApi.js
import axiosInstance from "@/api/axiosInstance";

/**
 * FAQ 조회 (관리자)
 * GET /api/v1/admin/faqs
 * params: { page, size, keyword } 등 (백엔드에 맞게 유연하게)
 */
export const getAdminFaqsApi = (params = {}) =>
  axiosInstance.get("/admin/faqs", { params });

/**
 * FAQ 추가
 * POST /api/v1/admin/faqs
 * body: { title, content, category? ... } (프로젝트 DTO에 맞게)
 */
export const createAdminFaqApi = (payload) =>
  axiosInstance.post("/admin/faqs", payload);

/**
 * FAQ 수정
 * PUT /api/v1/admin/faqs/{faqId}
 */
export const updateAdminFaqApi = (faqId, payload) =>
  axiosInstance.put(`/admin/faqs/${faqId}`, payload);

/**
 * FAQ 삭제
 * DELETE /api/v1/admin/faqs/{faqId}
 */
export const deleteAdminFaqApi = (faqId) =>
  axiosInstance.delete(`/admin/faqs/${faqId}`);