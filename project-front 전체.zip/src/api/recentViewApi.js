// src/api/recentViewApi.js
import axiosInstance from "@/api/axiosInstance";

/**
 * 최근 본 상품 조회
 * GET /api/v1/recent-views/{userId}
 */
export const getRecentViewsApi = (userId) =>
  axiosInstance.get(`/recent-views/${userId}`);

/**
 * 최근 본 상품 추가
 * POST /api/v1/recent-views/{userId}/{productId}
 */
export const addRecentViewApi = (userId, productId) =>
  axiosInstance.post(`/recent-views/${userId}/${productId}`);