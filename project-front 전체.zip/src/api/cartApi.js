// src/api/cartApi.js
import axiosInstance from "@/api/axiosInstance";

/**
 * 장바구니 조회
 * GET /api/v1/cart
 */
export const getCartItemsApi = () => axiosInstance.get("/cart");

/**
 * 장바구니 추가
 * POST /api/v1/cart
 * body: { productId, quantity }
 */
export const addToCartApi = ({ productId, quantity = 1 }) =>
  axiosInstance.post("/cart", { productId, quantity });

/**
 * 장바구니 수정(수량)
 * PATCH /api/v1/cart/{cartId}/quantity
 * body: { quantity }
 */
export const updateCartQuantityApi = (cartId, quantity) =>
  axiosInstance.patch(`/cart/${cartId}/quantity`, { quantity });

/**
 * 장바구니 삭제
 * DELETE /api/v1/cart/{productId}
 */
export const deleteCartItemApi = (productId) =>
  axiosInstance.delete(`/cart/${productId}`);

/**
 * 장바구니 전체삭제(유저)
 * DELETE /api/v1/cart/user/{userId}
 */
export const clearCartByUserApi = (userId) =>
  axiosInstance.delete(`/cart/user/${userId}`);