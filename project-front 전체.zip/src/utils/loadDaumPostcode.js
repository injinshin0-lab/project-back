let cachedPromise = null;

export default function loadDaumPostcode() {
  if (typeof window === 'undefined') return Promise.reject(new Error('window is not defined'));
  if (window.daum?.Postcode) return Promise.resolve();

  if (cachedPromise) return cachedPromise;

  cachedPromise = new Promise((resolve, reject) => {
    const script = document.createElement('script');
    script.src = '//t1.daumcdn.net/mapjsapi/bundle/postcode/prod/postcode.v2.js';
    script.async = true;

    script.onload = () => resolve();
    script.onerror = () => reject(new Error('Failed to load Daum Postcode script'));

    document.body.appendChild(script);
  });

  return cachedPromise;
}