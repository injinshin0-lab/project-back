import toast from "react-hot-toast";

export function toastApiError(err, fallback = "요청에 실패했어요.") {
  const msg =
    err?.response?.data?.message ||
    err?.message ||
    fallback;

  toast.error(msg);
}

export function toastSuccess(message) {
  toast.success(message);
}