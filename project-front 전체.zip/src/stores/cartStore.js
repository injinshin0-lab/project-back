// src/stores/cartStore.js
import { create } from "zustand";
import toast from "react-hot-toast";

import {
  getCartItemsApi,
  addToCartApi,
  updateCartQuantityApi,
  deleteCartItemApi,
  clearCartByUserApi,
} from "@/api/cartApi";

import { getWishlistApi, deleteWishlistApi } from "@/api/wishlistApi";
import { getRecentViewsApi } from "@/api/recentViewApi";

const pickMessage = (e, fallback) =>
  e?.response?.data?.message ||
  e?.response?.data?.error ||
  (typeof e?.response?.data === "string" ? e.response.data : null) ||
  e?.message ||
  fallback;

  const normalizeList = (res) => {
    // axios 응답은 res.data에 실제 바디가 담깁니다.
    const d = res?.data ?? res; 
    if (Array.isArray(d)) return d;
    // 만약 백엔드에서 { list: [...] } 형태로 준다면 아래와 같이 접근
    if (Array.isArray(d?.list)) return d.list; 
    return [];
  };

const normalizeCount = (list) => (Array.isArray(list) ? list.length : 0);

const getProductId = (item) =>
  item?.productId ??
  item?.product_id ??
  item?.product?.id ??
  item?.product?.productId;

function getProductName(item) {
  return (
    item?.productName || // RecentProductMapper.xml에서 AS productName으로 줌
    item?.name ||
    item?.product?.name ||
    "상품"
  );
}

export const CART_VIEW = {
  CART: "cart",
  WISHLIST: "wishlist",
  RECENT: "recent",
};

const useCartStore = create((set, get) => ({
  // 탭 상태
  activeView: CART_VIEW.CART,
  setActiveView: (v) => set({ activeView: v }),

  // 장바구니
  cartItems: [],
  cartLoading: false,

  // 찜
  wishlist: [],
  wishlistLoading: false,

  // 최근본
  recentViews: [],
  recentLoading: false,

  // --- fetchers ---
  fetchCartItems: async () => {
    try {
      const res = await getCartItemsApi();
      // 백엔드가 Map.of("items", list)로 주므로 res.data.items를 가져와야 함
      const items = res.data?.cartItems || []; 
      set({ cartItems: items });
    } catch (e) {
      console.error("장바구니 로드 실패", e);
    }
  },

  fetchWishlist: async () => {
    set({ wishlistLoading: true });
    try {
      const res = await getWishlistApi();
      set({ wishlist: normalizeList(res) });
    } catch (e) {
      toast.error(pickMessage(e, "찜 목록 조회 실패"));
    } finally {
      set({ wishlistLoading: false });
    }
  },

  fetchRecentViews: async (userId) => {
    if (!userId) return; // userId가 없으면 호출 안 함
    set({ recentLoading: true });
    try {
      const res = await getRecentViewsApi(userId);
      const list = Array.isArray(res.data) ? res.data : [];
      set({ 
        recentViews: list,
        recentLoading: false 
      });
    } catch (e) {
      console.error("최근 본 상품 로드 실패:", e);
      set({ recentLoading: false });
    }
  },


  // --- cart actions ---
  updateQuantity: async (cartId, quantity) => {
    if (!cartId) return;
    if (Number.isNaN(Number(quantity)) || Number(quantity) < 1) return;

    try {
      await updateCartQuantityApi(cartId, Number(quantity));
      await get().fetchCartItems();
      toast.success("수량이 변경되었습니다.");
    } catch (e) {
      toast.error(pickMessage(e, "수량 변경 실패"));
    }
  },

  addToCart: async ({ productId, quantity }) => {
    try {
      await addToCartApi({ productId, quantity });
      // 담기 성공 후 장바구니 목록을 다시 불러와서 상태를 동기화
      await get().fetchCartItems(); 
    } catch (e) {
      // 에러를 던져서 ProductDetailPage의 catch 문에서 toast를 띄울 수 있게 함
      throw e;
    }
  },

  removeCartItem: async (productId) => {
    if (!productId) return;
    try {
      await deleteCartItemApi(productId);
      set((s) => ({
        cartItems: s.cartItems.filter((it) => getProductId(it) !== productId),
      }));
      toast.success("장바구니에서 삭제했습니다.");
    } catch (e) {
      toast.error(pickMessage(e, "삭제 실패"));
    }
  },

  clearCart: async (userId) => {
    if (!userId) return;
    try {
      await clearCartByUserApi(userId);
      set({ cartItems: [] });
      toast.success("장바구니를 비웠습니다.");
    } catch (e) {
      toast.error(pickMessage(e, "전체 삭제 실패"));
    }
  },

  // --- wishlist actions ---
  removeWishlist: async (productId) => {
    if (!productId) return;
    try {
      await deleteWishlistApi(productId);
      set((s) => ({
        wishlist: s.wishlist.filter((it) => getProductId(it) !== productId),
      }));
      toast.success("찜에서 삭제했습니다.");
    } catch (e) {
      toast.error(pickMessage(e, "찜 삭제 실패"));
    }
  },

  /**
   * ✅ 찜 -> 장바구니 담기
   * - 장바구니에 담고
   * - 장바구니/찜 목록 재조회해서 UI 즉시 반영
   * - 옵션: 담은 뒤 찜에서 자동 삭제하고 싶으면 enableRemoveWishlist=true
   */
  addToCartFromWishlist: async ({ productId, quantity = 1, enableRemoveWishlist = false }) => {
    if (!productId) return;

    try {
      await addToCartApi({ productId, quantity });
      toast.success("장바구니에 담았습니다.");

      if (enableRemoveWishlist) {
        try {
          await deleteWishlistApi(productId);
        } catch {
          // 찜 해제 실패는 치명적이지 않아서 무시
        }
      }

      // ✅ UI 즉시 반영
      await Promise.allSettled([get().fetchCartItems(), get().fetchWishlist()]);
    } catch (e) {
      toast.error(pickMessage(e, "장바구니 담기 실패"));
    }
  },

  // counts
  getCounts: () => {
    const s = get();
    return {
      cart: normalizeCount(s.cartItems),
      wishlist: normalizeCount(s.wishlist),
      recent: normalizeCount(s.recentViews),
    };
  },
}));

export default useCartStore;