// src/stores/categoryStore.js
import { create } from "zustand";
import toast from "react-hot-toast";
import { getCategoriesApi } from "@/api/categoryApi";

// -------------------------
// helpers
// -------------------------
function arrayEqual(a = [], b = []) {
  if (a === b) return true;
  if (!Array.isArray(a) || !Array.isArray(b)) return false;
  if (a.length !== b.length) return false;
  for (let i = 0; i < a.length; i++) if (a[i] !== b[i]) return false;
  return true;
}

function buildTreeFromFlat(flat = []) {
  const nodes = new Map();

  flat.forEach((c) => {
    const id = c?.categoryId ?? c?.id;
    if (id == null) return;

    nodes.set(id, {
      id,
      name: c?.categoryName ?? c?.name ?? "",
      parentId: c?.parentId ?? null,
      level: c?.level ?? null,
      raw: c,
      children: [],
    });
  });

  const roots = [];
  nodes.forEach((node) => {
    const pid = node.parentId;
    if (pid && nodes.has(pid)) nodes.get(pid).children.push(node);
    else roots.push(node);
  });

  return roots;
}

function collectLeafIds(tree = []) {
  const leafIds = [];
  const dfs = (n) => {
    if (!n.children || n.children.length === 0) {
      leafIds.push(n.id);
      return;
    }
    n.children.forEach(dfs);
  };
  tree.forEach(dfs);
  return leafIds;
}

function filterLeafOnly(selectedIds = [], leafIdSet) {
  return selectedIds.filter((id) => leafIdSet.has(id));
}

// -------------------------
// store
// -------------------------
const useCategoryStore = create((set, get) => ({
  // 원본/트리
  flat: [],
  tree: [],
  leafIds: [],
  loading: false,
  _fetchedOnce: false,

  // 선택
  selectedIds: [],
  maxSelect: 10,

  async fetchCategories() {
    const { loading, _fetchedOnce, flat } = get();
    if (loading) return;
    if (_fetchedOnce && Array.isArray(flat) && flat.length > 0) return;

    set({ loading: true });
    try {
      const res = await getCategoriesApi();
      const data = res?.data?.data ?? res?.data ?? [];
      const flatNext = Array.isArray(data) ? data : [];

      const tree = buildTreeFromFlat(flatNext);
      const leafIds = collectLeafIds(tree);
      const leafSet = new Set(leafIds);

      // ✅ 기존 selectedIds가 있으면 leaf만 유지
      const selected = filterLeafOnly(get().selectedIds, leafSet);

      set({
        flat: flatNext,
        tree,
        leafIds,
        selectedIds: selected,
        loading: false,
        _fetchedOnce: true,
      });
    } catch (e) {
      set({ loading: false });
      toast.error("카테고리 불러오기 실패");
      throw e;
    }
  },

  // ✅ 무한루프 방지 핵심: 값이 같으면 set 안 함
  setSelectedIds(nextIds) {
    const prev = get().selectedIds;
    const next = Array.isArray(nextIds) ? nextIds : [];

    const normalized = Array.from(new Set(next))
      .map((v) => Number(v))
      .filter((n) => Number.isFinite(n));

    const leafSet = new Set(get().leafIds);
    const leafOnly = leafSet.size ? filterLeafOnly(normalized, leafSet) : normalized;

    const max = get().maxSelect ?? 10;
    const limited = leafOnly.slice(0, max);

    if (arrayEqual(prev, limited)) return;
    set({ selectedIds: limited });
  },

  toggleSelectedId(id) {
    const n = Number(id);
    if (!Number.isFinite(n)) return;

    const prev = get().selectedIds;
    const has = prev.includes(n);

    const next = has ? prev.filter((x) => x !== n) : [...prev, n];
    get().setSelectedIds(next);
  },

  clearSelected() {
    if (get().selectedIds.length === 0) return;
    set({ selectedIds: [] });
  },

  getSelectedLeafIds() {
    const leafSet = new Set(get().leafIds);
    return leafSet.size ? filterLeafOnly(get().selectedIds, leafSet) : get().selectedIds;
  },
}));

export default useCategoryStore;