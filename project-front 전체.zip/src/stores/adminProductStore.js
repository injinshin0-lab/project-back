// src/stores/adminProductStore.js
import { create } from "zustand";
import toast from "react-hot-toast";

import {
  adminGetProductsApi,
  adminGetProductDetailApi,
  adminCreateProductApi,
  adminUpdateProductApi,
  adminDeleteProductApi,
} from "@/api/adminProductApi";

const DEFAULT_QUERY = {
  page: 1,
  size: 10,
  keyword: "",
  sort: "latest",
  order: "desc",
  categoryId: "",
};

const useAdminProductStore = create((set, get) => ({
  items: [],
  pageInfo: { page: 1, size: 10, totalPages: 1, totalCount: 0 },
  query: { ...DEFAULT_QUERY },
  loading: false,

  setQuery(next) {
    set((s) => ({ query: { ...s.query, ...next } }));
  },

  resetQuery() {
    set({ query: { ...DEFAULT_QUERY } });
  },

  async fetch(params = {}) {
    set({ loading: true });
    try {
      const q = { ...get().query, ...params };

      // query에서 빈값은 빼서 보내기(서버 필터 안전)
      const sendQ = { ...q };
      if (!sendQ.keyword) delete sendQ.keyword;
      if (!sendQ.categoryId) delete sendQ.categoryId;

      const res = await adminGetProductsApi(sendQ);

      // ✅ Spring PageResponseDto: { list, totalPage, currentPage }
      const data = res?.data?.data ?? res?.data ?? {};
      const list = data?.list ?? [];

      const totalPage = data?.totalPage ?? 1;
      const currentPage = data?.currentPage ?? q.page;

      set({
        items: Array.isArray(list) ? list : [],
        pageInfo: {
          page: Number(currentPage) || q.page,
          size: Number(q.size) || 10,
          totalPages: Number(totalPage) || 1,
          totalCount: data?.totalCount ?? data?.totalElements ?? 0,
        },
        query: q,
        loading: false,
      });
    } catch (e) {
      set({ loading: false });
      toast.error("관리자 상품 목록 조회 실패");
      throw e;
    }
  },

  async detail(productId) {
    const res = await adminGetProductDetailApi(productId);
    return res?.data?.data ?? res?.data;
  },

  async create(payload) {
    try {
      await adminCreateProductApi(payload);
      toast.success("상품 등록 완료");
      await get().fetch({ page: 1 });
    } catch (e) {
      toast.error("상품 등록 실패");
      throw e;
    }
  },

  async update(productId, payload) {
    try {
      await adminUpdateProductApi(productId, payload);
      toast.success("상품 수정 완료");
      await get().fetch();
    } catch (e) {
      toast.error("상품 수정 실패");
      throw e;
    }
  },

  async remove(productId) {
    try {
      await adminDeleteProductApi(productId);
      toast.success("상품 삭제 완료");
      await get().fetch();
    } catch (e) {
      toast.error("상품 삭제 실패");
      throw e;
    }
  },
}));

export default useAdminProductStore;