// src/stores/paymentStore.js
import { create } from "zustand";
import toast from "react-hot-toast";
import { readyPaymentApi, confirmPaymentApi } from "@/api/paymentApi";

const pickMessage = (e, fallback) =>
  e?.response?.data?.message ||
  e?.response?.data?.error ||
  (typeof e?.response?.data === "string" ? e.response.data : null) ||
  e?.message ||
  fallback;

const usePaymentStore = create((set, get) => ({
  session: null, // { orderId, amount, source }
  paying: false,
  lastPayment: null, // { paymentId, raw }

  setSession: (session) => set({ session }),

  clearSession: () => set({ session: null, lastPayment: null }),

  /**
   * ✅ 결제 진행
   * - 백엔드 ready/confirm 있으면 호출
   * - 없으면 mock 결제 성공 처리
   */
  payNow: async () => {
    const s = get().session;
    if (!s?.orderId) {
      toast.error("결제 정보가 없습니다.");
      return null;
    }

    set({ paying: true });
    try {
      // 1) 결제 준비 시도
      let readyRes = null;
      try {
        readyRes = await readyPaymentApi({ orderId: s.orderId, amount: s.amount });
      } catch (e) {
        // ✅ 백엔드 결제 미구현 가능 → mock으로 fallback
        console.warn("[PAYMENT READY FAIL -> MOCK]", e);
      }

      const readyData = readyRes?.data;

      // (A) 외부 결제 URL을 주는 경우
      const redirectUrl =
        readyData?.redirectUrl ||
        readyData?.redirect_url ||
        readyData?.nextRedirectUrl ||
        readyData?.next_redirect_url;

      if (redirectUrl) {
        // 외부 결제 페이지로 보낼 수 있음(원하면)
        // 여기서는 "앱 내 결제 흐름"을 위해 일단 mock으로 진행하지 않고,
        // 실제로 쓸 경우 아래 주석 해제:
        // window.location.href = redirectUrl;
        // return { type: "redirect", redirectUrl };

        // 빠른 검증을 위해 앱 내 성공 처리로 진행(개발 단계)
        toast("외부 결제 URL이 왔지만 개발 단계에서는 앱 내 결제 성공으로 처리합니다.");
      }

      // (B) paymentId를 주는 경우
      const paymentId =
        readyData?.paymentId ||
        readyData?.payment_id ||
        readyData?.tid ||
        `mock_${Date.now()}`;

      // 2) 결제 확정 시도(없으면 무시)
      let confirmRes = null;
      try {
        confirmRes = await confirmPaymentApi({ orderId: s.orderId, paymentId });
      } catch (e) {
        console.warn("[PAYMENT CONFIRM FAIL -> MOCK]", e);
      }

      const raw = confirmRes?.data ?? readyData ?? { ok: true, paymentId, mock: true };

      set({ lastPayment: { paymentId, raw } });
      toast.success("결제가 완료되었습니다.");
      return { paymentId, raw };
    } catch (e) {
      toast.error(pickMessage(e, "결제 실패"));
      return null;
    } finally {
      set({ paying: false });
    }
  },
}));

export default usePaymentStore;