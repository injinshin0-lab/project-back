// src/stores/mypageStore.js
import { create } from "zustand";
import useAuthStore from "@/stores/authStore";

import {
  changePasswordApi,
  updateMyInfoApi,
  deleteAccountApi,
  getMyReviewsApi,
  getAddressesApi,
  createAddressApi,
  updateAddressApi,
  deleteAddressApi,
  updateNotificationSettingsApi,
  getNotificationsApi,
  readNotificationApi,
  readAllNotificationsApi,
  deleteNotificationApi,
  getMyOrdersByUserApi,
} from "@/api/mypageApi";

const useMypageStore = create((set, get) => ({
  // ===== 상태 =====
  loading: false,
  error: null,

  // 내 정보(수정 후 반영 용도)
  myInfo: null,

  // 주소록
  addresses: [],
  addressesLoading: false,

  // 내 리뷰
  myReviews: [],
  myReviewsLoading: false,

  // 알림
  notifications: [],
  notificationsLoading: false,
  notificationSettings: null,

  // 주문내역
  orders: [],
  ordersLoading: false,

  // ===== 내부 유틸 =====
  _getUserId: () => {
    const user = useAuthStore.getState().user;
    const id = user?.id ?? user?.user_id ?? user?.userId;
    if (!id) throw new Error("userId is missing");
    return id;
  },

  // ===== 내 정보 =====
  updateMyInfo: async (payload) => {
    const userId = get()._getUserId();
    set({ loading: true, error: null });

    try {
      const res = await updateMyInfoApi(userId, payload);
      set({ loading: false, myInfo: res?.data ?? null });

      // ✅ authStore user도 업데이트하고 싶으면 여기서 연동 가능(선택)
      // useAuthStore.setState((s) => ({ user: { ...s.user, ...(res?.data ?? {}) } }));

      return res?.data;
    } catch (e) {
      set({ loading: false, error: e });
      throw e;
    }
  },

  changePassword: async (payload) => {
    const userId = get()._getUserId();
    set({ loading: true, error: null });

    try {
      const res = await changePasswordApi(userId, payload);
      set({ loading: false });
      return res?.data;
    } catch (e) {
      set({ loading: false, error: e });
      throw e;
    }
  },

  deleteAccount: async (payload = {}) => {
    const userId = get()._getUserId();
    set({ loading: true, error: null });

    try {
      const res = await deleteAccountApi(userId, payload);
      set({ loading: false });
      return res?.data;
    } catch (e) {
      set({ loading: false, error: e });
      throw e;
    }
  },

  // ===== 주소록 =====
  fetchAddresses: async () => {
    const userId = get()._getUserId();
    set({ addressesLoading: true, error: null });

    try {
      const res = await getAddressesApi(userId);
      const data = res?.data;
      set({
        addressesLoading: false,
        addresses: Array.isArray(data) ? data : data?.items ?? [],
      });
    } catch (e) {
      set({ addressesLoading: false, error: e });
      throw e;
    }
  },

  createAddress: async (payload) => {
    const userId = get()._getUserId();
    await createAddressApi(userId, payload);
    await get().fetchAddresses();
  },

  updateAddress: async (addressId, payload) => {
    const userId = get()._getUserId();
    await updateAddressApi(userId, addressId, payload);
    await get().fetchAddresses();
  },

  deleteAddress: async (addressId) => {
    const userId = get()._getUserId();
    await deleteAddressApi(userId, addressId);
    await get().fetchAddresses();
  },

  // ===== 내 리뷰 =====
  fetchMyReviews: async (params = {}) => {
    const userId = get()._getUserId();
    set({ myReviewsLoading: true, error: null });

    try {
      const res = await getMyReviewsApi(userId, params);
      const data = res?.data;
      set({
        myReviewsLoading: false,
        myReviews: Array.isArray(data) ? data : data?.items ?? data?.content ?? [],
      });
      return res?.data;
    } catch (e) {
      set({ myReviewsLoading: false, error: e });
      throw e;
    }
  },

  // ===== 알림 =====
  fetchNotifications: async (params = {}) => {
    const userId = get()._getUserId();
    set({ notificationsLoading: true, error: null });

    try {
      const res = await getNotificationsApi(userId, params);
      const data = res?.data;
      set({
        notificationsLoading: false,
        notifications: Array.isArray(data) ? data : data?.items ?? data?.content ?? [],
      });
      return res?.data;
    } catch (e) {
      set({ notificationsLoading: false, error: e });
      throw e;
    }
  },

  readNotification: async (notificationId) => {
    await readNotificationApi(notificationId);
    await get().fetchNotifications();
  },

  readAllNotifications: async () => {
    const userId = get()._getUserId();
    await readAllNotificationsApi(userId);
    await get().fetchNotifications();
  },

  deleteNotification: async (notificationId) => {
    await deleteNotificationApi(notificationId);
    await get().fetchNotifications();
  },

  updateNotificationSettings: async (payload) => {
    const userId = get()._getUserId();
    const res = await updateNotificationSettingsApi(userId, payload);
    set({ notificationSettings: res?.data ?? null });
    return res?.data;
  },

  // ===== 주문내역 =====
  fetchMyOrders: async (params = {}) => {
    const userId = get()._getUserId();
    set({ ordersLoading: true, error: null });

    try {
      const res = await getMyOrdersByUserApi(userId, params);
      const data = res?.data;
      set({
        ordersLoading: false,
        orders: Array.isArray(data) ? data : data?.items ?? data?.content ?? [],
      });
      return res?.data;
    } catch (e) {
      set({ ordersLoading: false, error: e });
      throw e;
    }
  },
}));

export default useMypageStore;