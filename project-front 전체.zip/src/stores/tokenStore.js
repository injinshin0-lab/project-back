// src/stores/tokenStore.js

const ACCESS_TOKEN_KEY = "ACCESS_TOKEN";

/**
 * accessToken 관리 유틸
 * - axiosInstance에서 직접 import 해서 사용
 * - zustand store랑 분리 (순환 참조 방지)
 */

export function getAccessToken() {
  return localStorage.getItem(ACCESS_TOKEN_KEY);
}

export function setAccessToken(token) {
  if (!token) return;
  localStorage.setItem(ACCESS_TOKEN_KEY, token);
}

export function clearAccessToken() {
  localStorage.removeItem(ACCESS_TOKEN_KEY);
}