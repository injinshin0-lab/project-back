// src/stores/notificationStore.js
import { create } from "zustand";
import toast from "react-hot-toast";

import {
  getUserNotificationsApi,
  readUserNotificationApi,
  readAllUserNotificationsApi,
  deleteUserNotificationApi,
  updateUserNotificationSettingsApi,
} from "@/api/notificationApi";

function getUserIdFromUser(user) {
  return (
    user?.id ??
    user?.userId ??
    user?.user_id ??
    user?.memberId ??
    user?.member_id ??
    null
  );
}

const PAGE_SIZE = 20;

const useNotificationStore = create((set, get) => ({
  loading: false,

  // 목록
  list: [],
  page: 1,
  size: PAGE_SIZE,
  totalPage: 1,

  // 설정(기본)
  settings: {
    enabled: true, // 백엔드 필드 맞춰 필요 시 변경
  },

  // actions
  setPage: (page) => set({ page }),

  fetchNotifications: async (user) => {
    const userId = getUserIdFromUser(user);
    if (!userId) return;

    const { page, size } = get();

    try {
      set({ loading: true });

      const res = await getUserNotificationsApi(userId, { page, size });
      const data = res?.data || {};

      // 서버 응답이 list/page 형태일 수도 있고 배열일 수도 있어서 방어
      const list = Array.isArray(data) ? data : data.list || data.items || [];
      const totalPage = data.totalPage || data.totalPages || 1;
      const currentPage = data.currentPage || data.page || page;

      set({
        list,
        totalPage,
        page: currentPage,
      });
    } catch (e) {
      // ✅ 핵심 수정: 알림 API 미구현(404)은 조용히 무시
      if (e?.response?.status === 404) {
        set({
          list: [],
          totalPage: 1,
        });
        return;
      }

      // ❗ 그 외 에러는 기존대로
      toast.error("알림 조회 실패");
    } finally {
      set({ loading: false });
    }
  },

  markAsRead: async (user, notificationId) => {
    const userId = getUserIdFromUser(user);
    if (!userId || !notificationId) return;

    try {
      set({ loading: true });

      // ✅ payload 키는 백엔드 DTO에 맞춰야 함
      await readUserNotificationApi(userId, { notificationsId: notificationId });

      // 로컬 업데이트
      set((state) => ({
        list: state.list.map((n) => {
          const id = n.id ?? n.notificationsId;
          if (id !== notificationId) return n;
          return {
            ...n,
            isRead: true,
            read: true,
            readAt: n.readAt || new Date().toISOString(),
          };
        }),
      }));
    } catch (e) {
      toast.error("읽음 처리 실패");
    } finally {
      set({ loading: false });
    }
  },

  markAllAsRead: async (user) => {
    const userId = getUserIdFromUser(user);
    if (!userId) return;

    try {
      set({ loading: true });
      await readAllUserNotificationsApi(userId);

      set((state) => ({
        list: state.list.map((n) => ({ ...n, isRead: true, read: true })),
      }));

      toast.success("전체 읽음 처리 완료");
    } catch (e) {
      toast.error("전체 읽음 처리 실패");
    } finally {
      set({ loading: false });
    }
  },

  removeNotification: async (notificationId) => {
    if (!notificationId) return;

    try {
      set({ loading: true });
      await deleteUserNotificationApi(notificationId);

      set((state) => ({
        list: state.list.filter(
          (n) => (n.id ?? n.notificationsId) !== notificationId
        ),
      }));

      toast.success("알림 삭제 완료");
    } catch (e) {
      toast.error("알림 삭제 실패");
    } finally {
      set({ loading: false });
    }
  },

  updateSettings: async (user, nextSettings) => {
    const userId = getUserIdFromUser(user);
    if (!userId) return;

    try {
      set({ loading: true });

      // ✅ 서버 DTO 키에 맞추려면 여기만 바꾸면 됨
      await updateUserNotificationSettingsApi(userId, nextSettings);

      set({ settings: nextSettings });
      toast.success("알림 설정 저장 완료");
    } catch (e) {
      toast.error("알림 설정 저장 실패");
    } finally {
      set({ loading: false });
    }
  },
}));

export default useNotificationStore;

/**
 * ✅ Header 같은 곳에서 "미읽음 개수만" 구독할 때 쓰는 selector
 * - named export여야 Header.jsx에서 import 가능
 */
export const selectUnreadCount = (state) =>
  (state.list || []).filter((n) => !(n?.isRead ?? n?.read)).length;