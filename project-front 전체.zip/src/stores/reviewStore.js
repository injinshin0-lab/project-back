// src/stores/reviewStore.js
import { create } from "zustand";
import {
  getProductReviewsApi,
  createProductReviewApi,
  updateProductReviewApi,
} from "@/api/reviewApi";

const DEFAULT_REVIEW_QUERY = {
  sort: "latest",
  photosOnly: false,
  page: 1,
  size: 10,
};

const normalizeList = (res) => {
  const d = res?.data;
  if (Array.isArray(d?.items)) {
    return { items: d.items, pageInfo: d };
  }
  if (Array.isArray(d?.content)) {
    return {
      items: d.content,
      pageInfo: {
        page: (d.number ?? 0) + 1,
        size: d.size ?? DEFAULT_REVIEW_QUERY.size,
        totalElements: d.totalElements ?? 0,
        totalPages: d.totalPages ?? 1,
      },
    };
  }
  if (Array.isArray(d)) {
    return {
      items: d,
      pageInfo: {
        page: 1,
        size: d.length,
        totalElements: d.length,
        totalPages: 1,
      },
    };
  }
  return {
    items: [],
    pageInfo: {
      page: 1,
      size: DEFAULT_REVIEW_QUERY.size,
      totalElements: 0,
      totalPages: 1,
    },
  };
};

const useReviewStore = create((set, get) => ({
  productId: null,
  reviews: [],
  pageInfo: {
    page: 1,
    size: DEFAULT_REVIEW_QUERY.size,
    totalElements: 0,
    totalPages: 1,
  },
  query: { ...DEFAULT_REVIEW_QUERY },
  loading: false,
  error: null,
  creating: false,

  setProductId: (productId) => set({ productId }),

  setQuery: (patch = {}) =>
    set((s) => ({ query: { ...s.query, ...patch } })),

  fetchReviews: async (productIdArg, override = {}) => {
    const productId = productIdArg ?? get().productId;
    const q = { ...get().query, ...override };
    if (!productId) return [];

    set({ loading: true, error: null });
    try {
      const res = await getProductReviewsApi(productId, q);
      const { items, pageInfo } = normalizeList(res);
      set({
        productId,
        reviews: items,
        pageInfo,
        query: q,
        loading: false,
      });
      return items;
    } catch (e) {
      set({ loading: false, error: e });
      throw e;
    }
  },

  createReview: async (productIdArg, formData) => {
    const productId = productIdArg ?? get().productId;
    set({ creating: true });
    try {
      const res = await createProductReviewApi(productId, formData);
      set({ creating: false });
      await get().fetchReviews(productId);
      return res?.data;
    } catch (e) {
      set({ creating: false });
      throw e;
    }
  },

  // ✅ 수정
  updateReview: async (productIdArg, reviewId, payload) => {
    const productId = productIdArg ?? get().productId;
    if (!productId || !reviewId) throw new Error("invalid ids");

    await updateProductReviewApi(productId, reviewId, payload);
    await get().fetchReviews(productId);
  },

  // ✅ 삭제
  deleteReview: async (productIdArg, reviewId) => {
    const productId = productIdArg ?? get().productId;
    if (!productId || !reviewId) throw new Error("invalid ids");

    await deleteProductReviewApi(productId, reviewId);
    await get().fetchReviews(productId);
  },
}));

export default useReviewStore;