// src/stores/orderStore.js
import { create } from "zustand";
import toast from "react-hot-toast";

import { createOrderApi } from "@/api/orderApi";

const getProductId = (item) =>
  item?.productId ?? item?.product?.id ?? item?.product?.productId ?? item?.product_id;

const getCartId = (item) =>
  item?.cartId ?? item?.id ?? item?.cart_item_id ?? item?.cart_itemId;

const getQty = (item) => item?.quantity ?? item?.qty ?? item?.count ?? 1;

const getPrice = (item) => item?.price ?? item?.product?.price ?? item?.productPrice ?? 0;

const getName = (item) =>
  item?.productName || item?.name || item?.product?.name || item?.product?.productName || "상품";

const pickMessage = (e, fallback) =>
  e?.response?.data?.message ||
  e?.response?.data?.error ||
  (typeof e?.response?.data === "string" ? e.response.data : null) ||
  e?.message ||
  fallback;

const useOrderStore = create((set, get) => ({
  draftSource: "cart", // "cart" | "direct"

  draftItems: [],
  draftMemo: "",
  draftAddress: { postcode: "", address1: "", address2: "" },

  submitting: false,
  lastOrderResult: null,

  setDraftFromCart: (items = [], user = null, source = "cart") => {
    const mapped = (items || [])
      .map((it) => ({
        productId: getProductId(it) ?? Number(it?.productId),
        cartId: getCartId(it),
        name: it?.name ?? getName(it),
        price: Number(it?.price ?? getPrice(it) ?? 0),
        quantity: Number(it?.quantity ?? getQty(it) ?? 1),
      }))
      .filter((x) => x.productId);

    const postcode = user?.postcode ?? user?.zip ?? user?.zipcode ?? "";
    const address1 = user?.address ?? user?.address1 ?? "";
    const address2 = user?.addressDetail ?? user?.address2 ?? "";

    set({
      draftSource: source,
      draftItems: mapped,
      draftMemo: "",
      draftAddress: { postcode, address1, address2 },
      lastOrderResult: null,
    });
  },

  clearDraft: () =>
    set({
      draftSource: "cart",
      draftItems: [],
      draftMemo: "",
      draftAddress: { postcode: "", address1: "", address2: "" },
    }),

  setMemo: (memo) => set({ draftMemo: memo }),

  setAddress: (patch) =>
    set((s) => ({
      draftAddress: { ...s.draftAddress, ...patch },
    })),

  getTotal: () => {
    const s = get();
    return (s.draftItems || []).reduce(
      (acc, it) => acc + Number(it.price) * Number(it.quantity),
      0
    );
  },

  // ✅ 주문 생성: 실패해도 mock 주문번호로 진행(개발용)
  submitOrder: async () => {
    const s = get();

    if (!s.draftItems?.length) {
      toast.error("주문할 상품이 없습니다.");
      return null;
    }

    const payload = {
      items: s.draftItems.map((it) => ({
        productId: it.productId,
        quantity: it.quantity,
        cartId: it.cartId,
      })),

      postcode: s.draftAddress.postcode,
      address1: s.draftAddress.address1,
      address2: s.draftAddress.address2,

      // 호환 키
      address: s.draftAddress.address1,
      addressDetail: s.draftAddress.address2,

      memo: s.draftMemo,
      source: s.draftSource,
    };

    set({ submitting: true });
    try {
      console.log("[ORDER] createOrder payload:", payload);

      const res = await createOrderApi(payload);
      const d = res?.data;

      const orderId = d?.orderId ?? d?.id ?? d?.data?.orderId ?? d?.data?.id ?? null;

      set({ lastOrderResult: { orderId, raw: d } });
      toast.success("주문이 생성되었습니다.");
      return { orderId, raw: d };
    } catch (e) {
      // ✅ 개발 단계: 백엔드 실패해도 결제 UI 검증을 위해 mock orderId 발급
      console.warn("[ORDER] createOrder FAIL -> MOCK", e);
      toast(
        `주문 생성 API 실패(개발용): ${pickMessage(e, "백엔드 미구현/에러")}\n→ mock 주문으로 결제 진행`
      );

      const mockOrderId = `mock_order_${Date.now()}`;
      const raw = { mock: true, message: pickMessage(e, "order api fail") };

      set({ lastOrderResult: { orderId: mockOrderId, raw } });
      return { orderId: mockOrderId, raw };
    } finally {
      set({ submitting: false });
    }
  },
}));

export default useOrderStore;