// src/stores/adminFaqStore.js
import { create } from "zustand";
import toast from "react-hot-toast";

import {
  adminGetFaqsApi,
  adminCreateFaqApi,
  adminUpdateFaqApi,
  adminDeleteFaqApi,
} from "@/api/adminFaqApi";

const DEFAULT_QUERY = {
  keyword: "",
  page: 1,
  size: 10,
};

function normalizeFaq(raw) {
  // 다이어그램: faqId, title, content, createdAt, updatedAt
  const faqId = raw?.faqId ?? raw?.id;
  const title = raw?.title ?? "";
  const content = raw?.content ?? "";
  const createdAt = raw?.createdAt ?? null;
  const updatedAt = raw?.updatedAt ?? null;

  return { ...raw, _faqId: faqId, _title: title, _content: content, _createdAt: createdAt, _updatedAt: updatedAt };
}

const useAdminFaqStore = create((set, get) => ({
  items: [],
  pageInfo: { page: 1, size: 10, totalPages: 1 },
  query: { ...DEFAULT_QUERY },
  loading: false,

  setQuery(next) {
    set((s) => ({ query: { ...s.query, ...next } }));
  },

  resetQuery() {
    set({ query: { ...DEFAULT_QUERY } });
  },

  async fetch(params = {}) {
    set({ loading: true });
    try {
      const q = { ...get().query, ...params };

      const sendQ = { ...q };
      if (!sendQ.keyword) delete sendQ.keyword;

      const res = await adminGetFaqsApi(sendQ);
      const data = res?.data?.data ?? res?.data ?? {};

      const list = Array.isArray(data?.list) ? data.list : [];
      const totalPage = data?.totalPage ?? 1;
      const currentPage = data?.currentPage ?? q.page;

      set({
        items: list.map(normalizeFaq),
        pageInfo: { page: Number(currentPage) || q.page, size: Number(q.size) || 10, totalPages: Number(totalPage) || 1 },
        query: q,
        loading: false,
      });
    } catch (e) {
      set({ loading: false });
      toast.error("FAQ 목록 조회 실패");
      throw e;
    }
  },

  async create(payload) {
    try {
      await adminCreateFaqApi(payload);
      toast.success("FAQ 등록 완료");
      await get().fetch({ page: 1 });
    } catch (e) {
      toast.error("FAQ 등록 실패");
      throw e;
    }
  },

  async update(faqId, payload) {
    try {
      await adminUpdateFaqApi(faqId, payload);
      toast.success("FAQ 수정 완료");
      await get().fetch();
    } catch (e) {
      toast.error("FAQ 수정 실패");
      throw e;
    }
  },

  async remove(faqId) {
    try {
      await adminDeleteFaqApi(faqId);
      toast.success("FAQ 삭제 완료");
      await get().fetch();
    } catch (e) {
      toast.error("FAQ 삭제 실패");
      throw e;
    }
  },
}));

export default useAdminFaqStore;