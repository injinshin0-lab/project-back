// src/stores/orderHistoryStore.js
import { create } from "zustand";
import toast from "react-hot-toast";

import { getMyOrdersApi, getMyOrderDetailApi } from "@/api/orderApi";

/* ===============================
   ✅ 주문 상태 라벨
   =============================== */
export const ORDER_STATUS_LABEL = {
  PENDING: "주문 대기",
  PAID: "결제 완료",
  PREPARING: "상품 준비중",
  SHIPPED: "배송중",
  DELIVERED: "배송 완료",
  CANCELED: "주문 취소",
  REFUNDED: "환불 완료",
};

/* ===============================
   ✅ 결제 수단 라벨
   =============================== */
export const PAYMENT_METHOD_LABEL = {
  CARD: "카드",
  TRANSFER: "계좌이체",
  VBANK: "무통장",
  CASH: "현금",
  POINT: "포인트",
};

/* ===============================
   ✅ 결제 상태 라벨 (이번에 추가)
   =============================== */
export const PAYMENT_STATUS_LABEL = {
  READY: "결제 대기",
  PAID: "결제 완료",
  FAILED: "결제 실패",
  CANCELED: "결제 취소",
  REFUNDED: "환불 완료",
};

/* =============================== */

const pickMessage = (e, fallback) =>
  e?.response?.data?.message ||
  e?.response?.data?.error ||
  (typeof e?.response?.data === "string" ? e.response.data : null) ||
  e?.message ||
  fallback;

const normalizeList = (res) => {
  const d = res?.data ?? res;
  if (Array.isArray(d)) return d;
  if (Array.isArray(d?.items)) return d.items;
  if (Array.isArray(d?.content)) return d.content;
  if (Array.isArray(d?.data)) return d.data;
  return [];
};

const normalizeDetail = (res) => res?.data ?? res ?? null;

const useOrderHistoryStore = create((set, get) => ({
  // 목록
  orders: [],
  loading: false,
  error: null,

  // 상세 캐시
  orderDetailById: {},
  detailLoadingById: {},
  detailErrorById: {},

  reset: () =>
    set({
      orders: [],
      loading: false,
      error: null,
      orderDetailById: {},
      detailLoadingById: {},
      detailErrorById: {},
    }),

  fetchOrders: async (params = {}) => {
    set({ loading: true, error: null });
    try {
      const res = await getMyOrdersApi(params);
      const list = normalizeList(res);
      set({ orders: list });
    } catch (e) {
      const msg = pickMessage(e, "주문 내역을 불러오지 못했습니다.");
      set({ error: msg });
      toast.error(msg);
    } finally {
      set({ loading: false });
    }
  },

  fetchOrderDetail: async (orderId, { force = false } = {}) => {
    if (!orderId) return null;

    const cached = get().orderDetailById?.[orderId];
    if (cached && !force) return cached;

    set((s) => ({
      detailLoadingById: { ...s.detailLoadingById, [orderId]: true },
      detailErrorById: { ...s.detailErrorById, [orderId]: null },
    }));

    try {
      const res = await getMyOrderDetailApi(orderId);
      const detail = normalizeDetail(res);

      set((s) => ({
        orderDetailById: { ...s.orderDetailById, [orderId]: detail },
      }));

      return detail;
    } catch (e) {
      const msg = pickMessage(e, "주문 상세를 불러오지 못했습니다.");
      set((s) => ({
        detailErrorById: { ...s.detailErrorById, [orderId]: msg },
      }));
      toast.error(msg);
      return null;
    } finally {
      set((s) => ({
        detailLoadingById: { ...s.detailLoadingById, [orderId]: false },
      }));
    }
  },

  clearOrderDetailCache: (orderId) => {
    if (!orderId) return;
    set((s) => {
      const nextDetail = { ...s.orderDetailById };
      const nextL = { ...s.detailLoadingById };
      const nextE = { ...s.detailErrorById };
      delete nextDetail[orderId];
      delete nextL[orderId];
      delete nextE[orderId];
      return {
        orderDetailById: nextDetail,
        detailLoadingById: nextL,
        detailErrorById: nextE,
      };
    });
  },
}));

export default useOrderHistoryStore;