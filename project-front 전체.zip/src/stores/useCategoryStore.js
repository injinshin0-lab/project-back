import { create } from 'zustand';
import { getCategoriesApi } from '@/api/categoryApi';

export const useCategoryStore = create((set, get) => ({
  categories: [],
  loading: false,
  fetched: false, // 데이터를 이미 가져왔는지 확인하는 플래그

  fetchCategories: async (force = false) => {
    // 이미 가져온 데이터가 있고, 강제 업데이트(force)가 아니면 호출 안 함
    if (get().fetched && !force) return;

    set({ loading: true });
    try {
      const response = await getCategoriesApi();
      const data = response?.data || response;
      
      // API 응답 구조가 다른 경우를 대비한 유연한 매핑
      const list = Array.isArray(data) ? data : (data?.list || []);
      
      set({ 
        categories: list, 
        loading: false, 
        fetched: true 
      });
    } catch (error) {
      console.error("카테고리 로딩 실패:", error);
      set({ loading: false });
    }
  },

  // 특정 ID로 카테고리 이름을 찾는 헬퍼 (마이페이지/상세페이지용)
  getCategoryName: (id) => {
    const category = get().categories.find(c => (c.categoryId ?? c.id) === id);
    return category ? (category.categoryName ?? category.name) : '미지정';
  }
}));