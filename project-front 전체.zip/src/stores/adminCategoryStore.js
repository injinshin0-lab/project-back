// src/stores/adminCategoryStore.js
import { create } from "zustand";
import toast from "react-hot-toast";

import {
  adminGetCategoriesApi,
  adminCreateCategoryApi,
  adminUpdateCategoryApi,
  adminDeleteCategoryApi,
} from "@/api/adminCategoryApi";

function normalizeCategory(raw) {
  // 백엔드 DTO: categoryId / categoryName / parentId / level
  // 혹시 다른 이름으로 와도 안전 처리
  const id = raw?.categoryId ?? raw?.id;
  const name = raw?.categoryName ?? raw?.name ?? raw?.category_name;
  const parentId = raw?.parentId ?? raw?.parentCategoryId ?? raw?.parent_id ?? null;
  const level = raw?.level ?? raw?.depth ?? null;

  return {
    ...raw,
    _id: id,
    _name: name,
    _parentId: parentId === 0 ? null : parentId,
    _level: level,
  };
}

const useAdminCategoryStore = create((set, get) => ({
  list: [],
  loading: false,

  async fetch() {
    set({ loading: true });
    try {
      const res = await adminGetCategoriesApi();
      const data = res?.data?.data ?? res?.data ?? [];
      const list = Array.isArray(data) ? data.map(normalizeCategory) : [];
      set({ list, loading: false });
    } catch (e) {
      set({ loading: false });
      toast.error("카테고리 조회 실패");
      throw e;
    }
  },

  async create(payload) {
    try {
      await adminCreateCategoryApi(payload);
      toast.success("카테고리 추가 완료");
      await get().fetch();
    } catch (e) {
      toast.error("카테고리 추가 실패");
      throw e;
    }
  },

  async update(categoryId, payload) {
    try {
      await adminUpdateCategoryApi(categoryId, payload);
      toast.success("카테고리 수정 완료");
      await get().fetch();
    } catch (e) {
      toast.error("카테고리 수정 실패");
      throw e;
    }
  },

  async remove(categoryId) {
    try {
      await adminDeleteCategoryApi(categoryId);
      toast.success("카테고리 삭제 완료");
      await get().fetch();
    } catch (e) {
      toast.error("카테고리 삭제 실패");
      throw e;
    }
  },
}));

export default useAdminCategoryStore;