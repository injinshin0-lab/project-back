// src/stores/adminInquiryStore.js
import { create } from "zustand";
import toast from "react-hot-toast";

import { adminGetInquiriesApi, adminReplyInquiryApi } from "@/api/adminInquiryApi";

const DEFAULT_QUERY = {
  keyword: "",
  status: "", // "", "PENDING", "DONE" 등(서버 스펙에 맞게)
  page: 1,
  size: 10,
};

function normalizeInquiry(raw) {
  // 서버 DTO 이름이 다를 수 있어 안전 처리
  const id = raw?.inquiriesId ?? raw?.inquiryId ?? raw?.id;
  const title = raw?.title ?? raw?.subject ?? "";
  const content = raw?.content ?? raw?.question ?? "";
  const writer = raw?.writer ?? raw?.userId ?? raw?.loginId ?? raw?.email ?? "";
  const createdAt = raw?.createdAt ?? raw?.createdDate ?? null;

  const reply = raw?.reply ?? raw?.answer ?? "";
  const repliedAt = raw?.repliedAt ?? raw?.answeredAt ?? raw?.replyAt ?? null;

  // status가 없으면 reply 유무로 추정
  const status = raw?.status ?? (reply ? "DONE" : "PENDING");

  return {
    ...raw,
    _id: id,
    _title: title,
    _content: content,
    _writer: writer,
    _createdAt: createdAt,
    _reply: reply,
    _repliedAt: repliedAt,
    _status: status,
  };
}

const useAdminInquiryStore = create((set, get) => ({
  items: [],
  pageInfo: { page: 1, size: 10, totalPages: 1 },
  query: { ...DEFAULT_QUERY },
  loading: false,

  setQuery(next) {
    set((s) => ({ query: { ...s.query, ...next } }));
  },

  resetQuery() {
    set({ query: { ...DEFAULT_QUERY } });
  },

  async fetch(params = {}) {
    set({ loading: true });
    try {
      const q = { ...get().query, ...params };

      const sendQ = { ...q };
      if (!sendQ.keyword) delete sendQ.keyword;
      if (!sendQ.status) delete sendQ.status;

      const res = await adminGetInquiriesApi(sendQ);
      const data = res?.data?.data ?? res?.data ?? {};

      const list = Array.isArray(data?.list) ? data.list : [];
      const totalPage = data?.totalPage ?? 1;
      const currentPage = data?.currentPage ?? q.page;

      set({
        items: list.map(normalizeInquiry),
        pageInfo: {
          page: Number(currentPage) || q.page,
          size: Number(q.size) || 10,
          totalPages: Number(totalPage) || 1,
        },
        query: q,
        loading: false,
      });
    } catch (e) {
      set({ loading: false });
      toast.error("문의 목록 조회 실패");
      throw e;
    }
  },

  async reply(inquiriesId, replyText) {
    try {
      const reply = (replyText ?? "").trim();
      if (!reply) {
        toast.error("답변 내용을 입력해주세요");
        return;
      }
      await adminReplyInquiryApi(inquiriesId, { reply });
      toast.success("답변 등록 완료");
      await get().fetch();
    } catch (e) {
      toast.error("답변 등록 실패");
      throw e;
    }
  },
}));

export default useAdminInquiryStore;