// src/stores/productStore.js
import { create } from "zustand";
import { getProductsApi, getProductDetailApi } from "@/api/productApi";
import { addWishlistApi, deleteWishlistApi, getWishlistApi } from "@/api/wishlistApi";

const PRODUCT_LIST_STORAGE_KEY = "BOGAM_PRODUCT_LIST_QUERY_V1";

// 안전 파싱
function safeParse(jsonString, fallback) {
  try {
    if (!jsonString) return fallback;
    return JSON.parse(jsonString);
  } catch {
    return fallback;
  }
}

function loadListQuery() {
  const raw = localStorage.getItem(PRODUCT_LIST_STORAGE_KEY);
  const data = safeParse(raw, null);

  // 기본값
  const defaults = {
    page: 1,
    size: 12,
    keyword: "",
    sort: "latest", // 백엔드 스펙에 맞게 바꿔도 됨
    order: "desc",  // asc/desc
    categoryId: null,
  };

  if (!data || typeof data !== "object") return defaults;

  return {
    page: Number(data.page) || defaults.page,
    size: Number(data.size) || defaults.size,
    keyword: typeof data.keyword === "string" ? data.keyword : defaults.keyword,
    sort: typeof data.sort === "string" ? data.sort : defaults.sort,
    order: typeof data.order === "string" ? data.order : defaults.order,
    categoryId:
      data.categoryId === null || data.categoryId === undefined
        ? defaults.categoryId
        : data.categoryId,
  };
}

function saveListQuery(query) {
  localStorage.setItem(PRODUCT_LIST_STORAGE_KEY, JSON.stringify(query));
}

function normalizeProductsResponse(resData) {
  const data = resData?.data ?? resData;

  // 백엔드 PageResponseDto의 필드명이 'list'이므로 이를 추가합니다.
  const items =
    data?.list ??      // ✅ 백엔드 PageResponseDto 필드명
    data?.items ??
    data?.content ??
    [];

  const page = Number(data?.currentPage) || 1; // 백엔드는 currentPage 사용
  const totalPages = Number(data?.totalPage) || 1; // 백엔드는 totalPage 사용
  const totalElements = Number(data?.totalCount) || items.length;

  return {
    items: Array.isArray(items) ? items : [],
    page,
    totalPages,
    totalElements,
  };
}

const useProductStore = create((set, get) => {
  const initialQuery = loadListQuery();

  return {
    // =========================
    // state: list query
    // =========================
    query: initialQuery,

    // =========================
    // state: list data
    // =========================
    products: [],
    totalPages: 1,
    totalElements: 0,

    listLoading: false,
    listError: null,

    // =========================
    // state: detail cache
    // =========================
    productById: {}, // { [productId]: product }
    detailLoadingById: {}, // { [productId]: boolean }
    detailErrorById: {}, // { [productId]: any }

    wishlistMap: {}, // { [productId]: boolean }

    toggleWishlist: async (productId) => {
      const key = String(productId);
      const isWished = !!get().wishlistMap[key];

      try {
        if (isWished) {
          // 찜 취소 API 호출
          await deleteWishlistApi(productId); 
          
          set((state) => ({
            wishlistMap: { ...state.wishlistMap, [key]: false }
          }));
          return "removed";
        } else {
          // 찜 추가 API 호출
          await addWishlistApi(productId);

          set((state) => ({
            wishlistMap: { ...state.wishlistMap, [key]: true }
          }));
          return "added";
        }
      } catch (err) {
        // ESLint no-useless-catch 방지: 에러 로깅 등의 추가 작업 수행
        console.error("찜하기 토글 중 오류 발생:", err);
        throw err; 
      }
    },

    // =========================
    // actions: query setters
    // =========================
    setQuery: (partial) => {
      const prev = get().query;
      const next = { ...prev, ...partial };

      // 숫자 필드 보정
      next.page = Math.max(1, Number(next.page) || 1);
      next.size = Math.max(1, Number(next.size) || prev.size || 12);

      saveListQuery(next);
      set({ query: next });
    },

    // 페이지/필터 바뀌면 보통 page=1로 보내는 게 UX 좋음
    setFilters: (partial) => {
      const prev = get().query;
      const next = { ...prev, ...partial, page: 1 };

      next.size = Math.max(1, Number(next.size) || prev.size || 12);

      saveListQuery(next);
      set({ query: next });
    },

    resetQuery: () => {
      const defaults = {
        page: 1,
        size: 12,
        keyword: "",
        sort: "latest",
        order: "desc",
        categoryId: null,
      };
      saveListQuery(defaults);
      set({ query: defaults });
    },

    // =========================
    // actions: fetch list
    // =========================
    fetchProducts: async (overrideParams = {}) => {
      const { query } = get();
      const params = { ...query, ...overrideParams };

      // 저장(override가 들어온 경우도 반영)
      const mergedQuery = {
        ...query,
        ...overrideParams,
      };
      // page/size 보정
      mergedQuery.page = Math.max(1, Number(mergedQuery.page) || 1);
      mergedQuery.size = Math.max(1, Number(mergedQuery.size) || 12);

      saveListQuery(mergedQuery);
      set({
        query: mergedQuery,
        listLoading: true,
        listError: null,
      });

      try {
        const res = await getProductsApi(params);
        const normalized = normalizeProductsResponse(res);

        set({
          products: normalized.items,
          totalPages: normalized.totalPages,
          totalElements: normalized.totalElements,
          listLoading: false,
        });

        return normalized.items;
      } catch (err) {
        set({
          listError: err,
          listLoading: false,
        });
        return null;
      }
    },

    // =========================
    // actions: fetch detail (cached)
    // =========================
    fetchProductDetail: async (productId, { force = false } = {}) => {
      if (productId === undefined || productId === null) return null;

      const key = String(productId);
      const { productById } = get();

      // 캐시 히트
      if (!force && productById[key]) {
        return productById[key];
      }

      set((state) => ({
        detailLoadingById: { ...state.detailLoadingById, [key]: true },
        detailErrorById: { ...state.detailErrorById, [key]: null },
      }));

      try {
        const res = await getProductDetailApi(productId);

        if (res && res.isWished !== undefined) {
          set((state) => ({
            wishlistMap: { ...state.wishlistMap, [String(productId)]: res.isWished }
          }));
        }

        set((state) => ({
          productById: { ...state.productById, [key]: res },
          detailLoadingById: { ...state.detailLoadingById, [key]: false },
        }));

        return res;
      } catch (err) {
        set((state) => ({
          detailErrorById: { ...state.detailErrorById, [key]: err },
          detailLoadingById: { ...state.detailLoadingById, [key]: false },
        }));
        return null;
      }
    },

    fetchWishlist: async () => {
      try {
        const res = await getWishlistApi(); // GET /api/v1/wishlist
        const list = res.data || res;
        const map = {};
        list.forEach(item => {
          const id = item.productId || item.id;
          map[String(id)] = true;
        });
        set({ wishlistMap: map });
      } catch (err) {
        console.error("찜 목록 로드 실패", err);
      }
    },

    // =========================
    // helpers
    // =========================
    getCachedProduct: (productId) => {
      const key = String(productId);
      return get().productById[key] ?? null;
    },

    clearDetailCache: () => {
      set({
        productById: {},
        detailLoadingById: {},
        detailErrorById: {},
      });
    },
  };
});

export default useProductStore;