// src/stores/authStore.js
import { create } from "zustand";
import toast from "react-hot-toast";
import { loginApi, meApi, logoutApi } from "@/api/authApi";

const is401 = (e) => e?.response?.status === 401;

const pickUser = (res) => res?.data?.data ?? res?.data ?? null;

const getRole = (user) =>
  user?.role ?? user?.authority ?? user?.userRole ?? user?.type ?? null;

const useAuthStore = create((set, get) => ({
  user: null,
  isAuthenticated: false,
  isAdmin: false, // ✅ 추가
  loading: false,
  isInitializing: true,

  // ✅ 앱 시작 시 1회: 자동 로그인(세션/쿠키 기반이면 meApi가 핵심)
  initialize: async () => {
    // 이미 초기화 했으면 재호출 방지
    if (!get().isInitializing && get().user) return;

    set({ loading: true, isInitializing: true });

    try {
      const res = await meApi(); // POST /api/v1/auth/auto-login
      const data = pickUser(res);

      set({
        user: data,
        isAuthenticated: true,
        isAdmin: getRole(data) === "ADMIN", // ✅ 추가
        loading: false,
        isInitializing: false,
      });

      return data;
    } catch (e) {
      // ✅ 401은 "비로그인"이 정상
      if (is401(e)) {
        set({
          user: null,
          isAuthenticated: false,
          isAdmin: false, // ✅ 추가
          loading: false,
          isInitializing: false,
        });
        return null;
      }

      set({ loading: false, isInitializing: false });
      console.error("[authStore.initialize] error:", e);
      return null;
    }
  },

  // ✅ 로그인
  login: async ({ loginId, password }) => {
    set({ loading: true });

    try {
      // 1) 로그인 요청
      const res = await loginApi({ loginId, password });

      // ✅ 로그인 성공 즉시 상태 올려서 화면이 안 돌아가게
      // (백엔드가 user를 같이 주면 그걸로 세팅)
      const maybeUser = pickUser(res);
      const nextUser =
        maybeUser && typeof maybeUser === "object" ? maybeUser : get().user;

      set({
        isAuthenticated: true,
        user: nextUser,
        isAdmin: getRole(nextUser) === "ADMIN", // ✅ 추가
      });

      // 2) 이어서 auto-login으로 “진짜 유저” 동기화(세션/쿠키 확정)
      try {
        const me = await meApi();
        const meData = pickUser(me);

        set({
          user: meData,
          isAuthenticated: true,
          isAdmin: getRole(meData) === "ADMIN", // ✅ 추가
          loading: false,
          isInitializing: false, // ✅ 기존 initialized 같은 필드 대신 정상 필드 사용
        });

        // ✅ LoginForm에서 role 분기 이동할 수 있도록 user 반환
        return meData;
      } catch (e2) {
        // meApi 실패해도 일단 로그인 성공은 유지(세션/쿠키 구조에 따라)
        set({ loading: false, isInitializing: false });

        // ✅ 그래도 LoginForm에서 분기할 수 있게, 최소 user 반환
        return nextUser;
      }
    } catch (e) {
      set({ loading: false });
      if (is401(e)) toast.error("아이디/비밀번호가 올바르지 않습니다.");
      else toast.error("로그인 실패");
      throw e;
    }
  },

  // ✅ 로그아웃
  logout: async () => {
    set({ loading: true });
    try {
      await logoutApi?.();
    } catch (e) {
      // 실패해도 프론트 상태는 로그아웃 처리
    } finally {
      set({
        user: null,
        isAuthenticated: false,
        isAdmin: false, // ✅ 추가
        loading: false,
        isInitializing: false,
      });
    }
  },
}));

export default useAuthStore;