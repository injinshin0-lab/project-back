import useAuthStore from "@/stores/authStore";
import { useNavigate } from "react-router-dom";

export default function LogoutButton() {
  const logout = useAuthStore((s) => s.logout);
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    alert("로그아웃 되었습니다.");
    navigate("/login");
  };

  return (
    <button type="button" onClick={handleLogout}>
      로그아웃
    </button>
  );
}