// src/components/auth/signup/CategoriesSection.jsx
export default function CategoriesSection({
  categories,
  selectedIds,
  onToggleCategory,
  loading,
}) {
  return (
    <section className="border rounded-lg p-4">
      <div className="font-bold mb-3">관심 카테고리</div>

      {loading ? (
        <div className="text-sm text-gray-600">카테고리 불러오는 중...</div>
      ) : (
        <div className="flex flex-wrap gap-2">
          {(categories || []).map((c) => {
            const id = c.id ?? c.categoryId ?? c.category_id;
            const name = c.categoryName ?? c.name ?? c.title ?? "카테고리";
            const checked = selectedIds.includes(Number(id));

            return (
              <button
                key={String(id)}
                type="button"
                onClick={() => onToggleCategory(Number(id))}
                className={`px-3 py-2 rounded border ${
                  checked ? "bg-black text-white" : ""
                }`}
              >
                {name}
              </button>
            );
          })}
        </div>
      )}

      <div className="text-xs text-gray-500 mt-2">
        * 최소 1개 이상 선택해야 회원가입이 가능합니다.
      </div>
    </section>
  );
}