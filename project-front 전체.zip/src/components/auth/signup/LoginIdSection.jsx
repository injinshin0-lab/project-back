// src/components/auth/signup/LoginIdSection.jsx
export default function LoginIdSection({
  form,
  onChange,
  onCheckLoginId,
  loginIdCheck,
  isCheckingLoginId,
}) {
  return (
    <section className="border rounded-lg p-4">
      <div className="font-bold mb-3">아이디</div>

      <div className="flex gap-2 items-center">
        <input
          name="loginId"
          value={form.loginId}
          onChange={onChange}
          className="flex-1 border rounded px-3 py-2"
          placeholder="아이디 입력"
          autoComplete="username"
        />
        <button
          type="button"
          onClick={onCheckLoginId}
          className="px-3 py-2 border rounded"
          disabled={isCheckingLoginId || !form.loginId?.trim()}
        >
          {isCheckingLoginId ? "확인중..." : "중복확인"}
        </button>
      </div>

      {loginIdCheck?.checked ? (
        <div
          className={`text-sm mt-2 ${
            loginIdCheck.available ? "text-green-700" : "text-red-600"
          }`}
        >
          {loginIdCheck.message}
        </div>
      ) : (
        <div className="text-xs text-gray-500 mt-2">
          * 아이디 입력 후 중복확인을 진행해주세요.
        </div>
      )}
    </section>
  );
}