// src/components/auth/signup/PasswordSection.jsx
export default function PasswordSection({
  form,
  onChange,
  showPw,
  showConfirmPw,
  onTogglePw,
  onToggleConfirmPw,
}) {
  return (
    <section className="border rounded-lg p-4">
      <div className="font-bold mb-3">비밀번호</div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        <div>
          <label className="text-sm text-gray-600">비밀번호</label>
          <div className="flex gap-2 mt-1">
            <input
              name="password"
              type={showPw ? "text" : "password"}
              value={form.password}
              onChange={onChange}
              className="flex-1 border rounded px-3 py-2"
              placeholder="4자 이상, 한글 금지"
              autoComplete="new-password"
            />
            <button
              type="button"
              onClick={onTogglePw}
              className="px-3 py-2 border rounded"
            >
              {showPw ? "숨김" : "보기"}
            </button>
          </div>
        </div>

        <div>
          <label className="text-sm text-gray-600">비밀번호 확인</label>
          <div className="flex gap-2 mt-1">
            <input
              name="confirmPassword"
              type={showConfirmPw ? "text" : "password"}
              value={form.confirmPassword}
              onChange={onChange}
              className="flex-1 border rounded px-3 py-2"
              placeholder="비밀번호 재입력"
              autoComplete="new-password"
            />
            <button
              type="button"
              onClick={onToggleConfirmPw}
              className="px-3 py-2 border rounded"
            >
              {showConfirmPw ? "숨김" : "보기"}
            </button>
          </div>
        </div>
      </div>

      <div className="text-xs text-gray-500 mt-2">
        * 비밀번호 규칙: 4자 이상 / 한글 금지
      </div>
    </section>
  );
}