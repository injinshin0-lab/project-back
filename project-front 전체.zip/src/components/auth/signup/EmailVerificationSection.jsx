// src/components/auth/signup/EmailVerificationSection.jsx
export default function EmailVerificationSection({
  form,
  onChange,
  emailCode,
  onChangeEmailCode,
  onSendEmailCode,
  onVerifyEmailCode,
  emailSent,
  emailVerified,
  isSendingEmail,
  isVerifyingEmail,
}) {
  return (
    <section className="border rounded-lg p-4">
      <div className="font-bold mb-3">이메일 인증</div>

      <div className="flex gap-2 items-center">
        <input
          name="email"
          value={form.email}
          onChange={onChange}
          className="flex-1 border rounded px-3 py-2"
          placeholder="email@example.com"
          autoComplete="email"
        />
        <button
          type="button"
          onClick={onSendEmailCode}
          className="px-3 py-2 border rounded"
          disabled={isSendingEmail || !form.email?.trim()}
        >
          {isSendingEmail ? "발송중..." : "인증번호 발송"}
        </button>
      </div>

      <div className="flex gap-2 items-center mt-3">
        <input
          value={emailCode}
          onChange={onChangeEmailCode}
          className="flex-1 border rounded px-3 py-2"
          placeholder="인증번호 6자리"
          inputMode="numeric"
          disabled={!emailSent || emailVerified}
        />
        <button
          type="button"
          onClick={onVerifyEmailCode}
          className="px-3 py-2 border rounded"
          disabled={!emailSent || emailVerified || isVerifyingEmail}
        >
          {emailVerified ? "인증완료" : isVerifyingEmail ? "확인중..." : "인증하기"}
        </button>
      </div>

      <div className="text-xs mt-2">
        {!emailSent ? (
          <span className="text-gray-500">* 인증번호 발송 후 인증이 가능합니다.</span>
        ) : emailVerified ? (
          <span className="text-green-700">* 이메일 인증이 완료되었습니다.</span>
        ) : (
          <span className="text-gray-600">
            * 인증번호가 다르면 401이 나올 수 있어요(권한 문제가 아니라 “불일치/만료” 의미).
          </span>
        )}
      </div>
    </section>
  );
}