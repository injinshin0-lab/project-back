// src/components/auth/signup/AgreementSection.jsx
export default function AgreementSection({ form, onToggleAgree }) {
  return (
    <section className="border rounded-lg p-4">
      <div className="font-bold mb-3">약관 동의</div>

      <label className="flex items-center gap-2">
        <input type="checkbox" checked={!!form.agree} onChange={onToggleAgree} />
        <span className="text-sm">필수 약관에 동의합니다.</span>
      </label>
    </section>
  );
}