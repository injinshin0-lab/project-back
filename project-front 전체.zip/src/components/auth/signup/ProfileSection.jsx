// src/components/auth/signup/ProfileSection.jsx
export default function ProfileSection({ form, onChange }) {
  return (
    <section className="border rounded-lg p-4">
      <div className="font-bold mb-3">기본 정보</div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        <div>
          <label className="text-sm text-gray-600">이름</label>
          <input
            name="name"
            value={form.name}
            onChange={onChange}
            className="w-full border rounded px-3 py-2 mt-1"
            placeholder="이름"
            autoComplete="name"
          />
        </div>

        <div>
          <label className="text-sm text-gray-600">휴대폰</label>
          <input
            name="phone"
            value={form.phone}
            onChange={onChange}
            className="w-full border rounded px-3 py-2 mt-1"
            placeholder="01012345678"
            autoComplete="tel"
          />
        </div>
      </div>
    </section>
  );
}