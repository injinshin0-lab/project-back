// src/components/auth/signup/AddressSection.jsx
export default function AddressSection({ form, onChange, onSearchAddress }) {
  return (
    <section className="border rounded-lg p-4">
      <div className="font-bold mb-3">주소</div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        <div>
          <label className="text-sm text-gray-600">우편번호</label>
          <div className="flex gap-2 mt-1">
            <input
              name="postcode"
              value={form.postcode}
              onChange={onChange}
              className="flex-1 border rounded px-3 py-2"
              placeholder="우편번호"
            />
            <button
              type="button"
              onClick={onSearchAddress}
              className="px-3 py-2 border rounded"
            >
              주소찾기
            </button>
          </div>
        </div>

        <div className="md:col-span-2">
          <label className="text-sm text-gray-600">주소</label>
          <input
            name="address1"
            value={form.address1}
            onChange={onChange}
            className="w-full border rounded px-3 py-2 mt-1"
            placeholder="기본주소"
          />
        </div>

        <div className="md:col-span-2">
          <label className="text-sm text-gray-600">상세주소</label>
          <input
            name="address2"
            value={form.address2}
            onChange={onChange}
            className="w-full border rounded px-3 py-2 mt-1"
            placeholder="상세주소"
          />
        </div>
      </div>
    </section>
  );
}