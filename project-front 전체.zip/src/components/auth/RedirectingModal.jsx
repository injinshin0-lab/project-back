export default function RedirectingModal({ message = '로그인 화면으로 이동합니다…' }) {
  return (
    <div className="modal-overlay">
      <div className="modal-card" role="dialog" aria-modal="true">
        <h2 className="modal-title">잠시만요</h2>
        <p className="modal-desc">{message}</p>
      </div>
    </div>
  );
}