// src/components/auth/LoginForm.jsx
import { useEffect, useState } from "react";
import { Link, useNavigate, useLocation } from "react-router-dom";
import toast from "react-hot-toast";

import useAuthStore from "@/stores/authStore";

// ✅ role 파싱(백엔드 응답 포맷 방어)
function getRole(user) {
  if (!user) return "USER";
  const raw = user.role ?? user.roles ?? user.authorities ?? user.authority ?? user.type;

  if (typeof raw === "string") {
    if (raw === "ROLE_ADMIN") return "ADMIN";
    return raw;
  }
  if (Array.isArray(raw)) {
    if (raw.includes("ADMIN") || raw.includes("ROLE_ADMIN")) return "ADMIN";
    return raw[0] ?? "USER";
  }
  if (Array.isArray(user.authorities)) {
    const arr = user.authorities.map((a) => a?.authority).filter(Boolean);
    if (arr.includes("ROLE_ADMIN") || arr.includes("ADMIN")) return "ADMIN";
    return arr[0] ?? "USER";
  }
  return "USER";
}

const LS_SAVED_ID = "SAVE_LOGIN_ID";
const LS_AUTO_LOGIN = "AUTO_LOGIN";

export default function LoginForm() {
  const navigate = useNavigate();
  const location = useLocation();
  const { login, loading: storeLoading } = useAuthStore();

  const [form, setForm] = useState({
    loginId: "",
    password: "",
  });

  const [saveId, setSaveId] = useState(false);
  const [autoLogin, setAutoLogin] = useState(false);
  const [localLoading, setLocalLoading] = useState(false);

  // 전역 로딩과 지역 로딩 합산
  const isLoading = storeLoading || localLoading;

  // ✅ 초기 로컬스토리지 반영 (아이디 저장/자동 로그인 불러오기)
  useEffect(() => {
    const savedId = localStorage.getItem(LS_SAVED_ID) || "";
    const auto = localStorage.getItem(LS_AUTO_LOGIN) === "true";

    if (savedId) {
      setForm((prev) => ({ ...prev, loginId: savedId }));
      setSaveId(true);
    }
    setAutoLogin(auto);
  }, []);


  const onChange = (e) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const onSubmit = async (e) => {
    e.preventDefault();

    const loginId = form.loginId.trim();
    const password = form.password;

    if (!loginId || !password) {
      toast.error("아이디/비밀번호를 입력해주세요.");
      return;
    }

    try {
      setLocalLoading(true);

      // ✅ authStore.login()이 user를 return 하도록 이미 수정했음
      const u = await login({ loginId, password });
      console.log("로그인 성공 유저 정보:", u); // 👈 데이터 구조 확인

      // ✅ 로컬스토리지 처리 (아이디 저장 / 자동 로그인 여부 저장)
      if (saveId) localStorage.setItem(LS_SAVED_ID, loginId);
      else localStorage.removeItem(LS_SAVED_ID);

      if (autoLogin) localStorage.setItem(LS_AUTO_LOGIN, "true");
      else localStorage.removeItem(LS_AUTO_LOGIN);

      toast.success("로그인 성공!");

      // ✅ 권한 판별 및 경로 이동 로직
      const role = getRole(u);
      console.log("파싱된 역할(role):", role); // 👈 "ADMIN"이 나오는지 확인

      const from = location.state?.from;

     if (from) {
        navigate(from, { replace: true });
      } else if (role === "ADMIN") {
        console.log("관리자 경로로 이동합니다.");
        navigate("/admin", { replace: true });
      } else {
        console.log("일반 사용자 경로로 이동합니다.");
        navigate("/bogam", { replace: true });
      }
    } catch (err) {
      // 에러 메시지 처리 (두 번째 코드의 상세 에러 로깅/표시 적용)
      const data = err?.response?.data;
      const msg = (data && (data.message || data.error)) || "로그인 정보를 확인해주세요.";
      toast.error(msg);
    } finally {
      setLocalLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col justify-center items-center p-4">
      {/* 메인으로 돌아가기 버튼 */}
      <div className="mb-6">
        <button
          onClick={() => navigate("/bogam")}
          className="flex items-center text-gray-500 hover:text-black transition-colors"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
          </svg>
          메인으로 돌아가기
        </button>
      </div>

      <div className="max-w-md w-full bg-white rounded-2xl shadow-xl p-8">
        <div className="text-center mb-10">
          <h1 className="text-3xl font-bold text-gray-900">로그인</h1>
          <p className="text-gray-500 mt-2 text-sm">
            관리자/회원 로그인은 동일한 페이지를 사용합니다.
          </p>
        </div>

        <form className="space-y-4" onSubmit={onSubmit}>
          {/* 아이디 입력 */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">아이디</label>
            <input
              name="loginId"
              type="text"
              placeholder="아이디를 입력하세요"
              value={form.loginId}
              onChange={onChange}
              disabled={isLoading}
              autoComplete="username"
              className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-black focus:border-transparent outline-none transition-all disabled:bg-gray-100"
            />
          </div>

          {/* 비밀번호 입력 */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">비밀번호</label>
            <input
              type="password"
              name="password"
              placeholder="비밀번호를 입력하세요"
              value={form.password}
              onChange={onChange}
              disabled={isLoading}
              autoComplete="current-password"
              className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-black focus:border-transparent outline-none transition-all disabled:bg-gray-100"
            />
          </div>

          {/* 옵션 선택 (자동로그인 / 아이디저장) */}
          <div className="flex items-center justify-between py-2">
            <div className="flex gap-4">
              <label className="flex items-center gap-2 cursor-pointer group">
                <input
                  type="checkbox"
                  checked={autoLogin}
                  onChange={(e) => setAutoLogin(e.target.checked)}
                  disabled={isLoading}
                  className="w-4 h-4 rounded border-gray-300 text-black focus:ring-black cursor-pointer"
                />
                <span className="text-sm text-gray-600 group-hover:text-black">자동 로그인</span>
              </label>

              <label className="flex items-center gap-2 cursor-pointer group">
                <input
                  type="checkbox"
                  checked={saveId}
                  onChange={(e) => setSaveId(e.target.checked)}
                  disabled={isLoading}
                  className="w-4 h-4 rounded border-gray-300 text-black focus:ring-black cursor-pointer"
                />
                <span className="text-sm text-gray-600 group-hover:text-black">아이디 저장</span>
              </label>
            </div>
          </div>

          {/* 로그인 버튼 */}
          <button
            type="submit"
            disabled={isLoading}
            className="w-full py-3 bg-black text-white rounded-lg font-semibold hover:bg-gray-800 active:scale-[0.98] transition-all disabled:bg-gray-400 mt-2"
          >
            {isLoading ? (
              <span className="flex items-center justify-center">
                <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                로그인 중...
              </span>
            ) : "로그인"}
          </button>
        </form>

        {/* 푸터 영역: 아이디찾기 / 비밀번호찾기 / 회원가입 */}
        <div className="mt-8 pt-6 border-t border-gray-100">
          <div className="flex justify-center gap-4 text-sm text-gray-500">
            <Link to="/find/id" className="hover:text-black transition-colors">아이디 찾기</Link>
            <span className="text-gray-300">|</span>
            <Link to="/find/password" className="hover:text-black transition-colors">비밀번호 찾기</Link>
            <span className="text-gray-300">|</span>
            <Link to="/signup" className="font-semibold text-black hover:underline">회원가입</Link>
          </div>
        </div>
      </div>
    </div>
  );
}