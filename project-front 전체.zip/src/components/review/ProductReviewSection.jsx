// src/components/review/ProductReviewSection.jsx
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import toast from "react-hot-toast";

import useAuthStore from "@/stores/authStore";
import useReviewStore from "@/stores/reviewStore";

const SORT_OPTIONS = [
  { value: "latest", label: "최신순" },
  { value: "rating_desc", label: "평점 높은순" },
  { value: "rating_asc", label: "평점 낮은순" },
];

export default function ProductReviewSection({ productId }) {
  const navigate = useNavigate();
  const { isAuthenticated, user } = useAuthStore();
  const {
    reviews,
    pageInfo,
    query,
    loading,
    setProductId,
    setQuery,
    fetchReviews,
    updateReview,
    deleteReview,
  } = useReviewStore();

  const [editingId, setEditingId] = useState(null);
  const [editRating, setEditRating] = useState(5);
  const [editContent, setEditContent] = useState("");

  useEffect(() => {
    setProductId(productId);
  }, [productId]);

  useEffect(() => {
    fetchReviews(productId).catch(() =>
      toast.error("리뷰 목록을 불러오지 못했습니다.")
    );
  }, [productId, query.sort, query.photosOnly, query.page]);

  const onStartEdit = (r) => {
    setEditingId(r.reviewId ?? r.id);
    setEditRating(r.rating ?? 5);
    setEditContent(r.content ?? "");
  };

  const onCancelEdit = () => {
    setEditingId(null);
    setEditRating(5);
    setEditContent("");
  };

  const onSaveEdit = async (reviewId) => {
    try {
      await updateReview(productId, reviewId, {
        rating: editRating,
        content: editContent,
      });
      toast.success("리뷰가 수정되었습니다.");
      onCancelEdit();
    } catch {
      toast.error("리뷰 수정에 실패했습니다.");
    }
  };

  const onDelete = async (reviewId) => {
    if (!window.confirm("리뷰를 삭제할까요?")) return;
    try {
      await deleteReview(productId, reviewId);
      toast.success("리뷰가 삭제되었습니다.");
    } catch {
      toast.error("리뷰 삭제에 실패했습니다.");
    }
  };

  const totalPages = pageInfo?.totalPages ?? 1;
  const currentPage = pageInfo?.page ?? 1;

  return (
    <section className="rounded-xl border bg-white p-5">
      <div className="flex items-end justify-between">
        <h2 className="text-xl font-bold">리뷰</h2>
        <button
          className="px-4 py-2 rounded-md bg-black text-white text-sm"
          onClick={() =>
            isAuthenticated
              ? navigate(`/products/${productId}/review/write`)
              : navigate("/login")
          }
        >
          리뷰 작성
        </button>
      </div>

      <div className="mt-4 flex items-center gap-2">
        <select
          value={query.sort}
          onChange={(e) => setQuery({ sort: e.target.value, page: 1 })}
          className="px-3 py-2 border rounded-md text-sm"
        >
          {SORT_OPTIONS.map((o) => (
            <option key={o.value} value={o.value}>
              {o.label}
            </option>
          ))}
        </select>
      </div>

      <div className="mt-5 space-y-3">
        {loading ? (
          <div className="text-center text-gray-500 py-8">불러오는 중...</div>
        ) : reviews.length ? (
          reviews.map((r) => {
            const reviewId = r.reviewId ?? r.id;
            const isMine = user && (r.userId === user.id);

            return (
              <div key={reviewId} className="p-4 border rounded-lg">
                <div className="flex justify-between">
                  <div className="font-semibold">
                    {r.authorName ?? "사용자"}
                  </div>
                  <div className="text-sm">
                    ⭐ {r.rating?.toFixed(1)}
                  </div>
                </div>

                {editingId === reviewId ? (
                  <>
                    <textarea
                      value={editContent}
                      onChange={(e) => setEditContent(e.target.value)}
                      className="mt-2 w-full border rounded-md p-2"
                    />
                    <div className="mt-2 flex gap-2">
                      <button
                        onClick={() => onSaveEdit(reviewId)}
                        className="px-3 py-1 bg-black text-white rounded-md text-sm"
                      >
                        저장
                      </button>
                      <button
                        onClick={onCancelEdit}
                        className="px-3 py-1 border rounded-md text-sm"
                      >
                        취소
                      </button>
                    </div>
                  </>
                ) : (
                  <>
                    <p className="mt-2 text-sm">{r.content}</p>

                    {isMine && (
                      <div className="mt-2 flex gap-2 text-sm">
                        <button
                          onClick={() => onStartEdit(r)}
                          className="text-blue-600"
                        >
                          수정
                        </button>
                        <button
                          onClick={() => onDelete(reviewId)}
                          className="text-red-600"
                        >
                          삭제
                        </button>
                      </div>
                    )}
                  </>
                )}
              </div>
            );
          })
        ) : (
          <div className="text-center text-gray-500 py-8">
            아직 리뷰가 없습니다.
          </div>
        )}
      </div>

      {totalPages > 1 && (
        <div className="mt-4 flex justify-center gap-2">
          <button
            disabled={currentPage <= 1}
            onClick={() => setQuery({ page: currentPage - 1 })}
            className="px-3 py-1 border rounded-md text-sm"
          >
            이전
          </button>
          <span className="text-sm">
            {currentPage} / {totalPages}
          </span>
          <button
            disabled={currentPage >= totalPages}
            onClick={() => setQuery({ page: currentPage + 1 })}
            className="px-3 py-1 border rounded-md text-sm"
          >
            다음
          </button>
        </div>
      )}
    </section>
  );
}