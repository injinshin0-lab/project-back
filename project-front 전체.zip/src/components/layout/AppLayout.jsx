// src/components/layout/AppLayout.jsx
import { Outlet } from "react-router-dom";
import AppHeader from "@/components/layout/AppHeader";

export default function AppLayout() {
  return (
    <div className="min-h-screen">
      <AppHeader />
      <main>
        <Outlet />
      </main>
    </div>
  );
}