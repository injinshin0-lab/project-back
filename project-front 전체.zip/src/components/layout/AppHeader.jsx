// src/components/layout/AppHeader.jsx
import { useEffect } from "react";
import { Link, useNavigate, useLocation } from "react-router-dom";
import toast from "react-hot-toast";

import useAuthStore from "@/stores/authStore";
import useCartStore from "@/stores/cartStore";
import useNotificationStore, {
  selectUnreadCount,
} from "@/stores/notificationStore";

function roleLabel(role) {
  return role === "ADMIN" ? "관리자" : "회원";
}

export default function AppHeader() {
  const navigate = useNavigate();
  const location = useLocation();

  // 스토어 상태
  const { user, isAuthenticated, logout } = useAuthStore();
  const items = useCartStore((s) => s.items);
  const fetchNotifications = useNotificationStore((s) => s.fetchNotifications);
  const unreadCount = useNotificationStore(selectUnreadCount);

  // 장바구니 수량 계산
  const cartCount = (items || []).reduce(
    (sum, it) => sum + (Number(it.quantity) || 0),
    0
  );

  // ✅ 로그인 상태일 때만 알림 데이터 조회 (Header 기능 통합)
  useEffect(() => {
    if (!isAuthenticated || !user) return;
    fetchNotifications(user);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isAuthenticated, user]);

  const onClickLogout = async () => {
    await logout();
    toast.success("로그아웃 되었습니다.");
    navigate("/login", { replace: true });
  };

  const displayName = user?.name || user?.loginId || user?.email || "사용자";

  const isActive = (path) => 
    location.pathname === path 
      ? "text-black font-extrabold border-b-[3px] border-black" 
      : "text-gray-500 hover:text-black font-semibold";

      return (
        <header className="sticky top-0 z-50 w-full bg-white/90 backdrop-blur-md border-b border-gray-200">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between items-center h-20 md:h-24 gap-4">
              
              {/* 1. 왼쪽: 로고 (공간 유지) */}
              <div className="flex-shrink-0 min-w-fit">
                <Link to="/bogam" className="text-2xl md:text-3xl font-black tracking-tighter text-black">
                  보감
                </Link>
              </div>
    
              {/* 2. 중앙: 네비게이션 (공간에 따라 간격 조절 및 자동 숨김) */}
              <nav className="hidden xl:flex items-center gap-10 flex-1 justify-center">
                <Link to="/products" className={`text-base md:text-lg py-2 transition-all ${isActive('/products')}`}>상품목록</Link>
                <Link to="/faqs" className={`text-base md:text-lg py-2 transition-all ${isActive('/faqs')}`}>FAQ</Link>
                <Link to="/carts" className={`text-base md:text-lg py-2 transition-all flex items-center gap-2 ${isActive('/carts')}`}>
                  장바구니
                  {cartCount > 0 && (
                    <span className="bg-red-500 text-white text-[10px] px-1.5 py-0.5 rounded-full font-bold">{cartCount}</span>
                  )}
                </Link>
                <Link to="/mypage" className={`text-base md:text-lg py-2 transition-all ${isActive('/mypage')}`}>마이페이지</Link>
              </nav>
    
              {/* 3. 오른쪽: 사용자 영역 (유연하게 조절) */}
              <div className="flex items-center gap-2 sm:gap-4 md:gap-6 flex-shrink-0">
                
                {/* 알림 벨 아이콘 */}
                {isAuthenticated && (
                  <button
                    type="button"
                    onClick={() => navigate("/mypage/notifications")}
                    className="relative p-2 text-gray-600 hover:bg-gray-100 rounded-full transition-all"
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" className="w-6 h-6 md:w-7 md:h-7" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V4a2 2 0 10-4 0v1.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0a3 3 0 01-6 0" />
                    </svg>
                    {unreadCount > 0 && (
                      <span className="absolute top-1 right-1 min-w-[16px] h-[16px] px-1 rounded-full bg-red-600 text-white text-[9px] font-bold flex items-center justify-center border border-white">
                        {unreadCount > 99 ? "99+" : unreadCount}
                      </span>
                    )}
                  </button>
                )}
    
                {isAuthenticated ? (
                  <div className="flex items-center gap-2 sm:gap-4">
                    {/* 사용자 정보 (작은 화면에선 숨김) */}
                    <div className="hidden sm:flex flex-col items-end leading-tight">
                      <span className="text-xs md:text-sm font-bold text-black truncate max-w-[80px]">{displayName}님</span>
                      <span className="text-[10px] md:text-xs text-gray-400">{roleLabel(user?.role)}</span>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      {user?.role === "ADMIN" && (
                        <Link to="/admin" className="text-[11px] md:text-sm font-bold px-3 py-1.5 md:px-4 md:py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors whitespace-nowrap">
                          관리자
                        </Link>
                      )}
                      <button 
                        onClick={onClickLogout}
                        className="text-[11px] md:text-sm font-bold text-gray-500 hover:text-black border border-gray-200 px-3 py-1.5 md:px-4 md:py-2 rounded-lg whitespace-nowrap"
                      >
                        로그아웃
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="flex items-center gap-2 sm:gap-3">
                    <Link to="/login" className="text-sm md:text-base font-bold px-3 py-2 text-gray-700 hover:text-black">
                      로그인
                    </Link>
                    <Link to="/signup" className="text-sm md:text-base font-bold px-4 py-2 md:px-7 md:py-2.5 bg-black text-white rounded-full shadow-md">
                      회원가입
                    </Link>
                  </div>
                )}
              </div>
    
            </div>
          </div>
        </header>
      );
    }