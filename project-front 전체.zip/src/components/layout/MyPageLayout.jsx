// src/components/layout/MyPageLayout.jsx
import { Link, Outlet, useLocation, useNavigate } from "react-router-dom";
import toast from "react-hot-toast";
import useAuthStore from "@/stores/authStore";

export default function MyPageLayout() {
  const navigate = useNavigate();
  const location = useLocation();
  const { user, logout, isAuthenticated } = useAuthStore();

  const onLogout = async () => {
    if (!window.confirm("로그아웃 하시겠습니까?")) return;
    await logout();
    toast.success("로그아웃 되었습니다.");
    navigate("/login", { replace: true });
  };

  if (!isAuthenticated) {
    return (
      <div className="py-20 text-center">
        <p className="text-gray-500 mb-4">로그인이 필요한 서비스입니다.</p>
        <button onClick={() => navigate("/login")} className="px-6 py-2 bg-black text-white rounded-lg">로그인하기</button>
      </div>
    );
  }

  // 메뉴 정의
  const menuItems = [
    { path: "/mypage/profile", label: "내 정보 수정" },
    { path: "/mypage/orders", label: "주문 내역" },
    { path: "/mypage/addresses", label: "주소록 관리" },
    { path: "/mypage/reviews", label: "내가 쓴 리뷰" },
    { path: "/mypage/notifications", label: "알림함" },
    { path: "/mypage/signout", label: "회원 탈퇴" },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 py-10 flex flex-col md:flex-row gap-8">
      {/* 사이드바 */}
      <aside className="w-full md:w-64 flex-shrink-0">
        <div className="p-6 bg-gray-50 rounded-2xl border border-gray-100">
          <div className="mb-6">
            <h2 className="text-xl font-bold text-gray-900">{user?.name || "사용자"}님</h2>
            <p className="text-sm text-gray-500">{user?.email}</p>
          </div>
          
          <nav className="space-y-1">
            {menuItems.map((item) => (
              <Link
                key={item.path}
                to={item.path}
                className={`block px-4 py-3 rounded-xl text-sm font-medium transition-colors ${
                  location.pathname === item.path
                    ? "bg-black text-white"
                    : "text-gray-600 hover:bg-white hover:shadow-sm"
                }`}
              >
                {item.label}
              </Link>
            ))}
          </nav>

          <button
            onClick={onLogout}
            className="w-full mt-8 px-4 py-3 text-sm font-medium text-red-500 border border-red-100 rounded-xl hover:bg-red-50 transition-colors"
          >
            로그아웃
          </button>
        </div>
      </aside>

      {/* 우측 콘텐츠 영역 */}
      <main className="flex-1 bg-white p-6 rounded-2xl border border-gray-100 min-h-[500px]">
        <Outlet />
      </main>
    </div>
  );
}