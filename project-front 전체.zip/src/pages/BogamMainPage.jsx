import { Link, useNavigate } from 'react-router-dom';
import { useEffect, useState } from 'react';
import useProductStore from '@/stores/productStore'; // ✅ 스토어 임포트
import '../pages/bogamMain.css';

export default function BogamMainPage() {
  const navigate = useNavigate();
  const [q, setQ] = useState('');

  // ✅ 스토어에서 필요한 상태와 액션 가져오기
  const { 
    products, 
    fetchProducts, 
    listLoading 
  } = useProductStore();

  // ✅ 컴포넌트 마운트 시 데이터 페칭
  useEffect(() => {
    // 메인 페이지용 추천 상품 (최신순 4개 등)
    fetchProducts({ size: 4, sort: 'latest' });
  }, [fetchProducts]);

  const onSubmitSearch = (e) => {
    e.preventDefault();
    const keyword = q.trim();
    if (!keyword) return;

    // ✅ 요구서: /search (검색 결과)
    // ✅ 검색어를 쿼리스트링으로 전달해두면 SearchPage에서 그대로 사용 가능
    const params = new URLSearchParams();
    params.set('q', keyword);
    navigate(`/search?${params.toString()}`);
  };

  return (
    <div className="bogam-page">

      {/* 히어로 */}
      <section className="bogam-hero">
        <h1>건강한 선택, 보감</h1>
        <p>오늘의 추천 상품을 빠르게 찾아보세요.</p>
        <form className="bogam-search" onSubmit={onSubmitSearch}>
          <input
            className="search-input"
            placeholder="찾으시는 건강 식품이 있나요?"
            value={q}
            onChange={(e) => setQ(e.target.value)}
          />
          <button className="search-btn" type="submit">검색</button>
        </form>
      </section>

      {/* ✅ 카테고리 섹션 (필요 시 API 연동 가능, 현재는 상품 페이지 이동) */}
      <section className="bogam-section">
        <h2>인기 카테고리</h2>
        <div className="grid">
          {['면역/홍삼', '비타민', '유산균', '다이어트'].map((cat) => (
            <button 
              key={cat} 
              className="card" 
              onClick={() => navigate(`/products?keyword=${cat}`)}
            >
              {cat}
            </button>
          ))}
        </div>
      </section>

      {/* ✅ 실제 상품 데이터 렌더링 */}
      <section className="bogam-section">
        <h2>오늘의 추천</h2>
        {listLoading ? (
          <div className="loading-text">상품을 불러오는 중입니다...</div>
        ) : (
          <div className="grid">
            {products.length > 0 ? (
              products.map((product) => (
                <div key={product.productId} className="product">
                  {/* 이미지 URL이 있다면 src에 넣으세요 */}
                  <div className="thumb" style={{ backgroundImage: `url(${product.imageUrl})`, backgroundColor: '#f0f0f0' }} />
                  <div className="p-title">{product.productName}</div>
                  <div className="p-sub">{product.content || '최고의 선택'}</div>
                  <div className="p-price" style={{ fontWeight: 'bold', margin: '5px 0' }}>
                    {product.price?.toLocaleString()}원
                  </div>
                  <Link to={`/products/${product.productId}`} className="p-link">상세 보기</Link>
                </div>
              ))
            ) : (
              <div className="empty-text">등록된 상품이 없습니다.</div>
            )}
          </div>
        )}
      </section>

      <footer className="bogam-footer">
        <p>© Bogam. All rights reserved.</p>
      </footer>
    </div>
  );
}