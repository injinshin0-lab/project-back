export default function FaqPage() {
  return (
    <div style={{ padding: 24 }}>
      <h1>FAQ</h1>
      <p>/faq</p>
    </div>
  );
}