// src/pages/admin/AdminNotificationHistoryPage.jsx
import { useEffect, useState } from "react";

export default function AdminNotificationHistoryPage() {
  const [list, setList] = useState([]);

  useEffect(() => {
    // ⚠️ 지금은 API가 없으므로 임시 데이터
    // 나중에 GET /api/v1/admin/notifications 같은 API 나오면 여기만 교체
    setList([
      {
        id: 1,
        sentAt: "2026-01-08 10:30",
        target: "전체",
        title: "공지",
        message: "설 연휴 배송 일정 안내",
        sender: "관리자",
      },
      {
        id: 2,
        sentAt: "2026-01-07 18:10",
        target: "특정 사용자(3명)",
        title: "문의 답변",
        message: "1:1 문의 답변 알림",
        sender: "관리자",
      },
    ]);
  }, []);

  return (
    <div
      style={{
        border: "1px solid #ddd",
        borderRadius: 14,
        background: "#fff",
        overflow: "hidden",
      }}
    >
      <div
        style={{
          padding: 12,
          fontWeight: 900,
          borderBottom: "1px solid #eee",
        }}
      >
        발송 내역
      </div>

      {list.length === 0 ? (
        <div style={{ padding: 14, color: "#666" }}>
          발송 내역이 없습니다.
        </div>
      ) : (
        list.map((row) => (
          <div
            key={row.id}
            style={{
              padding: 12,
              borderBottom: "1px solid #eee",
            }}
          >
            <div style={{ fontWeight: 800 }}>
              {row.title ? `[${row.title}] ` : ""}
              {row.message}
            </div>
            <div
              style={{
                fontSize: 12,
                color: "#666",
                marginTop: 4,
              }}
            >
              발송일: {row.sentAt} · 대상: {row.target} · 발송자:{" "}
              {row.sender}
            </div>
          </div>
        ))
      )}
    </div>
  );
}