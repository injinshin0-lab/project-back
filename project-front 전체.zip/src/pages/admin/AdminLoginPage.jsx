import { useEffect, useState } from "react";
import { useNavigate, useLocation, Link } from "react-router-dom";
import toast from "react-hot-toast";

import { loginApi } from "@/api/authApi";
import useAuthStore from "@/stores/authStore";

const STORAGE_KEYS = {
  SAVE_ID: "SAVE_LOGIN_ID",
  AUTO_LOGIN: "AUTO_LOGIN",
};

export default function AdminLoginPage() {
  const navigate = useNavigate();
  const location = useLocation();

  const login = useAuthStore((s) => s.login);
  const logout = useAuthStore((s) => s.logout);

  const [form, setForm] = useState({ loginId: "", password: "" });
  const [options, setOptions] = useState({ saveId: false, autoLogin: false });
  const [loading, setLoading] = useState(false);

  // 저장된 아이디 복원
  useEffect(() => {
    const savedId = localStorage.getItem(STORAGE_KEYS.SAVE_ID);
    if (savedId) {
      setForm((prev) => ({ ...prev, loginId: savedId }));
      setOptions((prev) => ({ ...prev, saveId: true }));
    }
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const handleOptionChange = (e) => {
    const { name, checked } = e.target;
    setOptions((prev) => ({ ...prev, [name]: checked }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const loginId = form.loginId.trim();
    const password = form.password;

    if (!loginId || !password) {
      toast.error("아이디와 비밀번호를 입력해주세요.");
      return;
    }

    try {
      setLoading(true);

      const payload = { loginId, password };
      const res = await loginApi(payload);
      const user = res.data?.user ?? res.data;

      // ✅ 아이디 저장
      if (options.saveId) localStorage.setItem(STORAGE_KEYS.SAVE_ID, loginId);
      else localStorage.removeItem(STORAGE_KEYS.SAVE_ID);

      // ✅ 자동로그인 플래그만 저장(토큰 저장 X)
      if (options.autoLogin) localStorage.setItem(STORAGE_KEYS.AUTO_LOGIN, "true");
      else localStorage.removeItem(STORAGE_KEYS.AUTO_LOGIN);

      // ✅ authStore 로그인 반영
      login(user);

      // ✅ 관리자 권한 체크 (ERD: Bg_User.role = USER/ADMIN)
      if (user?.role !== "ADMIN") {
        toast.error("관리자 계정이 아닙니다.");
        // 자동로그인 플래그도 남기지 않도록 즉시 제거
        localStorage.removeItem(STORAGE_KEYS.AUTO_LOGIN);
        await logout();
        return;
      }

      toast.success("관리자 로그인 성공");

      // 원래 가려던 관리자 페이지가 있으면 거기로
      const next = location.state?.from || "/admin";
      navigate(next, { replace: true });
    } catch (err) {
      const data = err?.response?.data;
      const msg =
        (data && (data.message || data.error)) ||
        "로그인에 실패했습니다.";
      toast.error(msg);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ minHeight: "100vh", display: "grid", placeItems: "center", padding: 16 }}>
      <form
        onSubmit={handleSubmit}
        style={{
          width: "100%",
          maxWidth: 420,
          border: "1px solid #eee",
          borderRadius: 12,
          padding: 20,
          background: "white",
        }}
      >
        <h1 style={{ marginBottom: 12 }}>관리자 로그인</h1>

        <input
          name="loginId"
          type="text"
          placeholder="아이디"
          value={form.loginId}
          onChange={handleChange}
          disabled={loading}
          style={{ width: "100%", padding: 12, marginBottom: 10 }}
        />

        <input
          name="password"
          type="password"
          placeholder="비밀번호"
          value={form.password}
          onChange={handleChange}
          disabled={loading}
          style={{ width: "100%", padding: 12, marginBottom: 12 }}
        />

        <div style={{ display: "flex", gap: 16, marginBottom: 6 }}>
          <label style={{ display: "flex", gap: 6, alignItems: "center" }}>
            <input
              type="checkbox"
              name="autoLogin"
              checked={options.autoLogin}
              onChange={handleOptionChange}
              disabled={loading}
            />
            로그인 상태 유지
          </label>

          <label style={{ display: "flex", gap: 6, alignItems: "center" }}>
            <input
              type="checkbox"
              name="saveId"
              checked={options.saveId}
              onChange={handleOptionChange}
              disabled={loading}
            />
            아이디 저장
          </label>
        </div>

        <p style={{ fontSize: 12, color: "#888", marginTop: 4, marginBottom: 12 }}>
          ※ 공용 PC에서는 아이디 저장을 권장하지 않습니다.
        </p>

        <button type="submit" disabled={loading} style={{ width: "100%", padding: 12 }}>
          {loading ? "로그인 중…" : "관리자 로그인"}
        </button>

        <div style={{ marginTop: 12, fontSize: 13, color: "#666" }}>
          <Link to="/bogam">← 쇼핑으로 돌아가기</Link>
        </div>
      </form>
    </div>
  );
}