// src/pages/admin/AdminNotificationsPage.jsx
import { useState } from "react";

import AdminNotificationSendPage from "@/pages/admin/AdminNotificationSendPage";
import AdminNotificationHistoryPage from "@/pages/admin/AdminNotificationHistoryPage";

export default function AdminNotificationsPage() {
  const [tab, setTab] = useState("send"); // send | history

  return (
    <div style={{ padding: 16 }}>
      <h2
        style={{
          fontSize: 22,
          fontWeight: 900,
          marginBottom: 12,
        }}
      >
        관리자 알림 관리
      </h2>

      {/* 탭 버튼 */}
      <div style={{ display: "flex", gap: 8, marginBottom: 16 }}>
        <TabButton active={tab === "send"} onClick={() => setTab("send")}>
          알림 발송
        </TabButton>
        <TabButton
          active={tab === "history"}
          onClick={() => setTab("history")}
        >
          발송 내역
        </TabButton>
      </div>

      {/* 탭 내용 */}
      {tab === "send" && <AdminNotificationSendPage />}
      {tab === "history" && <AdminNotificationHistoryPage />}
    </div>
  );
}

function TabButton({ active, children, onClick }) {
  return (
    <button
      type="button"
      onClick={onClick}
      style={{
        padding: "10px 14px",
        borderRadius: 10,
        border: "1px solid #333",
        background: active ? "#111" : "#fff",
        color: active ? "#fff" : "#111",
        fontWeight: 800,
        cursor: "pointer",
      }}
    >
      {children}
    </button>
  );
}