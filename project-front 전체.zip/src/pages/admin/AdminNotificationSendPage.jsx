// src/pages/admin/AdminNotificationSendPage.jsx
import { useMemo, useState } from "react";
import toast from "react-hot-toast";

import { sendAdminNotificationApi } from "@/api/adminNotificationApi";

export default function AdminNotificationSendPage() {
  const [loading, setLoading] = useState(false);

  const [form, setForm] = useState({
    targetType: "ALL", // ALL | USER | GROUP
    userIdsText: "",   // "1,2,3"
    groupKey: "",      // 예: ROLE:USER / CATEGORY:15 등 (백엔드 규칙에 맞춰)
    title: "",
    message: "",
  });

  const payload = useMemo(() => {
    const p = {
      targetType: form.targetType,
      title: form.title.trim() || undefined,
      message: form.message.trim(),
    };

    if (form.targetType === "USER") {
      const ids = form.userIdsText
        .split(",")
        .map((v) => v.trim())
        .filter(Boolean)
        .map((v) => Number(v))
        .filter((n) => Number.isFinite(n));
      p.userIds = ids;
    }

    if (form.targetType === "GROUP") {
      p.groupKey = form.groupKey.trim() || undefined;
    }

    return p;
  }, [form]);

  const onSubmit = async () => {
    if (!payload.message) return toast.error("메시지를 입력하세요.");

    if (payload.targetType === "USER" && (!payload.userIds || payload.userIds.length === 0)) {
      return toast.error("USER 타깃은 userIds가 필요합니다. (예: 1,2,3)");
    }

    if (payload.targetType === "GROUP" && !payload.groupKey) {
      return toast.error("GROUP 타깃은 groupKey가 필요합니다. (예: ROLE:USER)");
    }

    try {
      setLoading(true);
      await sendAdminNotificationApi(payload);
      toast.success("알림 발송 완료");

      setForm((prev) => ({
        ...prev,
        title: "",
        message: "",
        userIdsText: "",
        groupKey: "",
      }));
    } catch (e) {
      toast.error("알림 발송 실패");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ padding: 16, maxWidth: 860 }}>
      <h2 style={{ fontSize: 20, fontWeight: 700, marginBottom: 12 }}>알림 발송</h2>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 2fr", gap: 12 }}>
        <div style={{ fontWeight: 700, paddingTop: 10 }}>타깃</div>
        <select
          value={form.targetType}
          onChange={(e) => setForm((prev) => ({ ...prev, targetType: e.target.value }))}
          style={{ padding: 10, border: "1px solid #ccc", borderRadius: 8 }}
        >
          <option value="ALL">전체</option>
          <option value="GROUP">특정 그룹</option>
          <option value="USER">특정 사용자</option>
        </select>

        {form.targetType === "USER" && (
          <>
            <div style={{ fontWeight: 700, paddingTop: 10 }}>userIds</div>
            <input
              value={form.userIdsText}
              onChange={(e) => setForm((prev) => ({ ...prev, userIdsText: e.target.value }))}
              placeholder="예: 1,2,3"
              style={{ padding: 10, border: "1px solid #ccc", borderRadius: 8 }}
            />
          </>
        )}

        {form.targetType === "GROUP" && (
          <>
            <div style={{ fontWeight: 700, paddingTop: 10 }}>groupKey</div>
            <input
              value={form.groupKey}
              onChange={(e) => setForm((prev) => ({ ...prev, groupKey: e.target.value }))}
              placeholder="예: ROLE:USER 또는 CATEGORY:15"
              style={{ padding: 10, border: "1px solid #ccc", borderRadius: 8 }}
            />
          </>
        )}

        <div style={{ fontWeight: 700, paddingTop: 10 }}>제목(선택)</div>
        <input
          value={form.title}
          onChange={(e) => setForm((prev) => ({ ...prev, title: e.target.value }))}
          placeholder="제목(선택)"
          style={{ padding: 10, border: "1px solid #ccc", borderRadius: 8 }}
        />

        <div style={{ fontWeight: 700, paddingTop: 10 }}>메시지</div>
        <textarea
          value={form.message}
          onChange={(e) => setForm((prev) => ({ ...prev, message: e.target.value }))}
          placeholder="발송할 메시지"
          rows={8}
          style={{ padding: 10, border: "1px solid #ccc", borderRadius: 8, resize: "vertical" }}
        />

        <div />
        <button
          onClick={onSubmit}
          disabled={loading}
          style={{
            padding: "10px 14px",
            borderRadius: 8,
            border: "1px solid #333",
            background: "#fff",
            fontWeight: 700,
            cursor: "pointer",
          }}
        >
          발송
        </button>
      </div>

      <div style={{ marginTop: 16, fontSize: 12, color: "#666", lineHeight: 1.6 }}>
        ※ payload 필드명은 백엔드 DTO에 따라 다를 수 있어요.  
        네트워크에서 400 뜨면 “요청 body 키”만 DTO에 맞게 바꾸면 바로 해결됩니다.
      </div>
    </div>
  );
}