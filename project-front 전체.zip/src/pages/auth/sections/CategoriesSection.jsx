// src/components/auth/signup/CategoriesSection.jsx
import { useEffect, useMemo, useState } from "react";
import useCategoryStore from "@/stores/categoryStore";

function cls(...args) {
  return args.filter(Boolean).join(" ");
}

function ListBox({ title, items, selectedId, onSelect }) {
  return (
    <div className="border rounded-xl bg-white overflow-hidden">
      <div className="px-3 py-2 border-b text-sm font-semibold">{title}</div>
      <div className="max-h-[280px] overflow-auto">
        {(!items || items.length === 0) && (
          <div className="px-3 py-3 text-sm opacity-60">목록이 없습니다.</div>
        )}

        {items?.map((it) => {
          const active = selectedId === it.id;
          return (
            <button
              key={it.id}
              type="button"
              onClick={() => onSelect(it)}
              className={cls(
                "w-full text-left px-3 py-2 text-sm border-b last:border-b-0",
                active ? "bg-gray-100 font-semibold" : "hover:bg-gray-50"
              )}
            >
              {it.name}
            </button>
          );
        })}
      </div>
    </div>
  );
}

export default function CategoriesSection() {
  const tree = useCategoryStore((s) => s.tree); // 대분류 루트 배열
  const loading = useCategoryStore((s) => s.loading);
  const fetchCategories = useCategoryStore((s) => s.fetchCategories);

  const selectedIds = useCategoryStore((s) => s.selectedIds);
  const setSelectedIds = useCategoryStore((s) => s.setSelectedIds);
  const toggleSelectedId = useCategoryStore((s) => s.toggleSelectedId);
  const maxSelect = useCategoryStore((s) => s.maxSelect);

  // ✅ 캐스케이드 선택 상태(대/중)
  const [big, setBig] = useState(null);
  const [mid, setMid] = useState(null);

  useEffect(() => {
    // 카테고리 없으면 1회 로드
    if (!tree || tree.length === 0) fetchCategories();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // 대/중/소 목록 구성
  const bigList = useMemo(() => tree ?? [], [tree]);

  const midList = useMemo(() => {
    if (!big) return [];
    return big.children ?? [];
  }, [big]);

  const smallList = useMemo(() => {
    if (!mid) return [];
    return mid.children ?? [];
  }, [mid]);

  // ✅ tree 로드되면 기본으로 첫 대분류 자동 선택(원하면 제거 가능)
  useEffect(() => {
    if (!big && bigList.length > 0) {
      setBig(bigList[0]);
      setMid(null);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [bigList.length]);

  // ✅ 대분류 바꾸면 중분류/소분류 초기화
  const onSelectBig = (node) => {
    setBig(node);
    setMid(null);
  };

  // ✅ 중분류 바꾸면 소분류 목록만 변경(선택값은 유지)
  const onSelectMid = (node) => {
    setMid(node);
  };

  // ✅ 소분류(leaf) 선택/해제 (복수 선택)
  const onToggleSmall = (id) => {
    toggleSelectedId(id);
  };

  // 선택된 소분류 chip 목록(이름 표시용)
  const leafNameMap = useMemo(() => {
    const map = new Map();
    const dfs = (n) => {
      map.set(n.id, n.name);
      n.children?.forEach(dfs);
    };
    bigList.forEach(dfs);
    return map;
  }, [bigList]);

  const selectedChips = useMemo(() => {
    return (selectedIds ?? []).map((id) => ({
      id,
      name: leafNameMap.get(id) ?? String(id),
    }));
  }, [selectedIds, leafNameMap]);

  const removeChip = (id) => {
    const next = (selectedIds ?? []).filter((x) => x !== id);
    setSelectedIds(next);
  };

  return (
    <section className="border rounded-xl p-4 bg-white">
      <div className="flex items-center justify-between mb-3">
        <div className="font-semibold">관심 카테고리</div>
        <div className="text-xs opacity-70">
          {selectedIds.length}/{maxSelect}
        </div>
      </div>

      {loading && <div className="text-sm">불러오는 중...</div>}

      {!loading && (!tree || tree.length === 0) && (
        <div className="text-sm opacity-70">카테고리가 없습니다.</div>
      )}

      {!loading && tree?.length > 0 && (
        <>
          {/* ✅ 캐스케이드 3단 */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <ListBox
              title="대분류"
              items={bigList}
              selectedId={big?.id ?? null}
              onSelect={onSelectBig}
            />

            <ListBox
              title="중분류"
              items={midList}
              selectedId={mid?.id ?? null}
              onSelect={onSelectMid}
            />

            <div className="border rounded-xl bg-white overflow-hidden">
              <div className="px-3 py-2 border-b text-sm font-semibold">소분류</div>
              <div className="max-h-[280px] overflow-auto">
                {!mid && (
                  <div className="px-3 py-3 text-sm opacity-60">
                    중분류를 선택하면 소분류가 보여요.
                  </div>
                )}

                {mid && smallList.length === 0 && (
                  <div className="px-3 py-3 text-sm opacity-60">소분류가 없습니다.</div>
                )}

                {mid &&
                  smallList.map((leaf) => {
                    const checked = selectedIds.includes(leaf.id);
                    const disabled =
                      !checked && selectedIds.length >= (maxSelect ?? 10);

                    return (
                      <label
                        key={leaf.id}
                        className={cls(
                          "flex items-center gap-2 px-3 py-2 border-b last:border-b-0 text-sm",
                          disabled ? "opacity-50 cursor-not-allowed" : "cursor-pointer hover:bg-gray-50"
                        )}
                      >
                        <input
                          type="checkbox"
                          checked={checked}
                          disabled={disabled}
                          onChange={() => onToggleSmall(leaf.id)}
                        />
                        <span>{leaf.name}</span>
                      </label>
                    );
                  })}
              </div>
            </div>
          </div>

          {/* ✅ 선택된 소분류 표시 */}
          <div className="mt-3">
            <div className="text-sm font-semibold mb-2">선택한 소분류</div>
            {selectedChips.length === 0 ? (
              <div className="text-sm opacity-60">아직 선택한 항목이 없습니다.</div>
            ) : (
              <div className="flex flex-wrap gap-2">
                {selectedChips.map((c) => (
                  <button
                    key={c.id}
                    type="button"
                    onClick={() => removeChip(c.id)}
                    className="text-sm border rounded-full px-3 py-1 bg-gray-50 hover:bg-gray-100"
                    title="클릭하면 제거"
                  >
                    {c.name} ✕
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* 안내 */}
          <div className="mt-3 text-xs opacity-60">
            대분류 → 중분류 → 소분류 순서로 선택하고, 소분류는 최대 {maxSelect}개까지 선택할 수 있어요.
          </div>
        </>
      )}
    </section>
  );
}