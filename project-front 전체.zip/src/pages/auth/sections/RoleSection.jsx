// src/pages/auth/sections/RoleSection.jsx
export default function RoleSection({ form, setForm }) {
  const role = form?.role || "USER";
  const isAdmin = role === "ADMIN";

  const setRole = (nextRole) => {
    setForm((prev) => ({
      ...prev,
      role: nextRole,
    }));
  };

  return (
    <section className="mt-6 rounded-2xl border bg-white p-5">
      <div className="text-lg font-bold">가입 유형</div>
      <p className="mt-1 text-sm text-gray-600">
        회원가입 시 가입 유형을 선택할 수 있어요.
      </p>

      <div className="mt-4 flex flex-col gap-3">
        <label className="flex items-center gap-3">
          <input
            type="radio"
            name="role"
            checked={!isAdmin}
            onChange={() => setRole("USER")}
          />
          <div>
            <div className="font-medium">일반 회원</div>
            <div className="text-xs text-gray-500">
              상품 구매/리뷰/장바구니/마이페이지 이용
            </div>
          </div>
        </label>

        <label className="flex items-center gap-3">
          <input
            type="radio"
            name="role"
            checked={isAdmin}
            onChange={() => setRole("ADMIN")}
          />
          <div>
            <div className="font-medium">관리자</div>
            <div className="text-xs text-gray-500">
              관리자 페이지 접근 권한이 필요할 때 선택
            </div>
          </div>
        </label>

        {isAdmin ? (
          <div className="mt-2 rounded-xl border bg-gray-50 p-3 text-xs text-gray-700">
            ⚠️ 관리자 권한은 백엔드에서 최종 검증해야 안전합니다. (지금은 프론트/가입 단계에서 role을
            포함시키는 1차 작업)
          </div>
        ) : null}
      </div>
    </section>
  );
}