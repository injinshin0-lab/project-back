export default function FindPasswordPage() {
  return (
    <div style={{ padding: 24 }}>
      <h1>비밀번호 찾기</h1>
      <p>/find/password</p>
    </div>
  );
}