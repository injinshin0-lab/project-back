// src/components/auth/SignupForm.jsx
import { useEffect, useMemo, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import toast from "react-hot-toast";

import { registerApi, sendEmailCodeApi, verifyEmailCodeApi, checkLoginIdApi } from "@/api/authApi";
import { getCategoriesApi } from "@/api/categoryApi";
import loadDaumPostcode from "@/utils/loadDaumPostcode";

// 분리 컴포넌트들
import LoginIdSection from "@/components/auth/signup/LoginIdSection";
import PasswordSection from "@/components/auth/signup/PasswordSection";
import ProfileSection from "@/components/auth/signup/ProfileSection";
import EmailVerificationSection from "@/components/auth/signup/EmailVerificationSection";
import AddressSection from "@/components/auth/signup/AddressSection";
import CategoriesSection from "@/components/auth/signup/CategoriesSection";
import AgreementSection from "@/components/auth/signup/AgreementSection";
import RoleSection from "@/pages/auth/sections/RoleSection";

export default function SignupForm() {
  const navigate = useNavigate();

  // =========================
  // form state (기존 그대로)
  // =========================
  const [form, setForm] = useState({
    loginId: "",
    password: "",
    confirmPassword: "",
    name: "",
    email: "",
    phone: "",
    postcode: "",
    address1: "",
    address2: "",
    categories: [], // ✅ 필수
    agree: false,
  });

  // UI states
  const [showPw, setShowPw] = useState(false);
  const [showConfirmPw, setShowConfirmPw] = useState(false);

  // categories
  const [categories, setCategories] = useState([]);
  const [categoriesLoading, setCategoriesLoading] = useState(false);

  // loginId check
  const [isCheckingLoginId, setIsCheckingLoginId] = useState(false);
  const [loginIdCheck, setLoginIdCheck] = useState({
    checked: false,
    available: false,
    message: "",
    loginId: "",
  });

  // email verify
  const [emailCode, setEmailCode] = useState("");
  const [emailSent, setEmailSent] = useState(false);
  const [emailVerified, setEmailVerified] = useState(false);
  const [isSendingEmail, setIsSendingEmail] = useState(false);
  const [isVerifyingEmail, setIsVerifyingEmail] = useState(false);

  // submit
  const [isSubmitting, setIsSubmitting] = useState(false);

  // =========================
  // effects
  // =========================
  useEffect(() => {
    const fetch = async () => {
      setCategoriesLoading(true);
      try {
        const res = await getCategoriesApi();
        const data = res?.data?.data ?? res?.data ?? [];
        setCategories(Array.isArray(data) ? data : []);
      } catch (e) {
        toast.error("카테고리 목록을 불러오지 못했습니다.");
      } finally {
        setCategoriesLoading(false);
      }
    };
    fetch();
  }, []);

  // loginId가 바뀌면 중복확인 상태 reset (기존 유지 스타일)
  useEffect(() => {
    setLoginIdCheck((prev) => ({
      ...prev,
      checked: false,
      available: false,
      message: "",
      loginId: "",
    }));
  }, [form.loginId]);

  // email이 바뀌면 인증상태 reset
  useEffect(() => {
    setEmailSent(false);
    setEmailVerified(false);
    setEmailCode("");
  }, [form.email]);

  // =========================
  // handlers (기존 유지)
  // =========================
  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const handleToggleAgree = () => {
    setForm((prev) => ({ ...prev, agree: !prev.agree }));
  };

  const toggleCategory = (id) => {
    setForm((prev) => {
      const exists = prev.categories.includes(id);
      const next = exists
        ? prev.categories.filter((x) => x !== id)
        : [...prev.categories, id];
      return { ...prev, categories: next };
    });
  };

  const onSearchAddress = async () => {
    try {
      await loadDaumPostcode();

      // 2. window.daum.Postcode가 존재하는지 확인 후 실행
      if (!window.daum || !window.daum.Postcode) {
        throw new Error("우편번호 서비스를 불러올 수 없습니다.");
      }

      new window.daum.Postcode({
        oncomplete: (data) => {
          // data 객체에서 필요한 정보를 추출합니다.
          // 도로명 주소(roadAddress) 또는 지번 주소(jibunAddress)
          let fullAddress = data.address;
          let extraAddress = "";

          if (data.addressType === "R") {
            if (data.bname !== "") extraAddress += data.bname;
            if (data.buildingName !== "") {
              extraAddress += extraAddress !== "" ? `, ${data.buildingName}` : data.buildingName;
            }
            fullAddress += extraAddress !== "" ? ` (${extraAddress})` : "";
          }

          // 3. 폼 상태 업데이트
          setForm((prev) => ({
            ...prev,
            postcode: data.zonecode, // 우편번호
            address1: fullAddress,   // 기본주소
          }));
        },
      }).open(); // 팝업창 열기

    } catch (error) {
      console.error(error);
      toast.error("주소 검색창을 띄우는 데 실패했습니다.");
    }
  };

  // ✅ 아이디 중복확인 수정 버전
  const runLoginIdCheck = async () => {
    const loginId = form.loginId.trim();
    if (!loginId) {
      toast.error("아이디를 입력해주세요.");
      return;
    }

    setIsCheckingLoginId(true);
    try {
      const res = await checkLoginIdApi(loginId);
      // 200 OK인 경우 (사용 가능)
      const message = typeof res.data === "string" ? res.data : (res.data?.message ?? "사용 가능한 아이디입니다.");

      setLoginIdCheck({
        checked: true,
        available: true,
        message: message,
        loginId,
      });
      toast.success(message);

    } catch (e) {
      // ✅ 서버가 409 Conflict 등을 던지면 이쪽으로 들어옵니다.
      const errorResponse = e.response;
      let errorMessage = "아이디 중복확인에 실패했습니다.";

      if (errorResponse) {
        // 서버에서 보낸 "이미 존재하는 아이디입니다." 메시지를 추출
        errorMessage = typeof errorResponse.data === "string" 
          ? errorResponse.data 
          : (errorResponse.data?.message ?? errorMessage);
      }

      setLoginIdCheck({
        checked: true,
        available: false, // 사용 불가
        message: errorMessage,
        loginId,
      });
      
      // 사용자에게 서버가 보낸 메시지("이미 존재하는 아이디입니다.")를 토스트로 알림
      toast.error(errorMessage);
    } finally {
      setIsCheckingLoginId(false);
    }
  };

  // ✅ 이메일 인증: send
  const sendEmail = async () => {
    const email = form.email.trim();
    if (!email) {
      toast.error("이메일을 입력해주세요.");
      return;
    }

    setIsSendingEmail(true);
    try {
      await sendEmailCodeApi(email);
      setEmailSent(true);
      setEmailVerified(false);
      toast.success("인증번호를 발송했습니다.");
    } catch (e) {
      toast.error("인증번호 발송에 실패했습니다.");
    } finally {
      setIsSendingEmail(false);
    }
  };

  // 인증코드 정규화(공백 제거, 숫자만, 6자리)
  const normalizeCode = (v) => (v || "").replace(/\s/g, "").replace(/[^0-9]/g, "").slice(0, 6);

  const onChangeEmailCode = (e) => {
    setEmailCode(normalizeCode(e.target.value));
  };

  // ✅ 이메일 인증: verify
  const verifyEmail = async () => {
    const email = form.email.trim();
    const code = normalizeCode(emailCode);

    if (!emailSent) {
      toast.error("먼저 인증번호를 발송해주세요.");
      return;
    }
    if (code.length !== 6) {
      toast.error("인증번호 6자리를 입력해주세요.");
      return;
    }

    setIsVerifyingEmail(true);
    try {
      await verifyEmailCodeApi({ email, code });
      setEmailVerified(true);
      toast.success("이메일 인증 완료!");
    } catch (e) {
      // 401 = 인증번호 불일치/만료 (권한 문제 X)
      toast.error("인증번호가 올바르지 않거나 만료되었습니다.");
      setEmailVerified(false);
    } finally {
      setIsVerifyingEmail(false);
    }
  };

  const validate = () => {
    const loginId = form.loginId.trim();
    const pw = form.password;
    const cpw = form.confirmPassword;

    if (!loginId) return toast.error("아이디를 입력해주세요."), false;
    if (!loginIdCheck.checked || !loginIdCheck.available || loginIdCheck.loginId !== loginId) {
      toast.error("아이디 중복확인을 완료해주세요.");
      return false;
    }

    if (!pw || pw.length < 4) return toast.error("비밀번호는 4자 이상이어야 합니다."), false;
    if (/[ㄱ-ㅎ|ㅏ-ㅣ|가-힣]/.test(pw)) return toast.error("비밀번호에는 한글을 사용할 수 없습니다."), false;
    if (pw !== cpw) return toast.error("비밀번호 확인이 일치하지 않습니다."), false;

    if (!form.name.trim()) return toast.error("이름을 입력해주세요."), false;
    if (!form.email.trim()) return toast.error("이메일을 입력해주세요."), false;
    if (!emailVerified) return toast.error("이메일 인증을 완료해주세요."), false;
    if (!form.phone.trim()) return toast.error("휴대폰 번호를 입력해주세요."), false;

    if (!form.postcode.trim()) return toast.error("우편번호를 입력해주세요."), false;
    if (!form.address1.trim()) return toast.error("주소를 입력해주세요."), false;
    if (!form.address2.trim()) return toast.error("상세주소를 입력해주세요."), false;

    // ✅ 백엔드가 categories 필수
    if (!form.categories || form.categories.length === 0) {
      toast.error("관심 카테고리를 1개 이상 선택해주세요.");
      return false;
    }

    if (!form.agree) return toast.error("약관 동의가 필요합니다."), false;

    return true;
  };

  const buildRegisterPayload = () => {
    // ✅ 호환 전송(카테고리/주소 필드 등)
    const categories = form.categories;

    return {
      loginId: form.loginId.trim(),
      password: form.password,
      name: form.name.trim(),
      email: form.email.trim(),
      phone: form.phone.trim(),

      // 주소 호환
      postcode: form.postcode.trim(),
      zipcode: form.postcode.trim(),
      address1: form.address1.trim(),
      address2: form.address2.trim(),
      address: form.address1.trim(),
      addressDetail: form.address2.trim(),

      // 카테고리 호환(백엔드가 categories 필수)
      categories,
      categoryId: categories,      // 일부 백엔드가 categoryId 배열로 받을 수도 있어 같이 보냄
      categoryIds: categories,
      interests: categories,
    };
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (isSubmitting) return;

    if (!validate()) return;

    setIsSubmitting(true);
    try {
      const payload = buildRegisterPayload();
      await registerApi(payload);

      toast.success("회원가입이 완료되었습니다.");
      navigate("/login", { replace: true });
    } catch (e) {
      toast.error("회원가입에 실패했습니다. (필수값/DTO 매핑/카테고리 필수 여부 확인)");
    } finally {
      setIsSubmitting(false);
    }
  };

  // 선택된 카테고리 id 배열
  const selectedCategoryIds = useMemo(
    () => (Array.isArray(form.categories) ? form.categories : []),
    [form.categories]
  );

  return (
    <div className="min-h-screen bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-3xl mx-auto">
        {/* 상단 네비게이션 */}
        <div className="flex justify-between items-center mb-8">
          <button
            onClick={() => navigate("/bogam")}
            className="flex items-center text-gray-500 hover:text-black transition-colors"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
            </svg>
            메인으로
          </button>
          <h1 className="text-2xl font-bold text-gray-900">회원가입</h1>
          <div className="w-20"></div> {/* 밸런스용 공백 */}
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* 각 섹션을 화이트 카드 스타일로 래핑 */}
          <div className="bg-white shadow-sm rounded-xl p-6 border border-gray-100 space-y-8">
            
            <LoginIdSection
              form={form}
              onChange={handleChange}
              onCheckLoginId={runLoginIdCheck}
              loginIdCheck={loginIdCheck}
              isCheckingLoginId={isCheckingLoginId}
            />

            <hr className="border-gray-100" />

            <PasswordSection
              form={form}
              onChange={handleChange}
              showPw={showPw}
              showConfirmPw={showConfirmPw}
              onTogglePw={() => setShowPw((v) => !v)}
              onToggleConfirmPw={() => setShowConfirmPw((v) => !v)}
            />

            <hr className="border-gray-100" />

            <ProfileSection form={form} onChange={handleChange} />

            <hr className="border-gray-100" />

            <EmailVerificationSection
              form={form}
              onChange={handleChange}
              emailCode={emailCode}
              onChangeEmailCode={onChangeEmailCode}
              onSendEmailCode={sendEmail}
              onVerifyEmailCode={verifyEmail}
              emailSent={emailSent}
              emailVerified={emailVerified}
              isSendingEmail={isSendingEmail}
              isVerifyingEmail={isVerifyingEmail}
            />

            <hr className="border-gray-100" />

            <AddressSection
              form={form}
              onChange={handleChange}
              onSearchAddress={onSearchAddress}
            />

            <hr className="border-gray-100" />

            <CategoriesSection
              categories={categories}
              selectedIds={selectedCategoryIds}
              onToggleCategory={toggleCategory}
              loading={categoriesLoading}
            />

            <hr className="border-gray-100" />

            <AgreementSection form={form} onToggleAgree={handleToggleAgree} />
          </div>

          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full py-4 bg-black text-white rounded-xl font-bold text-lg hover:bg-gray-800 active:scale-[0.99] transition-all disabled:bg-gray-400 shadow-lg"
          >
            {isSubmitting ? "가입 처리 중..." : "회원가입 완료"}
          </button>

          <div className="text-center text-gray-500 text-sm">
            이미 계정이 있으신가요?{" "}
            <Link to="/login" className="text-black font-semibold underline underline-offset-4">
              로그인하기
            </Link>
          </div>
        </form>
      </div>
    </div>
  );
}