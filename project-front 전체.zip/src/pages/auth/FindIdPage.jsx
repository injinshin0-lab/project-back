export default function FindIdPage() {
  return (
    <div style={{ padding: 24 }}>
      <h1>아이디 찾기</h1>
      <p>/find/id</p>
    </div>
  );
}