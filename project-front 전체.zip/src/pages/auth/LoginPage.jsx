import LoginForm from '@/components/auth/LoginForm';
import '@/styles/pages/login.css';

export default function LoginPage() {
  return (
    <div className="login-page">
      <LoginForm />
    </div>
  );
}