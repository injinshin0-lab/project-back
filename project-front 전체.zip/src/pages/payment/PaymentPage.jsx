// src/pages/payment/PaymentPage.jsx
import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import toast from "react-hot-toast";

import useAuthStore from "@/stores/authStore";
import useCartStore from "@/stores/cartStore";
import usePaymentStore from "@/stores/paymentStore";

function formatWon(n) {
  const num = Number(n || 0);
  return `${num.toLocaleString("ko-KR")}원`;
}

function SourceBadge({ source }) {
  const isCart = source === "cart";
  return (
    <span
      className={[
        "inline-flex items-center px-3 py-1 rounded-full text-xs font-medium border",
        isCart ? "bg-white" : "bg-black text-white border-black",
      ].join(" ")}
    >
      {isCart ? "장바구니 구매" : "즉시 구매"}
    </span>
  );
}

function PayMethodButton({ active, label, onClick }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={[
        "flex-1 px-4 py-3 rounded-xl border text-sm font-medium",
        active ? "bg-black text-white border-black" : "bg-white hover:bg-gray-50",
      ].join(" ")}
    >
      {label}
    </button>
  );
}

/* ------------------ ✅ (A) 카드 입력 유틸 ------------------ */
const CARD_BRANDS = [
  { value: "samsung", label: "삼성" },
  { value: "shinhan", label: "신한" },
  { value: "kb", label: "국민" },
  { value: "hyundai", label: "현대" },
  { value: "lotte", label: "롯데" },
  { value: "hana", label: "하나" },
  { value: "bc", label: "BC" },
  { value: "nh", label: "NH" },
];

const INSTALLMENTS = [
  { value: "0", label: "일시불" },
  { value: "2", label: "2개월" },
  { value: "3", label: "3개월" },
  { value: "6", label: "6개월" },
  { value: "12", label: "12개월" },
];

function onlyDigits(s = "") {
  return String(s).replace(/\D/g, "");
}

function formatCardNumber(input) {
  const d = onlyDigits(input).slice(0, 16);
  return d.replace(/(\d{4})(?=\d)/g, "$1 ").trim();
}

function formatMMYY(input) {
  const d = onlyDigits(input).slice(0, 4);
  if (d.length <= 2) return d;
  return `${d.slice(0, 2)}/${d.slice(2)}`;
}

function isValidMMYY(mmyy) {
  const d = onlyDigits(mmyy);
  if (d.length !== 4) return false;
  const mm = Number(d.slice(0, 2));
  const yy = Number(d.slice(2, 4));
  if (mm < 1 || mm > 12) return false;

  const now = new Date();
  const curYY = Number(String(now.getFullYear()).slice(2));
  const curMM = now.getMonth() + 1;

  if (yy < curYY) return false;
  if (yy === curYY && mm < curMM) return false;
  return true;
}

function isValidCVC(cvc) {
  const d = onlyDigits(cvc);
  return d.length === 3;
}

function isValidCardNumber(cardNumber) {
  const d = onlyDigits(cardNumber);
  return d.length === 16;
}

function CardPayForm({ value, onChange }) {
  return (
    <div className="mt-4 rounded-xl border bg-white p-4">
      <div className="font-semibold">카드 정보 (모의 입력)</div>
      <div className="mt-3 grid grid-cols-1 md:grid-cols-2 gap-3">
        <div>
          <label className="text-sm text-gray-700">카드사</label>
          <select
            className="mt-1 w-full border rounded-lg px-3 py-2 text-sm bg-white"
            value={value.brand}
            onChange={(e) => onChange({ ...value, brand: e.target.value })}
          >
            <option value="">선택</option>
            {CARD_BRANDS.map((b) => (
              <option key={b.value} value={b.value}>
                {b.label}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="text-sm text-gray-700">할부</label>
          <select
            className="mt-1 w-full border rounded-lg px-3 py-2 text-sm bg-white"
            value={value.installment}
            onChange={(e) => onChange({ ...value, installment: e.target.value })}
          >
            {INSTALLMENTS.map((it) => (
              <option key={it.value} value={it.value}>
                {it.label}
              </option>
            ))}
          </select>
        </div>

        <div className="md:col-span-2">
          <label className="text-sm text-gray-700">카드번호</label>
          <input
            className="mt-1 w-full border rounded-lg px-3 py-2 text-sm"
            placeholder="1234 5678 9012 3456"
            inputMode="numeric"
            value={value.number}
            onChange={(e) =>
              onChange({ ...value, number: formatCardNumber(e.target.value) })
            }
          />
          <div className="mt-1 text-xs text-gray-500">* 16자리 입력(개발용)</div>
        </div>

        <div>
          <label className="text-sm text-gray-700">유효기간 (MM/YY)</label>
          <input
            className="mt-1 w-full border rounded-lg px-3 py-2 text-sm"
            placeholder="MM/YY"
            inputMode="numeric"
            value={value.expiry}
            onChange={(e) =>
              onChange({ ...value, expiry: formatMMYY(e.target.value) })
            }
          />
        </div>

        <div>
          <label className="text-sm text-gray-700">CVC</label>
          <input
            className="mt-1 w-full border rounded-lg px-3 py-2 text-sm"
            placeholder="123"
            inputMode="numeric"
            value={value.cvc}
            onChange={(e) =>
              onChange({ ...value, cvc: onlyDigits(e.target.value).slice(0, 3) })
            }
          />
        </div>
      </div>
    </div>
  );
}

/* ------------------ ✅ (B) 무통장 발급 유틸/컴포넌트 ------------------ */
const VBANK_BANKS = [
  "국민은행",
  "신한은행",
  "우리은행",
  "하나은행",
  "농협은행",
  "기업은행",
  "카카오뱅크",
];

function randInt(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}
function genAccountNumber() {
  // 간단히 “가상계좌 느낌”만 나는 숫자 조합
  const a = randInt(100, 999);
  const b = randInt(1000, 9999);
  const c = randInt(1000, 9999);
  return `${a}-${b}-${c}`;
}
function addHours(date, hours) {
  const d = new Date(date);
  d.setHours(d.getHours() + hours);
  return d;
}
function formatDeadline(d) {
  if (!d) return "-";
  return d.toLocaleString("ko-KR", {
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
  });
}

function VbankBox({ vbank, onIssue, onCopy }) {
  return (
    <div className="mt-4 rounded-xl border bg-white p-4">
      <div className="flex items-center justify-between gap-2">
        <div className="font-semibold">무통장 입금 안내</div>
        <button
          type="button"
          onClick={onIssue}
          className="px-3 py-2 rounded-lg border bg-white hover:bg-gray-50 text-sm"
        >
          계좌 발급(모의)
        </button>
      </div>

      {!vbank ? (
        <div className="mt-3 text-sm text-gray-600">
          계좌 발급(모의)을 누르면 입금 계좌가 생성됩니다.
        </div>
      ) : (
        <div className="mt-4 space-y-2 text-sm text-gray-700">
          <div>
            은행: <b>{vbank.bank}</b>
          </div>
          <div className="flex items-center justify-between gap-2">
            <div>
              계좌번호: <b>{vbank.account}</b>
            </div>
            <button
              type="button"
              onClick={() => onCopy(vbank.account)}
              className="px-3 py-2 rounded-lg border bg-white hover:bg-gray-50 text-xs"
            >
              복사
            </button>
          </div>
          <div>
            예금주: <b>{vbank.holder}</b>
          </div>
          <div>
            입금기한: <b>{formatDeadline(vbank.deadline)}</b>
          </div>
          <div className="pt-2 text-xs text-gray-500">
            * 무통장 입금은 입금 확인 후 주문이 완료됩니다. (개발용 모의)
          </div>
        </div>
      )}
    </div>
  );
}

export default function PaymentPage() {
  const navigate = useNavigate();

  const { isAuthenticated, user } = useAuthStore();
  const userId = user?.id ?? user?.userId ?? user?.memberId ?? user?.uid;

  const { clearCart } = useCartStore();
  const { session, paying, payNow, clearSession } = usePaymentStore();

  const amount = useMemo(() => Number(session?.amount || 0), [session]);

  // 결제 UI 상태
  const [method, setMethod] = useState("card"); // card | transfer | vbank

  // ✅ (C) 테스트용 결제 결과 토글 (추가)
  const [testResult, setTestResult] = useState("success"); // success | fail

  const [agreeAll, setAgreeAll] = useState(false);
  const [agreeRequired, setAgreeRequired] = useState(false);
  const [agreePrivacy, setAgreePrivacy] = useState(false);

  // (A) 카드 입력 상태
  const [card, setCard] = useState({
    brand: "",
    number: "",
    expiry: "",
    cvc: "",
    installment: "0",
  });

  // ✅ (B) 무통장 계좌 상태 추가
  const [vbank, setVbank] = useState(null);

  // 로그인/세션 체크
  useEffect(() => {
    if (!isAuthenticated) {
      navigate("/login", { replace: true });
      return;
    }
    if (!session?.orderId) {
      toast("결제 정보가 없습니다. 주문서에서 다시 진행해주세요.");
      navigate("/order", { replace: true });
    }
  }, [isAuthenticated, session?.orderId, navigate]);

  // 전체동의 처리
  useEffect(() => {
    if (agreeAll) {
      setAgreeRequired(true);
      setAgreePrivacy(true);
    }
  }, [agreeAll]);

  useEffect(() => {
    const all = agreeRequired && agreePrivacy;
    setAgreeAll(all);
  }, [agreeRequired, agreePrivacy]);

  if (!isAuthenticated || !session?.orderId) {
    return (
      <div className="max-w-2xl mx-auto p-4">
        <div className="rounded-xl border bg-white p-6">
          <h1 className="text-2xl font-bold">결제</h1>
          <p className="mt-2 text-sm text-gray-600">이동 중...</p>
        </div>
      </div>
    );
  }

  const canPayBase = agreeRequired && agreePrivacy && !paying;

  // 카드일 때는 카드 폼 검증 필요
  const cardOk =
    method !== "card"
      ? true
      : Boolean(card.brand) &&
        isValidCardNumber(card.number) &&
        isValidMMYY(card.expiry) &&
        isValidCVC(card.cvc);

  // ✅ (B) 무통장은 “계좌 발급”이 되어 있어야 결제 진행 가능(모의)
  const vbankOk = method !== "vbank" ? true : Boolean(vbank?.account);

  const canPay = canPayBase && cardOk && vbankOk;

  const validateBeforePay = () => {
    if (!agreeRequired || !agreePrivacy) {
      toast.error("필수 약관에 동의해주세요.");
      return false;
    }

    if (method === "card") {
      if (!card.brand) return toast.error("카드사를 선택해주세요."), false;
      if (!isValidCardNumber(card.number))
        return toast.error("카드번호 16자리를 입력해주세요."), false;
      if (!isValidMMYY(card.expiry))
        return toast.error("유효기간(MM/YY)을 확인해주세요."), false;
      if (!isValidCVC(card.cvc)) return toast.error("CVC 3자리를 입력해주세요."), false;
    }

    if (method === "vbank") {
      if (!vbank?.account) {
        toast.error("무통장 계좌를 먼저 발급해주세요.");
        return false;
      }
    }

    return true;
  };

  // ✅ (B) 계좌 발급(모의)
  const onIssueVbank = () => {
    const bank = VBANK_BANKS[randInt(0, VBANK_BANKS.length - 1)];
    const account = genAccountNumber();
    const holder = "보감(주)"; // 예금주(모의)
    const deadline = addHours(new Date(), 24); // 24시간 후

    setVbank({ bank, account, holder, deadline });
    toast.success("가상계좌가 발급되었습니다. (모의)");
  };

  // ✅ (B) 복사 기능(추가)
  const onCopy = async (text) => {
    try {
      await navigator.clipboard.writeText(String(text));
      toast.success("복사되었습니다.");
    } catch {
      toast.error("복사에 실패했습니다.");
    }
  };

  const onPay = async () => {
    if (!validateBeforePay()) return;

    // ✅ (C) 테스트 실패 분기 (추가)
    if (testResult === "fail") {
      navigate("/payment/fail", {
        state: {
          orderId: session.orderId,
          reason: "테스트 설정으로 결제가 실패 처리되었습니다.",
        },
        replace: true,
      });
      return;
    }

    console.log("[PAYMENT] method:", method);
    if (method === "card") console.log("[PAYMENT] card mock:", card);
    if (method === "vbank") console.log("[PAYMENT] vbank mock:", vbank);

    const result = await payNow();
    if (!result) return;

    if (session.source === "cart") {
      try {
        await clearCart(userId);
      } catch {
        // cartStore 내부 toast
      }
    }

    const state = {
      orderId: session.orderId,
      source: session.source,
      paid: true,
      payment: {
        ...result,
        method,
        card: method === "card" ? card : null,
        vbank: method === "vbank" ? vbank : null,
      },
    };

    clearSession();
    navigate("/order/complete", { state });
  };

  const onCancel = () => {
    toast("결제를 취소했습니다.");
    navigate("/order");
  };

  return (
    <div className="max-w-2xl mx-auto p-4">
      <div className="rounded-xl border bg-white p-6">
        {/* 헤더 */}
        <div className="flex items-end justify-between gap-2">
          <div>
            <h1 className="text-2xl font-bold">결제</h1>
            <div className="mt-2 flex items-center gap-2">
              <SourceBadge source={session.source} />
              <span className="text-xs px-3 py-1 rounded-full border">주문서 기반</span>
            </div>
          </div>
          <div className="text-sm text-gray-700">
            주문번호: <b>{session.orderId}</b>
          </div>
        </div>

        {/* 결제 금액 */}
        <div className="mt-5 rounded-xl border p-4">
          <div className="text-sm text-gray-600">결제 금액</div>
          <div className="mt-1 text-2xl font-extrabold">{formatWon(amount)}</div>
          <div className="mt-1 text-xs text-gray-500">
            * 배송비/할인/포인트 등은 다음 단계에서 확장 가능
          </div>
        </div>

        {/* 결제 수단 */}
        <div className="mt-5">
          <div className="font-semibold">결제 수단</div>
          <div className="mt-3 flex gap-2">
            <PayMethodButton
              label="카드"
              active={method === "card"}
              onClick={() => setMethod("card")}
            />
            <PayMethodButton
              label="계좌이체"
              active={method === "transfer"}
              onClick={() => setMethod("transfer")}
            />
            <PayMethodButton
              label="무통장"
              active={method === "vbank"}
              onClick={() => setMethod("vbank")}
            />
          </div>

          <div className="mt-3 text-sm text-gray-600 rounded-lg border bg-gray-50 p-3">
            {method === "card" ? (
              <div>카드 결제는 결제 승인 후 주문이 완료됩니다. (개발용 모의 입력)</div>
            ) : null}
            {method === "transfer" ? <div>계좌이체는 이체 완료 후 주문이 완료됩니다.</div> : null}
            {method === "vbank" ? <div>무통장 입금은 입금 확인 후 주문이 완료됩니다. (개발용 모의)</div> : null}
          </div>
        </div>

        {/* (A) 카드 폼 */}
        {method === "card" ? <CardPayForm value={card} onChange={setCard} /> : null}

        {/* ✅ (B) 무통장 박스 */}
        {method === "vbank" ? (
          <VbankBox vbank={vbank} onIssue={onIssueVbank} onCopy={onCopy} />
        ) : null}

        {/* ✅ (C) 테스트용: 결제 결과 선택 (추가) */}
        <div className="mt-5 rounded-xl border bg-white p-4">
          <div className="font-semibold">테스트 옵션</div>
          <div className="mt-3 flex gap-2">
            <button
              type="button"
              onClick={() => setTestResult("success")}
              className={[
                "flex-1 px-4 py-2 rounded-lg border text-sm",
                testResult === "success"
                  ? "bg-black text-white border-black"
                  : "bg-white hover:bg-gray-50",
              ].join(" ")}
            >
              결제 성공
            </button>
            <button
              type="button"
              onClick={() => setTestResult("fail")}
              className={[
                "flex-1 px-4 py-2 rounded-lg border text-sm",
                testResult === "fail"
                  ? "bg-black text-white border-black"
                  : "bg-white hover:bg-gray-50",
              ].join(" ")}
            >
              결제 실패
            </button>
          </div>
          <div className="mt-2 text-xs text-gray-500">
            * 개발용 옵션입니다. 실제 결제 연동 시 제거/비활성화하면 됩니다.
          </div>
        </div>

        {/* 약관 동의 */}
        <div className="mt-5">
          <div className="font-semibold">약관 동의</div>

          <div className="mt-3 space-y-2">
            <label className="flex items-center gap-2 text-sm">
              <input
                type="checkbox"
                checked={agreeAll}
                onChange={(e) => setAgreeAll(e.target.checked)}
              />
              <span className="font-medium">전체 동의</span>
            </label>

            <div className="h-px bg-gray-100" />

            <label className="flex items-center gap-2 text-sm">
              <input
                type="checkbox"
                checked={agreeRequired}
                onChange={(e) => setAgreeRequired(e.target.checked)}
              />
              <span>(필수) 결제 진행 및 구매 조건 동의</span>
            </label>

            <label className="flex items-center gap-2 text-sm">
              <input
                type="checkbox"
                checked={agreePrivacy}
                onChange={(e) => setAgreePrivacy(e.target.checked)}
              />
              <span>(필수) 개인정보 제3자 제공 동의</span>
            </label>

            <div className="text-xs text-gray-500">
              * 실결제 연동 시 약관 상세/모달/링크로 확장 가능
            </div>
          </div>
        </div>

        {/* 하단 버튼 */}
        <div className="mt-6 flex gap-2">
          <button
            type="button"
            onClick={onCancel}
            className="flex-1 px-4 py-3 rounded-xl border bg-white hover:bg-gray-50"
            disabled={paying}
          >
            이전으로
          </button>

          <button
            type="button"
            onClick={onPay}
            className="flex-1 px-4 py-3 rounded-xl bg-black text-white hover:bg-black/90 disabled:opacity-60"
            disabled={!canPay}
          >
            {paying ? "결제 진행 중..." : `결제하기 (${formatWon(amount)})`}
          </button>
        </div>

        {/* 개발 안내 */}
        <div className="mt-4 text-xs text-gray-500">
          * 개발 단계: 백엔드 결제 API가 없으면 자동으로 “모의 결제 성공” 처리됩니다.
        </div>

        {/* 카드 검증 힌트 */}
        {method === "card" && canPayBase && !cardOk ? (
          <div className="mt-3 text-xs text-red-500">
            카드 결제는 카드사/카드번호(16)/유효기간(MM/YY)/CVC(3) 입력이 필요합니다.
          </div>
        ) : null}

        {/* 무통장 검증 힌트 */}
        {method === "vbank" && canPayBase && !vbankOk ? (
          <div className="mt-3 text-xs text-red-500">
            무통장 결제는 먼저 “계좌 발급(모의)”을 진행해야 합니다.
          </div>
        ) : null}
      </div>
    </div>
  );
}