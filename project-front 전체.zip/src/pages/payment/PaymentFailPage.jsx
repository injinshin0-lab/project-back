// src/pages/payment/PaymentFailPage.jsx
import { useLocation, useNavigate } from "react-router-dom";

export default function PaymentFailPage() {
  const navigate = useNavigate();
  const { state } = useLocation();

  const orderId = state?.orderId ?? "-";
  const reason = state?.reason ?? "결제가 실패했습니다.";

  return (
    <div className="max-w-2xl mx-auto p-4">
      <div className="rounded-xl border bg-white p-6">
        <h1 className="text-2xl font-bold">결제 실패</h1>
        <p className="mt-2 text-sm text-gray-600">
          주문번호: <b>{orderId}</b>
        </p>

        <div className="mt-4 rounded-xl border bg-red-50 p-4 text-sm text-red-700">
          {reason}
        </div>

        <div className="mt-6 flex gap-2">
          <button
            type="button"
            onClick={() => navigate("/payment", { replace: true, state })}
            className="flex-1 px-4 py-3 rounded-xl bg-black text-white hover:bg-black/90"
          >
            다시 결제하기
          </button>
          <button
            type="button"
            onClick={() => navigate("/order", { replace: true })}
            className="flex-1 px-4 py-3 rounded-xl border bg-white hover:bg-gray-50"
          >
            주문서로 돌아가기
          </button>
        </div>
      </div>
    </div>
  );
}