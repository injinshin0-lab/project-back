export default function CartPage() {
  return (
    <div style={{ padding: 24 }}>
      <h1>장바구니</h1>
      <p>/cart</p>
    </div>
  );
}