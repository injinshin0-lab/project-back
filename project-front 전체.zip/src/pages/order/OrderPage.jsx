// src/pages/order/OrderPage.jsx
import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import toast from "react-hot-toast";

import useAuthStore from "@/stores/authStore";
import useOrderStore from "@/stores/orderStore";
import usePaymentStore from "@/stores/paymentStore";

function formatWon(n) {
  const num = Number(n || 0);
  return `${num.toLocaleString("ko-KR")}원`;
}

function SourceBadge({ source }) {
  const isCart = source === "cart";
  return (
    <span
      className={[
        "inline-flex items-center px-3 py-1 rounded-full text-xs font-medium border",
        isCart ? "bg-white" : "bg-black text-white border-black",
      ].join(" ")}
    >
      {isCart ? "장바구니 구매" : "즉시 구매"}
    </span>
  );
}

// ✅ (추가) 다음 우편번호 스크립트 로더
function loadDaumPostcodeScript() {
  return new Promise((resolve, reject) => {
    if (typeof window === "undefined") return reject(new Error("no window"));
    if (window.daum?.Postcode) return resolve(true);

    const existing = document.querySelector('script[data-daum-postcode="true"]');
    if (existing) {
      existing.addEventListener("load", () => resolve(true));
      existing.addEventListener("error", reject);
      return;
    }

    const script = document.createElement("script");
    script.src =
      "https://t1.daumcdn.net/mapjsapi/bundle/postcode/prod/postcode.v2.js";
    script.async = true;
    script.dataset.daumPostcode = "true";
    script.onload = () => resolve(true);
    script.onerror = reject;
    document.body.appendChild(script);
  });
}

export default function OrderPage() {
  const navigate = useNavigate();

  const { user } = useAuthStore();
  const name = user?.name ?? user?.username ?? user?.loginId ?? "사용자";

  const { setSession } = usePaymentStore();

  const {
    draftSource,
    draftItems,
    draftMemo,
    draftAddress,
    setMemo,
    setAddress,
    submitting,
    submitOrder,
    getTotal,
  } = useOrderStore();

  const total = useMemo(() => getTotal(), [getTotal, draftItems]);

  // ✅ (추가) 주소검색 준비 상태
  const [postcodeReady, setPostcodeReady] = useState(false);

  // ✅ (추가) 스크립트 로드
  useEffect(() => {
    loadDaumPostcodeScript()
      .then(() => setPostcodeReady(true))
      .catch(() => setPostcodeReady(false));
  }, []);

  // ✅ (추가) 주소찾기 핸들러
  const onFindAddress = async () => {
    try {
      await loadDaumPostcodeScript();

      if (!window.daum?.Postcode) {
        toast.error("주소 검색 모듈을 불러오지 못했습니다.");
        return;
      }

      new window.daum.Postcode({
        oncomplete: (data) => {
          const addr = data.roadAddress || data.jibunAddress || "";
          const zonecode = data.zonecode || "";

          setAddress({
            postcode: zonecode,
            address1: addr,
          });

          // 상세주소로 포커스 유도(UX)
          setTimeout(() => {
            const el = document.getElementById("order-address2");
            if (el) el.focus();
          }, 50);
        },
      }).open();
    } catch (e) {
      toast.error("주소 검색을 열 수 없습니다.");
    }
  };

  const onGoPayment = async () => {
    console.log("[ORDER] go payment click");
    const result = await submitOrder();

    console.log("[ORDER] submitOrder result:", result);

    if (!result?.orderId) {
      toast.error("주문 생성 결과가 없습니다.");
      return;
    }

    setSession({
      orderId: result.orderId,
      amount: total,
      source: draftSource,
    });

    console.log("[ORDER] navigate -> /payment");
    navigate("/payment");
  };

  if (!draftItems?.length) {
    return (
      <div className="max-w-3xl mx-auto p-4">
        <h1 className="text-2xl font-bold">주문서</h1>
        <div className="mt-6 rounded-xl border p-6 bg-white">
          <div className="text-lg font-semibold">주문할 상품이 없어요.</div>
          <div className="mt-2 text-sm text-gray-600">
            장바구니 또는 상품 상세에서 구매하기를 눌러주세요.
          </div>
          <button
            type="button"
            onClick={() => navigate("/cart")}
            className="mt-4 px-4 py-2 rounded-lg border bg-white hover:bg-gray-50"
          >
            장바구니로
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto p-4">
      <div className="flex items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold">주문서</h1>
          <p className="text-sm text-gray-600 mt-1">주문 정보를 확인하고 결제를 진행하세요.</p>
          <div className="mt-2">
            <SourceBadge source={draftSource} />
          </div>
        </div>
        <div className="text-sm text-gray-700">
          주문자: <b>{name}</b>
        </div>
      </div>

      {/* 주문 상품 */}
      <div className="mt-6 rounded-xl border bg-white p-4">
        <div className="font-semibold">주문 상품</div>
        <div className="mt-3 space-y-2">
          {draftItems.map((it) => (
            <div key={it.productId} className="flex items-start justify-between gap-3 border rounded-lg p-3">
              <div className="min-w-0">
                <div className="font-medium truncate">{it.name}</div>
                <div className="text-sm text-gray-600 mt-1">
                  {formatWon(it.price)} · 수량 {it.quantity}
                </div>
              </div>
              <div className="text-sm">
                <b>{formatWon(Number(it.price) * Number(it.quantity))}</b>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-4 flex items-center justify-between text-sm">
          <span className="text-gray-700">합계</span>
          <b className="text-base">{formatWon(total)}</b>
        </div>
      </div>

      {/* 배송지 */}
      <div className="mt-4 rounded-xl border bg-white p-4">
        {/* ✅ (추가) 제목 + 주소찾기 버튼 */}
        <div className="flex items-center justify-between gap-2"></div>
        <div className="font-semibold">배송지</div>
        <button
            type="button"
            onClick={onFindAddress}
            disabled={!postcodeReady}
            className="px-3 py-2 rounded-lg border bg-white hover:bg-gray-50 text-sm disabled:opacity-60"
          >
            주소 찾기
          </button>
        </div>

        <div className="mt-3 grid grid-cols-1 gap-2">
          <input
            className="border rounded-lg px-3 py-2 text-sm"
            placeholder="우편번호"
            value={draftAddress.postcode}
            onChange={(e) => setAddress({ postcode: e.target.value })}
          />
          <input
            className="border rounded-lg px-3 py-2 text-sm"
            placeholder="주소"
            value={draftAddress.address1}
            onChange={(e) => setAddress({ address1: e.target.value })}
          />
          <input
            id="order-address2" // ✅ (추가) 포커스 이동용 id
            className="border rounded-lg px-3 py-2 text-sm"
            placeholder="상세주소"
            value={draftAddress.address2}
            onChange={(e) => setAddress({ address2: e.target.value })}
          />
        </div>

      {/* 요청사항 */}
      <div className="mt-4 rounded-xl border bg-white p-4">
        <div className="font-semibold">배송 요청사항</div>
        <textarea
          className="mt-3 w-full border rounded-lg px-3 py-2 text-sm min-h-[90px]"
          placeholder="예: 문 앞에 두고 연락 주세요."
          value={draftMemo}
          onChange={(e) => setMemo(e.target.value)}
        />
      </div>

      {/* 결제 이동 */}
      <div className="mt-6 flex items-center justify-between gap-3">
        <button
          type="button"
          onClick={() => navigate(draftSource === "cart" ? "/cart" : "/products")}
          className="px-4 py-3 rounded-xl border bg-white hover:bg-gray-50"
        >
          이전으로
        </button>

        <button
          type="button"
          onClick={onGoPayment}
          disabled={submitting}
          className="px-5 py-3 rounded-xl bg-black text-white hover:bg-black/90 disabled:opacity-60"
        >
          {submitting ? "주문 생성 중..." : `결제하러 가기 (${formatWon(total)})`}
        </button>
      </div>
    </div>
  );
}
