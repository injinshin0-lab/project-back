// src/pages/order/OrderCompletePage.jsx
import { Link, useLocation, useNavigate } from "react-router-dom";

function SourceBadge({ source }) {
  const isCart = source === "cart";
  return (
    <span
      className={[
        "inline-flex items-center px-3 py-1 rounded-full text-xs font-medium border",
        isCart ? "bg-white" : "bg-black text-white border-black",
      ].join(" ")}
    >
      {isCart ? "장바구니 구매" : "즉시 구매"}
    </span>
  );
}

export default function OrderCompletePage() {
  const navigate = useNavigate();
  const { state } = useLocation();

  const orderId = state?.orderId;
  const source = state?.source ?? "cart";
  const paid = Boolean(state?.paid);

  return (
    <div className="max-w-2xl mx-auto p-4">
      <div className="rounded-xl border bg-white p-6">
        <h1 className="text-2xl font-bold">주문 완료 🎉</h1>

        <div className="mt-3 flex items-center gap-2">
          <SourceBadge source={source} />
          <span className="text-xs px-3 py-1 rounded-full border">
            {paid ? "결제 완료" : "결제 미확인"}
          </span>
        </div>

        <div className="mt-3 text-sm text-gray-700">
          {orderId ? (
            <>
              주문번호: <b>{orderId}</b>
            </>
          ) : (
            "주문이 완료되었습니다."
          )}
        </div>

        <div className="mt-6 flex gap-2">
          <button
            type="button"
            onClick={() => navigate("/cart")}
            className="px-4 py-2 rounded-lg border bg-white hover:bg-gray-50"
          >
            장바구니로
          </button>

          <Link
            to="/bogam"
            className="px-4 py-2 rounded-lg bg-black text-white hover:bg-black/90"
          >
            메인으로
          </Link>
        </div>
      </div>
    </div>
  );
}