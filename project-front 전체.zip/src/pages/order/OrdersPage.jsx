// src/pages/order/OrdersPage.jsx
import { useEffect, useMemo } from "react";
import { Link } from "react-router-dom";
// src/pages/order/OrdersPage.jsx

import useAuthStore from "@/stores/authStore";
import useOrderHistoryStore, {
  ORDER_STATUS_LABEL,
  PAYMENT_STATUS_LABEL,
  PAYMENT_METHOD_LABEL,
} from "@/stores/orderHistoryStore";

function cn(...arr) {
  return arr.filter(Boolean).join(" ");
}

function formatWon(n) {
  const num = Number(n || 0);
  return `${num.toLocaleString("ko-KR")}원`;
}

function formatDateTime(v) {
  if (!v) return "-";
  // backend가 string으로 준다고 가정(텍스트)
  // ISO면 Date 파싱, 아니면 그대로 표시
  const d = new Date(v);
  if (!Number.isNaN(d.getTime())) {
    return `${d.toLocaleDateString("ko-KR")} ${d.toLocaleTimeString("ko-KR", {
      hour: "2-digit",
      minute: "2-digit",
    })}`;
  }
  return String(v);
}

function Badge({ children, tone = "gray" }) {
  const map = {
    gray: "bg-gray-100 text-gray-700 border-gray-200",
    black: "bg-black text-white border-black",
    green: "bg-green-50 text-green-700 border-green-200",
    red: "bg-red-50 text-red-700 border-red-200",
    blue: "bg-blue-50 text-blue-700 border-blue-200",
  };
  return (
    <span className={cn("inline-flex items-center px-2.5 py-1 rounded-full text-xs border", map[tone])}>
      {children}
    </span>
  );
}

function getOrderId(o) {
  return o?.id ?? o?.orderId ?? o?.order_id;
}

function getOrderStatus(o) {
  return o?.orderStatus ?? o?.order_status ?? o?.status;
}

function getPaymentStatus(o) {
  return o?.paymentStatus ?? o?.payment_status;
}

function getPaymentMethod(o) {
  return o?.paymentMethod ?? o?.payment_method;
}

function getPaymentPrice(o) {
  return o?.paymentPrice ?? o?.payment_price ?? o?.totalPrice ?? o?.total_price ?? o?.price ?? 0;
}

function getOrderedAt(o) {
  return o?.orderedAt ?? o?.ordered_at ?? o?.createdAt ?? o?.created_at;
}

export default function OrdersPage() {
  const { user } = useAuthStore();
  const userId = user?.id ?? user?.userId ?? user?.memberId ?? user?.uid;

  const { orders, loading, fetchMyOrders } = useOrderHistoryStore();

  useEffect(() => {
    if (!userId) return;
    fetchMyOrders(userId);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [userId]);

  const sorted = useMemo(() => {
    const list = Array.isArray(orders) ? [...orders] : [];
    // 최신순 정렬(orderedAt 기준)
    list.sort((a, b) => {
      const da = new Date(getOrderedAt(a) || 0).getTime();
      const db = new Date(getOrderedAt(b) || 0).getTime();
      return db - da;
    });
    return list;
  }, [orders]);

  return (
    <div className="max-w-4xl mx-auto p-4">
      <div className="flex items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold">주문 내역</h1>
          <p className="text-sm text-gray-600 mt-1">
            결제수단/결제상태/배송상태를 한 번에 확인할 수 있어요.
          </p>
        </div>

        <div className="text-sm text-gray-700">
          총 <b>{sorted.length}</b>건
        </div>
      </div>

      <div className="mt-6">
        {loading ? (
          <div className="rounded-xl border p-6 bg-white text-gray-600">불러오는 중...</div>
        ) : !sorted.length ? (
          <div className="rounded-xl border p-6 bg-white">
            <div className="text-lg font-semibold">주문 내역이 없어요.</div>
            <div className="mt-2 text-sm text-gray-600">상품을 구매하면 여기에 표시됩니다.</div>
            <Link
              to="/products"
              className="inline-block mt-4 px-4 py-2 rounded-lg border bg-white hover:bg-gray-50 text-sm"
            >
              상품 보러가기
            </Link>
          </div>
        ) : (
          <div className="space-y-3">
            {sorted.map((o) => {
              const id = getOrderId(o);
              const orderStatus = getOrderStatus(o);
              const paymentStatus = getPaymentStatus(o);
              const paymentMethod = getPaymentMethod(o);
              const price = getPaymentPrice(o);
              const orderedAt = getOrderedAt(o);

              const orderLabel = ORDER_STATUS_LABEL[orderStatus] || orderStatus || "상태";
              const payLabel = PAYMENT_STATUS_LABEL[paymentStatus] || paymentStatus || "결제";
              const methodLabel = PAYMENT_METHOD_LABEL[paymentMethod] || paymentMethod || "결제수단";

              // 뱃지 톤(대충만)
              const orderTone =
                orderStatus === "CANCELED" ? "red" :
                orderStatus === "DELIVERED" ? "green" :
                orderStatus === "SHIPPING" ? "blue" :
                "gray";

              const payTone =
                paymentStatus === "PAID" ? "green" :
                paymentStatus === "FAILED" ? "red" :
                "gray";

              return (
                <div key={id} className="rounded-xl border bg-white p-4">
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <div className="text-sm text-gray-600">
                        주문번호 <b className="text-gray-900">{id}</b> · {formatDateTime(orderedAt)}
                      </div>

                      <div className="mt-2 flex flex-wrap gap-2">
                        <Badge tone={orderTone}>배송: {orderLabel}</Badge>
                        <Badge tone={payTone}>결제: {payLabel}</Badge>
                        <Badge tone="gray">수단: {methodLabel}</Badge>
                      </div>

                      <div className="mt-3 text-sm text-gray-700">
                        결제금액 <b className="text-gray-900">{formatWon(price)}</b>
                      </div>
                    </div>

                    <div className="shrink-0">
                      {id ? (
                        <Link
                          to={`/mypage/orders/${id}`}
                          className="inline-flex items-center px-4 py-2 rounded-lg border bg-white hover:bg-gray-50 text-sm"
                        >
                          상세보기
                        </Link>
                      ) : null}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}