// src/pages/reviews/ProductReviewWritePage.jsx
import { useMemo, useRef, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import toast from "react-hot-toast";

import useAuthStore from "@/stores/authStore";
import useReviewStore from "@/stores/reviewStore";

/**
 * 리뷰 작성 페이지
 * - 회원만 작성 가능
 * - 별점(1~5), 내용 필수
 * - 사진: 최대 5장, 각 10MB 이하, 이미지 파일만
 * - 미리보기/삭제 지원
 * - 성공 시: 상세 페이지로 이동 + 리뷰 목록은 상세에서 자동 재조회
 */

const MAX_FILES = 5;
const MAX_FILE_SIZE = 10 * 1024 * 1024; // 10MB
const ACCEPTED_IMAGE_TYPES = [
  "image/jpeg",
  "image/png",
  "image/webp",
  "image/gif",
];

function isImageFile(file) {
  if (!file) return false;
  // type이 비어있는 경우도 있어 확장자로 한 번 더 보완
  if (file.type && ACCEPTED_IMAGE_TYPES.includes(file.type)) return true;
  const name = (file.name || "").toLowerCase();
  return (
    name.endsWith(".jpg") ||
    name.endsWith(".jpeg") ||
    name.endsWith(".png") ||
    name.endsWith(".webp") ||
    name.endsWith(".gif")
  );
}

export default function ProductReviewWritePage() {
  const { productId } = useParams();
  const navigate = useNavigate();

  const { isAuthenticated } = useAuthStore();
  const { createReview, creating } = useReviewStore();

  const fileRef = useRef(null);

  const [rating, setRating] = useState(5);
  const [content, setContent] = useState("");

  const [files, setFiles] = useState([]); // File[]
  const previews = useMemo(() => {
    // objectURL 생성
    return files.map((f) => ({
      file: f,
      url: URL.createObjectURL(f),
    }));
  }, [files]);

  // objectURL 정리
  // (간단히 페이지 이동 시 브라우저가 정리하지만, 안전하게 cleanup)
  // - React strict mode에서 두 번 실행될 수 있어 여기서는 미사용
  // - 실제 릭이 크게 문제되진 않지만, 삭제 시 revoke 처리함

  const ensureAuth = () => {
    if (!isAuthenticated) {
      toast("리뷰 작성은 로그인 후 가능합니다.");
      navigate("/login", { replace: true });
      return false;
    }
    return true;
  };

  const onClickBack = () => {
    navigate(-1);
  };

  const onPickFiles = () => {
    if (!ensureAuth()) return;
    fileRef.current?.click();
  };

  const onChangeFiles = (e) => {
    const incoming = Array.from(e.target.files || []);
    // 동일 파일 다시 선택 가능하도록 value 초기화
    e.target.value = "";

    if (!incoming.length) return;

    const next = [...files];
    for (const file of incoming) {
      if (next.length >= MAX_FILES) {
        toast.error(`사진은 최대 ${MAX_FILES}장까지 첨부할 수 있어요.`);
        break;
      }

      if (!isImageFile(file)) {
        toast.error("이미지 파일만 첨부할 수 있어요.");
        continue;
      }

      if (file.size > MAX_FILE_SIZE) {
        toast.error("이미지는 10MB 이하만 첨부할 수 있어요.");
        continue;
      }

      // 중복(이름+사이즈) 간단 방지
      const dup = next.some((f) => f.name === file.name && f.size === file.size);
      if (dup) continue;

      next.push(file);
    }

    setFiles(next);
  };

  const onRemoveFile = (idx) => {
    const target = previews[idx];
    if (target?.url) URL.revokeObjectURL(target.url);

    setFiles((prev) => prev.filter((_, i) => i !== idx));
  };

  const onSetStar = (v) => {
    if (!ensureAuth()) return;
    setRating(v);
  };

  const onSubmit = async (e) => {
    e.preventDefault();
    if (!ensureAuth()) return;

    const text = content.trim();
    if (!productId) {
      toast.error("상품 정보를 확인할 수 없습니다.");
      return;
    }
    if (!rating || rating < 1 || rating > 5) {
      toast.error("별점을 선택해주세요.");
      return;
    }
    if (!text) {
      toast.error("리뷰 내용을 입력해주세요.");
      return;
    }

    try {
      const fd = new FormData();

      /**
       * ✅ FormData 필드명은 백엔드 스펙에 따라 다를 수 있음.
       * 현재는 가장 흔한 키로 구성:
       * - rating
       * - content
       * - images (파일 여러 개)
       *
       * 만약 백엔드가 다른 키를 요구하면 여기만 바꾸면 됨.
       */
      fd.append("rating", String(rating));
      fd.append("content", text);
      files.forEach((f) => fd.append("images", f));

      await createReview(productId, fd);

      toast.success("리뷰가 등록되었습니다.");
      // 상세로 복귀 (상세 페이지의 리뷰 섹션이 다시 fetch 하게 됨)
      navigate(`/products/${productId}`, { replace: true });
    } catch (err) {
      toast.error("리뷰 등록에 실패했습니다.");
    }
  };

  return (
    <div className="max-w-3xl mx-auto px-4 py-6">
      {/* 상단 */}
      <div className="flex items-center justify-between gap-3">
        <button
          type="button"
          onClick={onClickBack}
          className="px-3 py-2 rounded-md border text-sm hover:bg-gray-50"
        >
          ← 뒤로
        </button>

        <button
          type="button"
          onClick={() => navigate(`/products/${productId}`)}
          className="px-3 py-2 rounded-md border text-sm hover:bg-gray-50"
        >
          상품 상세로
        </button>
      </div>

      <h1 className="mt-5 text-2xl font-bold">리뷰 작성</h1>
      <p className="mt-1 text-sm text-gray-500">
        별점과 후기를 작성하고, 사진은 최대 {MAX_FILES}장까지 첨부할 수 있어요.
      </p>

      {!isAuthenticated && (
        <div className="mt-4 p-4 rounded-lg border bg-white">
          <div className="font-semibold text-gray-800">로그인이 필요합니다.</div>
          <div className="text-sm text-gray-600 mt-1">
            리뷰 작성은 회원만 가능합니다.
          </div>
          <button
            type="button"
            onClick={() => navigate("/login", { replace: true })}
            className="mt-3 px-4 py-2 rounded-md bg-black text-white text-sm hover:opacity-90"
          >
            로그인 하러가기
          </button>
        </div>
      )}

      <form onSubmit={onSubmit} className="mt-6 space-y-6">
        {/* 별점 */}
        <div className="p-5 rounded-xl border bg-white">
          <div className="flex items-center justify-between">
            <div className="font-semibold">별점</div>
            <div className="text-sm text-gray-600">{rating} / 5</div>
          </div>

          <div className="mt-3 flex gap-1">
            {[1, 2, 3, 4, 5].map((v) => (
              <button
                key={v}
                type="button"
                onClick={() => onSetStar(v)}
                className={`w-10 h-10 rounded-md border text-lg ${
                  v <= rating ? "bg-black text-white" : "hover:bg-gray-50"
                }`}
                disabled={!isAuthenticated}
                title={`${v}점`}
              >
                ★
              </button>
            ))}
          </div>
        </div>

        {/* 내용 */}
        <div className="p-5 rounded-xl border bg-white">
          <div className="font-semibold">내용</div>
          <textarea
            value={content}
            onChange={(e) => setContent(e.target.value)}
            placeholder="상품에 대한 솔직한 후기를 남겨주세요."
            className="mt-3 w-full min-h-[140px] px-3 py-2 border rounded-md"
            disabled={!isAuthenticated || creating}
          />
          <div className="mt-2 text-xs text-gray-500">
            공백 제외 {content.trim().length}자
          </div>
        </div>

        {/* 사진 */}
        <div className="p-5 rounded-xl border bg-white">
          <div className="flex items-center justify-between gap-3">
            <div>
              <div className="font-semibold">사진 첨부</div>
              <div className="text-sm text-gray-500 mt-1">
                이미지 파일만 가능 · 각 10MB 이하 · 최대 {MAX_FILES}장
              </div>
            </div>

            <button
              type="button"
              onClick={onPickFiles}
              className="px-4 py-2 rounded-md border text-sm hover:bg-gray-50"
              disabled={!isAuthenticated || creating || files.length >= MAX_FILES}
            >
              사진 선택
            </button>

            <input
              ref={fileRef}
              type="file"
              accept="image/*"
              multiple
              className="hidden"
              onChange={onChangeFiles}
            />
          </div>

          {files.length > 0 ? (
            <div className="mt-4 grid grid-cols-3 sm:grid-cols-5 gap-2">
              {previews.map((p, idx) => (
                <div key={`${p.file.name}-${p.file.size}-${idx}`} className="relative">
                  <img
                    src={p.url}
                    alt="preview"
                    className="w-full aspect-square object-cover rounded-md border"
                    loading="lazy"
                  />
                  <button
                    type="button"
                    onClick={() => onRemoveFile(idx)}
                    className="absolute top-1 right-1 w-7 h-7 rounded-full bg-black/70 text-white text-xs"
                    title="삭제"
                    disabled={creating}
                  >
                    ✕
                  </button>
                </div>
              ))}
            </div>
          ) : (
            <div className="mt-4 text-sm text-gray-500">첨부된 사진이 없습니다.</div>
          )}
        </div>

        {/* 제출 */}
        <div className="flex gap-2">
          <button
            type="submit"
            className="flex-1 py-3 rounded-md bg-black text-white font-medium hover:opacity-90 disabled:opacity-50"
            disabled={!isAuthenticated || creating}
          >
            {creating ? "등록 중..." : "리뷰 등록"}
          </button>

          <button
            type="button"
            onClick={() => navigate(`/products/${productId}`)}
            className="px-4 py-3 rounded-md border hover:bg-gray-50"
            disabled={creating}
          >
            취소
          </button>
        </div>
      </form>
    </div>
  );
}