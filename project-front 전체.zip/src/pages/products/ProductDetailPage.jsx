// src/pages/products/ProductDetailPage.jsx
import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import toast from "react-hot-toast";

import useAuthStore from "@/stores/authStore";
import useOrderStore from "@/stores/orderStore";
import useProductStore from "@/stores/productStore";
import useCartStore from "@/stores/cartStore";
import useRecentViewTracker from "@/hooks/useRecentViewTracker";

import ProductReviewSection from "@/components/review/ProductReviewSection";

export default function ProductDetailPage() {
  const { productId } = useParams();
  useRecentViewTracker(productId);

  const navigate = useNavigate();

  const { user, isAuthenticated } = useAuthStore();
  const { setDraftFromCart } = useOrderStore();
  const { addToCart } = useCartStore();

  const {
    fetchProductDetail,
    productById,
    detailLoadingById,
    detailErrorById,
    toggleWishlist, 
    wishlistMap,
  } = useProductStore();

  const product = productById[productId];
  const isLoading = detailLoadingById[productId];
  const isError = detailErrorById[productId];

  const { fetchWishlist } = useCartStore(); // cartStore에서 fetch함수 가져오기
  const isWished = wishlistMap ? wishlistMap[productId] : false;

  const [quantity, setQuantity] = useState(1);

  useEffect(() => {
    if (productId) fetchProductDetail(productId);
  }, [productId, fetchProductDetail]);

  // 수량 조절 함수
  const handleQuantity = (type) => {
    if (type === "plus") {
      setQuantity((prev) => prev + 1);
    } else {
      if (quantity > 1) setQuantity((prev) => prev - 1);
    }
  };

  // 찜하기 핸들러
  const onToggleWish = async () => {
    if (!isAuthenticated) {
      toast("로그인이 필요한 서비스입니다.");
      navigate("/login");
      return;
    }
    try {
      // store의 toggleWishlist는 추가 시 "added", 취소 시 "removed"를 반환하도록 구성
      const result = await toggleWishlist(productId);
      await fetchWishlist();
      
      if (result === "added") {
        toast.success("찜 목록에 추가되었습니다.");
      } else if (result === "removed") {
        toast.success("찜 목록에서 제거되었습니다."); 
      }
    } catch (e) {
      toast.error("찜하기 처리에 실패했습니다.");
    }
  };

  // ✅ 즉시 구매 → /order (draftSource="direct")
  const handleBuyNow = () => {
    if (!isAuthenticated) {
      toast("구매하려면 로그인해야 합니다.");
      navigate("/login", { replace: true });
      return;
    }
    if (!product) {
      toast.error("상품 정보를 불러오는 중입니다.");
      return;
    }

    setDraftFromCart(
      [
        {
          productId: Number(productId),
          quantity: quantity,
          product,
          price: product.price,
          name: product.productName,
        },
      ],
      user,
      "direct"
    );

    navigate("/order");
  };

  const onAddToCart = async () => {
    if (!isAuthenticated) {
      toast("장바구니는 로그인 후 이용 가능합니다.");
      navigate("/login", { replace: true });
      return;
    }

    try {
      // ✅ productId를 넘길 때 확실히 String 또는 Number로 변환하여 일관성 유지
      await addToCart({ 
        productId: Number(productId),
        quantity: quantity 
      });
      toast.success("장바구니에 담았습니다.");
      // navigate("/cart"); // ✅ 사용자가 계속 쇼핑하고 싶을 수 있으므로 주석 처리하거나 필요시 유지
    } catch (e) {
      toast.error("장바구니 담기에 실패했습니다.");
    }
  };

  const onGoBack = () => navigate(-1);

  if (isLoading) {
    return (
      <div className="max-w-5xl mx-auto px-4 py-10 text-center text-gray-500">
        불러오는 중...
      </div>
    );
  }

  if (isError) {
    return (
      <div className="max-w-5xl mx-auto px-4 py-10 text-center">
        <div className="text-red-500 font-semibold">상품 정보를 불러오지 못했습니다.</div>
        <button
          onClick={onGoBack}
          className="mt-4 px-4 py-2 border rounded-md hover:bg-gray-50"
        >
          뒤로가기
        </button>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="max-w-5xl mx-auto px-4 py-10 text-center text-gray-500">
        상품이 없습니다.
      </div>
    );
  }

  const name = product.productName || "상품";
  const price = product.price ? product.price.toLocaleString() : "가격 정보 없음";
  const imageUrl = product.imageUrl || null;
  const description = product.content || "상세 설명 없음";

  return (
    <div className="max-w-5xl mx-auto px-4 py-6">
      {/* 상단 버튼 */}
      <div className="flex items-center justify-between gap-3">
        <button type="button" onClick={onGoBack} className="px-3 py-2 rounded-md border text-sm hover:bg-gray-50">← 뒤로</button>
        <button type="button" onClick={() => navigate("/products")} className="px-3 py-2 rounded-md border text-sm hover:bg-gray-50">목록으로</button>
      </div>

      <div className="mt-5 grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* 상품 이미지 */}
        <div className="rounded-xl border bg-white overflow-hidden relative">
          <div className="aspect-[4/3] bg-gray-100">
            {imageUrl ? (
              <img src={imageUrl} alt={name} className="w-full h-full object-cover" loading="lazy" />
            ) : (
              <div className="w-full h-full flex items-center justify-center text-gray-400 text-sm">이미지 없음</div>
            )}
          </div>
          {/* 찜하기 버튼 (이미지 위 배치) */}
          <button 
            onClick={onToggleWish}
            className="absolute top-4 right-4 p-2 rounded-full bg-white/80 shadow-md hover:bg-white transition-all"
          >
            <svg 
              xmlns="http://www.w3.org/2000/svg" 
              className={`h-6 w-6 ${isWished ? 'text-red-500' : 'text-gray-400'}`} 
              fill={isWished ? "currentColor" : "none"} 
              viewBox="0 0 24 24" 
              stroke="currentColor"
            >
              <path strokeLinecap="round\" strokeLinejoin="round\" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
            </svg>
          </button>
        </div>

        {/* 상품 정보 및 구매 섹션 */}
        <div className="rounded-xl border bg-white p-5 flex flex-col justify-between">
          <div>
            <h1 className="text-2xl font-bold">{name}</h1>
            <div className="mt-3 text-xl font-extrabold text-black">
              {price ? `${price}원` : "가격 정보 없음"}
            </div>
            <p className="mt-4 text-sm text-gray-700 whitespace-pre-line">{description}</p>
          </div>

          <div className="mt-8 border-t pt-5">
            {/* 수량 조절 UI */}
            <div className="flex items-center justify-between mb-4">
              <span className="text-sm font-medium text-gray-600">수량</span>
              <div className="flex items-center border rounded-md">
                <button 
                  onClick={() => handleQuantity("minus")}
                  className="px-3 py-1 hover:bg-gray-100 text-lg border-r"
                >-</button>
                <span className="px-4 py-1 font-semibold">{quantity}</span>
                <button 
                  onClick={() => handleQuantity("plus")}
                  className="px-3 py-1 hover:bg-gray-100 text-lg border-l"
                >+</button>
              </div>
            </div>

            {/* 총 합계 */}
            <div className="flex items-center justify-between mb-6">
              <span className="text-sm font-medium text-gray-600">총 상품 금액</span>
              <span className="text-xl font-bold text-red-600">
                {(product.price * quantity).toLocaleString()}원
              </span>
            </div>

            <div className="flex gap-2">
              <button
                type="button"
                onClick={handleBuyNow}
                className="flex-1 py-4 rounded-md bg-black text-white font-bold hover:opacity-90 transition-opacity"
              >
                구매하기
              </button>

              <button
                type="button"
                onClick={onAddToCart}
                className="px-6 py-4 rounded-md border border-gray-300 font-bold hover:bg-gray-50 transition-colors"
              >
                장바구니
              </button>
            </div>

            {!isAuthenticated && (
              <div className="mt-3 text-xs text-center text-gray-500">
                * 구매/리뷰 작성/장바구니/찜하기는 로그인 후 가능합니다.
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="mt-12">
        <ProductReviewSection productId={productId} />
      </div>
    </div>
  );
}