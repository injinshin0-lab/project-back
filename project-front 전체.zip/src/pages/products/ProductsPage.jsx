// src/pages/products/ProductsPage.jsx
import { useEffect, useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import toast from "react-hot-toast";

import { getProductsApi } from "@/api/productApi";
import useCartStore from "@/stores/cartStore";

import useProductStore from "@/stores/productStore"; // ✅ 찜하기 위해 추가
import useAuthStore from "@/stores/authStore"; // ✅ 로그인 체크 위해 추가

function safeArray(x) {
  return Array.isArray(x) ? x : [];
}

function normalizeProductsResponse(res) {
  // axios 응답 구조에 따라 res.data 또는 res 확인
  const d = res?.data ?? res; 
  
  // 백엔드 PageResponseDto 구조: { list: [...], totalPage: 2, currentPage: 1 }
  const items = d.list ?? d.content ?? [];
  
  return {
    content: safeArray(items),
    totalPages: Number(d.totalPage ?? 1), // 백엔드 필드명: totalPage
    totalElements: Number(d.totalCount ?? items.length),
  };
}

function ProductCard({ p, onClick }) {
  const id = p.productId ?? p.id; 
  const name = p.productName ?? p.name ?? "이름 없는 상품";
  const price = Number(p.price ?? 0);
  const imageUrl = p.imageUrl ?? "";

  const addItem = useCartStore((s) => s.addToCart);
  const navigate = useNavigate();
  const { toggleWishlist, wishlistMap } = useProductStore();
  const { isAuthenticated } = useAuthStore();
  const isWished = wishlistMap[id] || false;
  

  // 장바구니 핸들러 수정
  const handleCart = async (e) => {
    e.stopPropagation();
    if (!isAuthenticated) {
      toast("로그인 후 이용 가능합니다.");
      navigate("/login");
      return;
    }
    try {
      // ✅ 기존: addItem(p, 1) -> 수정: 객체 형태로 전달 (상세페이지와 통일)
      await addItem({ productId: id, quantity: 1 });
      toast.success("장바구니에 담겼습니다.");
    } catch (err) {
      toast.error("장바구니 담기에 실패했습니다.");
    }
  };

  // ✅ 찜하기 핸들러 수정 (주석 처리 후 기능 구현)
  const handleWish = async (e) => {
    e.stopPropagation();
    if (!isAuthenticated) {
      toast("로그인 후 이용 가능합니다.");
      navigate("/login");
      return;
    }
    try {
      const result = await toggleWishlist(id);
      if (result === "added") toast.success("찜 목록에 추가되었습니다.");
      else if (result === "removed") toast.success("찜 목록에서 제거되었습니다.");
    } catch (err) {
      toast.error("찜하기 처리에 실패했습니다.");
    }
  };

  const handleBuy = (e) => {
    e.stopPropagation();

    if (!isAuthenticated) {
      toast("로그인 후 이용 가능합니다.");
      navigate("/login");
      return;
    }
    
    if (typeof addItem === 'function') {
      addItem({ productId: id, quantity: 1 });
      navigate(`/order`);
      toast.success("주문 페이지로 이동합니다.");
    } else {
      console.error("addItem 함수를 찾을 수 없습니다. store 설정을 확인하세요.");
      toast.error("주문 처리 중 오류가 발생했습니다.");
    }
  };

  return (
    <div
      onClick={() => onClick(id)}
      className="group relative text-left border border-gray-100 rounded-2xl overflow-hidden hover:shadow-xl transition-all duration-300 bg-white cursor-pointer"
    >
      {/* 이미지 영역 */}
      <div className="aspect-[5/5] bg-gray-50 relative overflow-hidden">
        {imageUrl ? (
          <img 
            src={`http://localhost:8080/images/${imageUrl}`} 
            alt={name} 
            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" 
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-gray-300">이미지 없음</div>
        )}
        
        {/* ✅ 찜 버튼: 상태에 따른 색상 변경 반영 */}
        <button 
          onClick={handleWish}
          className="absolute top-3 right-3 p-2 bg-white/80 backdrop-blur-md rounded-full shadow-sm hover:bg-white transition-colors"
        >
          <svg 
            xmlns="http://www.w3.org/2000/svg" 
            className={`h-5 w-5 ${isWished ? 'text-red-500' : 'text-gray-400'}`} 
            fill={isWished ? "currentColor" : "none"} 
            viewBox="0 0 24 24" 
            stroke="currentColor"
          >
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
          </svg>
        </button>
      </div>

      {/* 정보 영역 */}
      <div className="p-4">
        <div className="text-sm text-gray-400 mb-1">보감 추천</div>
        <div className="font-bold text-gray-800 line-clamp-1 text-lg mb-1">{name}</div>
        <div className="text-xl font-black text-black mb-4">
          {price.toLocaleString()}<span className="text-sm font-normal ml-0.5">원</span>
        </div>

        {/* 액션 버튼 그룹 */}
        <div className="flex gap-2">
          <button 
            onClick={handleCart}
            className="flex-1 py-2.5 border border-gray-200 rounded-xl text-sm font-bold hover:bg-gray-50 transition-colors flex justify-center items-center gap-1"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" />
            </svg>
            담기
          </button>
          <button 
            onClick={handleBuy}
            className="flex-[1.5] py-2.5 bg-black text-white rounded-xl text-sm font-bold hover:bg-gray-800 transition-colors"
          >
            바로구매
          </button>
        </div>
      </div>
    </div>
  );
}

export default function ProductsPage() {
  const navigate = useNavigate();
  const [sp, setSp] = useSearchParams();

  // 쿼리스트링 기반 상태 (새로고침/공유 가능)
  const q = sp.get("q") ?? "";
  const page = Number(sp.get("page") ?? "1") || 1; // 1-based
  const sort = sp.get("sort") ?? "latest"; // latest | price_asc | price_desc

  const [loading, setLoading] = useState(false);
  const [products, setProducts] = useState([]);
  const [totalPages, setTotalPages] = useState(1);

  const [keyword, setKeyword] = useState(q);
  const { fetchWishlist } = useProductStore();
  const { isAuthenticated } = useAuthStore();

  useEffect(() => {
    if (isAuthenticated) {
      fetchWishlist(); // 로그인 상태라면 찜 목록을 서버에서 가져옴
    }
  }, [isAuthenticated]);

  // ✅ 1. 데이터 페칭 로직 최적화
  useEffect(() => {
    const fetchProducts = async () => {
      setLoading(true);
      try {
        // 정렬 파라미터 구성
        let sortField = "latest";
        let order = "desc";
        if (sort === "price_asc") { sortField = "price"; order = "asc"; }
        if (sort === "price_desc") { sortField = "price"; order = "desc"; }

        const params = {
          page: page, 
          size: 12,
          keyword: q || undefined,
          sort: sortField,
          order: order,
        };

        const res = await getProductsApi(params);
        const norm = normalizeProductsResponse(res);

        setProducts(norm.content);
        setTotalPages(norm.totalPages || 1);

      } catch ( e ) {
        toast.error("상품 목록을 불러오지 못했습니다.");
        setProducts([]);
      } finally {
        setLoading(false);
      }
    };

    fetchProducts();
    // ✅ 객체인 sortParam 대신 기본 타입 변수들을 의존성에 넣어야 정확히 반응합니다.
  }, [page, q, sort]); 

  // 키워드 동기화 (주소창에 직접 q를 쳤을 때 입력창도 바뀌게)
  useEffect(() => {
    setKeyword(q);
  }, [q]);

  const goDetail = (id) => {
    if (id === undefined || id === null) return;
    navigate(`/products/${id}`);
  };

  const onSubmit = (e) => {
    e.preventDefault();
    const nextQ = keyword.trim();
    setSp((prev) => {
      const n = new URLSearchParams(prev);
      if (nextQ) n.set("q", nextQ);
      else n.delete("q");
      n.set("page", "1");
      // sort 유지
      return n;
    });
  };

  const onChangeSort = (e) => {
    const v = e.target.value;
    setSp((prev) => {
      const n = new URLSearchParams(prev);
      n.set("sort", v);
      n.set("page", "1");
      return n;
    });
  };

  const goPage = (p) => {
    setSp((prev) => {
      const n = new URLSearchParams(prev);
      n.set("page", String(p));
      return n;
    });
  };

  return (
    <div className="max-w-7xl mx-auto p-6 lg:p-10">
      {/* 상단 헤더 영역 */}
      <div className="mb-8 flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div>
          <h1 className="text-3xl font-black tracking-tight text-black">상품 목록</h1>
          <p className="text-gray-500 mt-2 text-lg">
            건강한 삶을 위한 보감의 특별한 제안
          </p>
        </div>

        {/* 정렬 필터 */}
        <div className="flex items-center gap-4">
          <select
            value={sort}
            onChange={onChangeSort}
            className="border-none bg-gray-100 rounded-full px-6 py-3 font-bold text-sm focus:ring-2 focus:ring-black outline-none cursor-pointer"
            title="정렬"
          >
            <option value="latest">최신순</option>
            <option value="price_asc">가격 낮은순</option>
            <option value="price_desc">가격 높은순</option>
          </select>
        </div>
      </div>

      {/* 검색 바 (개선됨) */}
      <div className="mb-10 max-w-2xl">
        <form onSubmit={onSubmit} className="relative group">
          <input
            value={keyword}
            onChange={(e) => setKeyword(e.target.value)}
            className="w-full border-2 border-gray-100 bg-gray-50 rounded-2xl px-6 py-4 outline-none focus:border-black focus:bg-white transition-all text-lg pr-20"
            placeholder="어떤 건강을 찾으시나요?"
          />
          <button type="submit" className="absolute right-2 top-2 bottom-2 px-6 rounded-xl bg-black text-white font-bold hover:bg-gray-800 transition-colors">
            검색
          </button>
        </form>
      </div>

      {/* 상품 리스트 그리드 */}
      {loading ? (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 animate-pulse">
          {[...Array(8)].map((_, i) => (
            <div key={i} className="h-80 bg-gray-100 rounded-2xl"></div>
          ))}
        </div>
      ) : products.length === 0 ? (
        <div className="py-32 text-center border-2 border-dashed border-gray-100 rounded-3xl">
          <div className="text-gray-400 text-xl font-medium mb-2">검색 결과가 없습니다.</div>
          <div className="text-sm text-gray-500 underline cursor-pointer" onClick={() => {setKeyword(""); setSp({});}}>전체 상품 보기</div>
        </div>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-x-6 gap-y-10">
          {products.map((p) => {
            const id = p.id ?? p.productId ?? p.product_id;
            return <ProductCard key={String(id)} p={p} onClick={goDetail} />;
          })}
        </div>
      )}

      {/* 페이지네이션 (개선된 goPage 연결) */}
      {totalPages > 1 && (
        <div className="flex justify-center items-center gap-6 mt-20">
          <button
            className="w-12 h-12 flex items-center justify-center border border-gray-200 rounded-full hover:bg-black hover:text-white transition-all disabled:opacity-30"
            onClick={() => goPage(page - 1)}
            disabled={page <= 1}
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
          </button>

          <div className="flex items-center font-bold text-lg">
            <span className="text-black">{page}</span>
            <span className="text-gray-300 mx-2">/</span>
            <span className="text-gray-400">{totalPages}</span>
          </div>

          <button
            className="w-12 h-12 flex items-center justify-center border border-gray-200 rounded-full hover:bg-black hover:text-white transition-all disabled:opacity-30"
            onClick={() => goPage(page + 1)}
            disabled={page >= totalPages}
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
          </button>
        </div>
      )}
    </div>
  );
}