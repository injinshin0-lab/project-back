export default function SearchPage() {
  return (
    <div style={{ padding: 24 }}>
      <h1>검색 결과</h1>
      <p>/search</p>
    </div>
  );
}