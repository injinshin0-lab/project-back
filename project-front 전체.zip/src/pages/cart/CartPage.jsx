// src/pages/cart/CartPage.jsx
import { useEffect, useMemo } from "react";
import { Link, useNavigate } from "react-router-dom";

import useAuthStore from "@/stores/authStore";
import useCartStore, { CART_VIEW } from "@/stores/cartStore";
import useOrderStore from "@/stores/orderStore";


function cn(...arr) {
  return arr.filter(Boolean).join(" ");
}

function getProductName(item) {
  return (
    item?.productName ||
    item?.name ||
    item?.product?.name ||
    item?.product?.productName ||
    "상품"
  );
}

function getProductId(item) {
  return item?.productId ?? item?.product?.id ?? item?.product?.productId ?? item?.product_id;
}

function getCartId(item) {
  // 백엔드 Select 쿼리에서 AS cartItemId를 사용하므로 이 값이 우선순위여야 함
  return item?.cartItemId || item?.id || item?.cartId;
}

function getPrice(item) {
  return item?.price ?? item?.product?.price ?? item?.productPrice ?? 0;
}

function getQty(item) {
  return item?.quantity ?? item?.qty ?? item?.count ?? 1;
}

function formatWon(n) {
  const num = Number(n || 0);
  return `${num.toLocaleString("ko-KR")}원`;
}

function EmptyState({ title, desc }) {
  return (
    <div className="rounded-xl border p-6 bg-white">
      <div className="text-lg font-semibold">{title}</div>
      {desc ? <div className="mt-2 text-sm text-gray-600">{desc}</div> : null}
    </div>
  );
}

function Tabs({ activeView, counts, onChange }) {
  const tabs = [
    { key: CART_VIEW.CART, label: "장바구니", count: counts.cart },
    { key: CART_VIEW.WISHLIST, label: "찜", count: counts.wishlist },
    { key: CART_VIEW.RECENT, label: "최근 본 상품", count: counts.recent },
  ];

  return (
    <div className="flex gap-2">
      {tabs.map((t) => (
        <button
          key={t.key}
          type="button"
          onClick={() => onChange(t.key)}
          className={cn(
            "px-4 py-2 rounded-full border text-sm",
            activeView === t.key ? "bg-black text-white border-black" : "bg-white hover:bg-gray-50"
          )}
        >
          {t.label}{" "}
          <span className={cn("ml-1", activeView === t.key ? "text-white/90" : "text-gray-600")}>
            ({t.count})
          </span>
        </button>
      ))}
    </div>
  );
}

function CartList({ items, loading, userId, onClear, onQtyChange, onRemove, onBuy }) {
  const total = useMemo(() => {
    return (items || []).reduce((acc, it) => acc + Number(getPrice(it)) * Number(getQty(it)), 0);
  }, [items]);

  if (loading) return <EmptyState title="불러오는 중..." />;
  if (!items?.length) {
    return <EmptyState title="장바구니가 비어있어요." desc="상품 상세에서 장바구니에 담아보세요!" />;
  }

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between gap-2">
        <div className="text-sm text-gray-700">
          총 {items.length}개 · 합계 <b>{formatWon(total)}</b>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={onBuy}
            className="text-sm px-3 py-2 rounded-lg bg-black text-white hover:bg-black/90"
          >
            구매하기
          </button>

          <button
            type="button"
            onClick={() => onClear(userId)}
            className="text-sm px-3 py-2 rounded-lg border bg-white hover:bg-gray-50"
          >
            전체 삭제
          </button>
        </div>
      </div>

      <div className="space-y-2">
        {items.map((it) => {
          const productId = getProductId(it);
          const cartId = getCartId(it);
          const qty = getQty(it);

          return (
            <div key={`${productId}-${cartId}`} className="rounded-xl border p-4 bg-white">
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <div className="font-semibold truncate">{getProductName(it)}</div>
                  <div className="mt-1 text-sm text-gray-600">가격: {formatWon(getPrice(it))}</div>
                </div>

                <button
                  type="button"
                  onClick={() => onRemove(productId)}
                  className="text-sm px-3 py-2 rounded-lg border bg-white hover:bg-gray-50"
                >
                  삭제
                </button>
              </div>

              <div className="mt-3 flex items-center gap-2">
                <span className="text-sm text-gray-700">수량</span>
                <button
                  type="button"
                  className="w-9 h-9 rounded-lg border bg-white hover:bg-gray-50"
                  onClick={() => onQtyChange(cartId, Math.max(1, Number(qty) - 1))}
                >
                  -
                </button>
                <div className="w-12 text-center text-sm">{qty}</div>
                <button
                  type="button"
                  className="w-9 h-9 rounded-lg border bg-white hover:bg-gray-50"
                  onClick={() => onQtyChange(cartId, Number(qty) + 1)}
                >
                  +
                </button>

                <div className="ml-auto text-sm">
                  소계: <b>{formatWon(Number(getPrice(it)) * Number(qty))}</b>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function WishlistList({ items, loading, onRemove, onAddToCart }) {
  if (loading) return <EmptyState title="불러오는 중..." />;
  if (!items?.length) return <EmptyState title="찜한 상품이 없어요." />;

  return (
    <div className="space-y-2">
      {items.map((it) => {
        const productId = getProductId(it);
        return (
          <div key={productId} className="rounded-xl border p-4 bg-white">
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0">
                <div className="font-semibold truncate">{getProductName(it)}</div>
                <div className="mt-1 text-sm text-gray-600">가격: {formatWon(getPrice(it))}</div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => onAddToCart(productId)}
                  className="text-sm px-3 py-2 rounded-lg border bg-black text-white hover:bg-black/90"
                >
                  장바구니 담기
                </button>

                <button
                  type="button"
                  onClick={() => onRemove(productId)}
                  className="text-sm px-3 py-2 rounded-lg border bg-white hover:bg-gray-50"
                >
                  찜 해제
                </button>
              </div>
            </div>

            {productId ? (
              <div className="mt-3">
                <Link to={`/products/${productId}`} className="text-sm underline text-gray-700 hover:text-black">
                  상품 보러가기
                </Link>
              </div>
            ) : null}
          </div>
        );
      })}
    </div>
  );
}

function RecentViewsList({ items, loading }) {
  if (loading) return <EmptyState title="불러오는 중..." />;
  if (!items?.length) return <EmptyState title="최근 본 상품이 없어요." />;

  return (
    <div className="space-y-2">
      {items.map((it) => {
        const productId = getProductId(it);
        return (
          <div key={productId} className="rounded-xl border p-4 bg-white">
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0">
                <div className="font-semibold truncate">{getProductName(it)}</div>
                <div className="mt-1 text-sm text-gray-600">가격: {formatWon(getPrice(it))}</div>
              </div>

              {productId ? (
                <Link
                  to={`/products/${productId}`}
                  className="text-sm px-3 py-2 rounded-lg border bg-white hover:bg-gray-50"
                >
                  상세
                </Link>
              ) : null}
            </div>
          </div>
        );
      })}
    </div>
  );
}

export default function CartPage() {
  const navigate = useNavigate();
  const { isAuthenticated, user } = useAuthStore();
  const userId = user?.id ?? user?.userId ?? user?.memberId ?? user?.uid;

  const { setDraftFromCart } = useOrderStore();

  const {
    activeView,
    setActiveView,

    cartItems,
    cartLoading,
    wishlist,
    wishlistLoading,
    recentViews,
    recentLoading,

    fetchCartItems,
    fetchWishlist,
    fetchRecentViews,

    clearCart,
    updateQuantity,
    removeCartItem,
    removeWishlist,

    addToCartFromWishlist,

    getCounts,
  } = useCartStore();

  const counts = useMemo(() => getCounts(), [cartItems, wishlist, recentViews, getCounts]);

  useEffect(() => {
    if (!isAuthenticated) return;

    fetchCartItems();
    fetchWishlist();
    if (userId) fetchRecentViews(userId);
  }, [isAuthenticated, userId]);

  const handleAddToCartFromWishlist = async (productId) => {
    await addToCartFromWishlist({ productId, quantity: 1, enableRemoveWishlist: false });
    setActiveView(CART_VIEW.CART);
  };

  const handleBuy = () => {
    if (!cartItems?.length) return;
    // ✅ 구매경로: 장바구니 구매
    setDraftFromCart(cartItems, user, "cart");
    navigate("/order");
  };

  return (
    <div className="max-w-4xl mx-auto p-4">
      <div className="flex items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold">장바구니</h1>
          <p className="text-sm text-gray-600 mt-1">
            한 페이지에서 장바구니/찜/최근 본 상품을 전환해서 볼 수 있어요.
          </p>
        </div>

        <Tabs activeView={activeView} counts={counts} onChange={setActiveView} />
      </div>

      <div className="mt-6">
        {!isAuthenticated ? (
          <EmptyState title="로그인이 필요해요." desc="로그인 후 장바구니/찜/최근 본 상품을 확인할 수 있어요." />
        ) : (
          <>
            {activeView === CART_VIEW.CART ? (
              <CartList
                items={cartItems}
                loading={cartLoading}
                userId={userId}
                onClear={clearCart}
                onQtyChange={updateQuantity}
                onRemove={removeCartItem}
                onBuy={handleBuy}
              />
            ) : null}

            {activeView === CART_VIEW.WISHLIST ? (
              <WishlistList
                items={wishlist}
                loading={wishlistLoading}
                onRemove={removeWishlist}
                onAddToCart={handleAddToCartFromWishlist}
              />
            ) : null}

            {activeView === CART_VIEW.RECENT ? (
              <RecentViewsList items={recentViews} loading={recentLoading} />
            ) : null}
          </>
        )}
      </div>
    </div>
  );
}