// src/pages/mypage/orders/OrderDetailPage.jsx
import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import toast from "react-hot-toast";
import useOrderHistoryStore from "@/stores/orderHistoryStore";

import { getMyOrderDetailApi } from "@/api/orderApi";

function priceKRW(v) {
  const n = Number(v);
  if (!Number.isFinite(n)) return "-";
  return n.toLocaleString("ko-KR");
}

function formatDate(v) {
  if (!v) return "";
  const d = new Date(v);
  return Number.isNaN(d.getTime()) ? String(v) : d.toLocaleString("ko-KR");
}

/* =========================
 * ✅ (추가) 상태 라벨 매핑 유틸
 * - 백엔드가 코드/영문/한글 섞여 와도 안전하게
 * ========================= */
const ORDER_STATUS_LABEL = {
  CREATED: "주문완료",
  PAID: "결제완료",
  PREPARING: "상품준비중",
  SHIPPING: "배송중",
  DELIVERED: "배송완료",
  CANCELED: "주문취소",
};

const PAYMENT_STATUS_LABEL = {
  READY: "결제대기",
  PAID: "결제완료",
  FAILED: "결제실패",
  CANCELED: "결제취소",
};

const PAYMENT_METHOD_LABEL = {
  card: "카드",
  transfer: "계좌이체",
  vbank: "무통장",
  CARD: "카드",
  TRANSFER: "계좌이체",
  VBANK: "무통장",
};

const SHIPPING_STATUS_LABEL = {
  READY: "배송준비",
  PREPARING: "상품준비중",
  SHIPPING: "배송중",
  DELIVERED: "배송완료",
  CANCELED: "취소/반품",
};

function toLabel(map, v, fallback = "-") {
  if (v == null || v === "") return fallback;
  return map?.[v] || String(v);
}

export default function OrderDetailPage() {
  const navigate = useNavigate();
  const { orderId } = useParams();

  const [loading, setLoading] = useState(false);
  const [detail, setDetail] = useState(null);

  useEffect(() => {
    const run = async () => {
      setLoading(true);
      try {
        const data = await getMyOrderDetailApi(orderId);
        setDetail(data);
      } catch {
        toast.error("주문 상세를 불러오지 못했습니다.");
      } finally {
        setLoading(false);
      }
    };
    run();
  }, [orderId]);

  const items =
    detail?.items ??
    detail?.orderItems ??
    detail?.products ??
    detail?.content ??
    [];

  const totalPrice =
    detail?.totalPrice ?? detail?.amount ?? detail?.total_amount ?? null;

  const status = detail?.status ?? detail?.orderStatus ?? "상태 미확인";
  const createdAt = detail?.createdAt ?? detail?.created_at ?? detail?.orderDate;

  const receiverName =
    detail?.receiverName ?? detail?.recipient ?? detail?.name ?? "-";
  const receiverPhone =
    detail?.receiverPhone ?? detail?.phone ?? detail?.tel ?? "-";

  const addressLine = [
    detail?.postcode ?? detail?.zipcode,
    detail?.address1 ?? detail?.address,
    detail?.address2,
  ]
    .filter(Boolean)
    .join(" ");

  /* =========================
   * ✅ (추가) 결제/배송 관련 필드 안전 추출
   * ========================= */
  const paymentMethodRaw =
    detail?.paymentMethod ??
    detail?.payment_method ??
    detail?.payMethod ??
    detail?.pay_method ??
    detail?.method ??
    null;

  const paymentStatusRaw =
    detail?.paymentStatus ??
    detail?.payment_status ??
    detail?.payStatus ??
    detail?.pay_status ??
    detail?.paidStatus ??
    null;

  const paymentPriceRaw =
    detail?.paymentPrice ??
    detail?.payment_price ??
    detail?.paidAmount ??
    detail?.paid_amount ??
    null;

  const shippingStatusRaw =
    detail?.shippingStatus ??
    detail?.shipping_status ??
    detail?.deliveryStatus ??
    detail?.delivery_status ??
    detail?.shipStatus ??
    null;

  const paymentMethodLabel = toLabel(PAYMENT_METHOD_LABEL, paymentMethodRaw, "-");
  const paymentStatusLabel = toLabel(PAYMENT_STATUS_LABEL, paymentStatusRaw, "-");
  const shippingStatusLabel = toLabel(SHIPPING_STATUS_LABEL, shippingStatusRaw, null);

  const paidAmount =
    paymentPriceRaw != null ? paymentPriceRaw : totalPrice;

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <div className="flex items-end justify-between gap-3 flex-wrap">
        <div>
          <h1 className="text-2xl font-bold">주문 상세</h1>
          <p className="text-sm text-gray-500 mt-1">
            주문번호: <span className="font-medium">{orderId}</span>
          </p>
        </div>

        <div className="flex gap-2">
          <button
            type="button"
            onClick={() => navigate("/mypage/orders")}
            className="px-3 py-2 rounded-md border text-sm hover:bg-gray-50"
          >
            목록으로
          </button>
          <button
            type="button"
            onClick={() => navigate(`/mypage/orders/${orderId}/cancel`)}
            className="px-3 py-2 rounded-md border text-sm hover:bg-gray-50"
          >
            취소/반품 신청
          </button>
        </div>
      </div>

      {loading ? (
        <div className="py-10 text-center text-gray-500">불러오는 중...</div>
      ) : !detail ? (
        <div className="py-16 text-center text-gray-500">상세 정보가 없습니다.</div>
      ) : (
        <div className="mt-6 space-y-4">
          <div className="p-6 rounded-2xl border bg-white">
            <div className="font-bold text-lg">주문 정보</div>
            <div className="mt-3 text-sm text-gray-700 space-y-1">
              <div>주문일: {formatDate(createdAt)}</div>
              <div>
                상태:{" "}
                <span className="font-semibold">
                  {ORDER_STATUS_LABEL[status] || String(status)}
                </span>
              </div>

              {/* ✅ (추가) 배송상태가 있으면 함께 표시 */}
              {shippingStatusLabel ? (
                <div>
                  배송상태:{" "}
                  <span className="font-semibold">{shippingStatusLabel}</span>
                </div>
              ) : null}

              <div>
                결제금액:{" "}
                <span className="font-bold">
                  {paidAmount != null ? `${priceKRW(paidAmount)}원` : "-"}
                </span>
              </div>
            </div>
          </div>

          {/* ✅ 결제 정보 (추가) */}
          <div className="p-6 rounded-2xl border bg-white">
            <div className="font-bold text-lg">결제 정보</div>

            <div className="mt-3 text-sm text-gray-700 space-y-1">
              <div>
                결제 수단:{" "}
                <span className="font-medium">
                  {detail?.paymentMethod ??
                    detail?.payMethod ??
                    detail?.method ??
                    "정보 없음"}
                </span>
              </div>

              <div>
                결제 상태:{" "}
                <span className="font-medium">
                  {detail?.paymentStatus ??
                    detail?.payStatus ??
                    "미확인"}
                </span>
              </div>

              <div>
                결제 금액:{" "}
                <span className="font-bold">
                  {detail?.paidAmount != null
                    ? `${priceKRW(detail.paidAmount)}원`
                    : totalPrice != null
                    ? `${priceKRW(totalPrice)}원`
                    : "-"}
                </span>
              </div>

              <div>
                결제일:{" "}
                <span>
                  {formatDate(
                    detail?.paidAt ??
                      detail?.paymentDate ??
                      detail?.approvedAt
                  ) || "-"}
                </span>
              </div>
            </div>
          </div>


          {/* ✅ 기존 배송 정보 박스 유지 */}
          <div className="p-6 rounded-2xl border bg-white">
            <div className="font-bold text-lg">배송 정보</div>
            <div className="mt-3 text-sm text-gray-700 space-y-1">
              <div>수령인: {receiverName}</div>
              <div>연락처: {receiverPhone}</div>
              <div>주소: {addressLine || "-"}</div>
              {detail?.memo && <div>메모: {detail.memo}</div>}
            </div>
          </div>

          {/* ✅ 기존 주문 상품 박스 유지 */}
          <div className="p-6 rounded-2xl border bg-white">
            <div className="font-bold text-lg">주문 상품</div>

            {Array.isArray(items) && items.length ? (
              <div className="mt-4 space-y-2">
                {items.map((it, idx) => {
                  const name =
                    it?.productName ?? it?.name ?? it?.product?.name ?? "상품";
                  const qty = it?.quantity ?? it?.qty ?? 1;
                  const price = 
                    it?.price ?? it?.productPrice ?? it?.product?.price ?? 0;

                  return (
                    <div
                      key={it?.id ?? it?.orderItemId ?? idx}
                      className="flex items-center justify-between text-sm"
                    >
                      <div className="truncate mr-3">
                        {name} <span className="text-gray-500">x {qty}</span>
                      </div>
                      <div className="font-medium">
                        {priceKRW(Number(price) * Number(qty))}원
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="mt-3 text-sm text-gray-500">
                주문 상품 정보가 없습니다.
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}