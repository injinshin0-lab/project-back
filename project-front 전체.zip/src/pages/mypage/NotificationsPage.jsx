// src/pages/mypage/NotificationsPage.jsx
import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import toast from "react-hot-toast";

import useMypageStore from "@/stores/mypageStore";

function getId(n) {
  return n?.id ?? n?.notificationId ?? n?.notificationsId;
}

function formatDate(v) {
  if (!v) return "";
  const d = new Date(v);
  return Number.isNaN(d.getTime()) ? String(v) : d.toLocaleString("ko-KR");
}

export default function NotificationsPage() {
  const navigate = useNavigate();

  const notifications = useMypageStore((s) => s.notifications);
  const loading = useMypageStore((s) => s.notificationsLoading);

  const fetchNotifications = useMypageStore((s) => s.fetchNotifications);
  const readNotification = useMypageStore((s) => s.readNotification);
  const readAllNotifications = useMypageStore((s) => s.readAllNotifications);
  const deleteNotification = useMypageStore((s) => s.deleteNotification);

  useEffect(() => {
    fetchNotifications().catch(() =>
      toast.error("알림을 불러오지 못했습니다.")
    );
    // eslint-disable-next-line
  }, []);

  const onRead = async (id) => {
    try {
      await readNotification(id);
    } catch {
      toast.error("읽음 처리 실패");
    }
  };

  const onReadAll = async () => {
    try {
      await readAllNotifications();
      toast.success("모든 알림을 읽음 처리했습니다.");
    } catch {
      toast.error("전체 읽음 처리 실패");
    }
  };

  const onDelete = async (id) => {
    if (!window.confirm("이 알림을 삭제할까요?")) return;
    try {
      await deleteNotification(id);
    } catch {
      toast.error("삭제 실패");
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <div className="flex items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold">알림함</h1>
          <p className="text-sm text-gray-500 mt-1">
            주문/리뷰/문의 관련 알림을 확인하세요.
          </p>
        </div>

        <div className="flex gap-2">
          <button
            onClick={() => navigate("/mypage")}
            className="px-3 py-2 rounded-md border text-sm"
          >
            마이페이지
          </button>
          <button
            onClick={onReadAll}
            className="px-3 py-2 rounded-md border text-sm"
          >
            전체 읽음
          </button>
          <button
            onClick={() => navigate("/mypage/notifications/settings")}
            className="px-3 py-2 rounded-md bg-black text-white text-sm"
          >
            알림 설정
          </button>
        </div>
      </div>

      <div className="mt-6">
        {loading ? (
          <div className="py-10 text-center text-gray-500">불러오는 중...</div>
        ) : notifications.length ? (
          <div className="space-y-3">
            {notifications.map((n) => {
              const id = getId(n);
              const read = n?.read ?? n?.isRead;
              return (
                <div
                  key={id}
                  className={`p-5 rounded-2xl border bg-white ${
                    read ? "opacity-70" : ""
                  }`}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <div className="font-bold">
                        {n?.title ?? "알림"}
                      </div>
                      <div className="mt-1 text-sm text-gray-700">
                        {n?.content ?? n?.message ?? ""}
                      </div>
                      <div className="mt-1 text-xs text-gray-500">
                        {formatDate(n?.createdAt ?? n?.created_at)}
                      </div>
                    </div>

                    <div className="flex gap-2 shrink-0">
                      {!read && (
                        <button
                          onClick={() => onRead(id)}
                          className="px-3 py-2 rounded-md border text-sm"
                        >
                          읽음
                        </button>
                      )}
                      <button
                        onClick={() => onDelete(id)}
                        className="px-3 py-2 rounded-md border text-sm"
                      >
                        삭제
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="py-16 text-center text-gray-500">
            알림이 없습니다.
          </div>
        )}
      </div>
    </div>
  );
}