// src/pages/mypage/NotificationSettingsPage.jsx
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import toast from "react-hot-toast";

import useMypageStore from "@/stores/mypageStore";

/**
 * 알림 설정
 * PUT /api/v1/users/settings/{userId}
 */

export default function NotificationSettingsPage() {
  const navigate = useNavigate();

  const updateNotificationSettings =
    useMypageStore((s) => s.updateNotificationSettings);

  const [form, setForm] = useState({
    order: true,
    review: true,
    inquiry: true,
    marketing: false,
  });

  const onChange = (e) => {
    const { name, checked } = e.target;
    setForm((p) => ({ ...p, [name]: checked }));
  };

  const onSubmit = async (e) => {
    e.preventDefault();
    try {
      await updateNotificationSettings(form);
      toast.success("알림 설정이 저장되었습니다.");
      navigate("/mypage/notifications", { replace: true });
    } catch {
      toast.error("설정 저장 실패");
    }
  };

  return (
    <div className="max-w-3xl mx-auto px-4 py-8">
      <div className="flex items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold">알림 설정</h1>
          <p className="text-sm text-gray-500 mt-1">
            받고 싶은 알림을 선택하세요.
          </p>
        </div>

        <button
          onClick={() => navigate("/mypage/notifications")}
          className="px-3 py-2 rounded-md border text-sm"
        >
          알림함으로
        </button>
      </div>

      <form onSubmit={onSubmit} className="mt-6 space-y-4">
        <div className="p-6 rounded-2xl border bg-white space-y-3">
          <label className="flex items-center gap-2">
            <input
              type="checkbox"
              name="order"
              checked={form.order}
              onChange={onChange}
            />
            주문/배송 알림
          </label>

          <label className="flex items-center gap-2">
            <input
              type="checkbox"
              name="review"
              checked={form.review}
              onChange={onChange}
            />
            리뷰/답변 알림
          </label>

          <label className="flex items-center gap-2">
            <input
              type="checkbox"
              name="inquiry"
              checked={form.inquiry}
              onChange={onChange}
            />
            문의 알림
          </label>

          <label className="flex items-center gap-2">
            <input
              type="checkbox"
              name="marketing"
              checked={form.marketing}
              onChange={onChange}
            />
            마케팅/이벤트 알림
          </label>
        </div>

        <div className="flex gap-2">
          <button
            type="submit"
            className="flex-1 py-3 rounded-md bg-black text-white"
          >
            저장하기
          </button>
          <button
            type="button"
            onClick={() => navigate("/mypage/notifications")}
            className="px-4 py-3 rounded-md border"
          >
            취소
          </button>
        </div>
      </form>
    </div>
  );
}