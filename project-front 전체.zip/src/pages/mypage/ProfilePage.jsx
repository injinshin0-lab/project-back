// src/pages/mypage/NotificationsPage.jsx
import { useEffect, useMemo, useState } from "react";
import useAuthStore from "@/stores/authStore";
import useNotificationStore from "@/stores/notificationStore";

// <<<<<<< HEAD
function getNotificationId(n) {
  return n?.id ?? n?.notificationsId ?? null;
// import CategoriesSection from "@/components/auth/signup/CategoriesSection";

// /**
//  * 마이페이지 - 내 정보 수정
//  * API(요구서):
//  * - PATCH /api/v1/users/{userId}  (비밀번호 제외)
//  *
//  * 관심분야:
//  * - categoryStore 트리 재사용
//  * - leaf ids만 최종 payload에 넣음
//  */

// const MAX_CATEGORIES = 5;

// function pickUserId(user) {
//   return user?.userId ?? user?.id ?? user?.user_id ?? null;
}

function getIsRead(n) {
  return Boolean(n?.isRead ?? n?.read);
}

function pickTitle(n) {
  return n?.title || n?.notificationTitle || n?.type || "알림";
}

function pickMessage(n) {
  return n?.message || n?.content || n?.body || "";
}

function pickCreatedAt(n) {
  return n?.createdAt || n?.created_at || n?.createdDate || n?.regDate || "";
}

export default function NotificationsPage() {
  const user = useAuthStore((s) => s.user);
  const isAuthenticated = useAuthStore((s) => s.isAuthenticated);

  const {
    loading,
    list,
    page,
    totalPage,
    setPage,
    fetchNotifications,
    markAsRead,
    markAllAsRead,
    removeNotification,
    settings,
    updateSettings,
  } = useNotificationStore();

  // 설정 UI(로컬)
  const [enabled, setEnabled] = useState(settings.enabled);

  useEffect(() => {
    setEnabled(settings.enabled);
  }, [settings.enabled]);

  useEffect(() => {
    if (!isAuthenticated) return;
    fetchNotifications(user);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isAuthenticated, page]);

  const unreadCount = useMemo(() => {
    return list.filter((n) => !getIsRead(n)).length;
  }, [list]);

  const onRefresh = () => {
    fetchNotifications(user);
  };

  const onSaveSettings = () => {
    updateSettings(user, { enabled });
  };

  const goPrev = () => setPage(Math.max(1, page - 1));
  const goNext = () => setPage(Math.min(totalPage, page + 1));

  if (!isAuthenticated) {
    return (
      <div style={{ padding: 16 }}>
        <h2 style={{ fontSize: 20, fontWeight: 900 }}>알림</h2>
        <div style={{ marginTop: 10, color: "#666" }}>
          로그인 후 이용 가능합니다.
        </div>
      </div>
    );
  }

  return (
    <div style={{ padding: 16, maxWidth: 980 }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 10 }}>
        <h2 style={{ fontSize: 22, fontWeight: 900, margin: 0 }}>
          알림
          <span style={{ fontSize: 13, color: "#666", fontWeight: 700, marginLeft: 10 }}>
            (미읽음 {unreadCount}개)
          </span>
        </h2>

        <div style={{ display: "flex", gap: 8 }}>
          <button
            onClick={onRefresh}
            disabled={loading}
            style={{
              padding: "10px 12px",
              borderRadius: 10,
              border: "1px solid #333",
              background: "#fff",
              cursor: "pointer",
              fontWeight: 800,
            }}
          >
            새로고침
          </button>

          <button
            onClick={() => markAllAsRead(user)}
            disabled={loading || list.length === 0}
            style={{
              padding: "10px 12px",
              borderRadius: 10,
              border: "1px solid #333",
              background: "#fff",
              cursor: "pointer",
              fontWeight: 800,
            }}
          >
            전체 읽음
          </button>
        </div>
      </div>

      {/* 알림 설정 */}
      <div
        style={{
          marginTop: 12,
          border: "1px solid #ddd",
          borderRadius: 14,
          padding: 14,
          background: "#fff",
        }}
      >
        <div style={{ fontWeight: 900, marginBottom: 10 }}>알림 설정</div>

        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 12 }}>
          <div style={{ color: "#444", lineHeight: 1.5 }}>
            알림을 받기
            <div style={{ fontSize: 12, color: "#888" }}>
              (답변/주문/이벤트 등 알림 수신 여부)
            </div>
          </div>

          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <label style={{ display: "flex", alignItems: "center", gap: 8, cursor: "pointer" }}>
              <input
                type="checkbox"
                checked={enabled}
                onChange={(e) => setEnabled(e.target.checked)}
              />
              <span style={{ fontWeight: 800 }}>{enabled ? "ON" : "OFF"}</span>
            </label>

            <button
              onClick={onSaveSettings}
              disabled={loading}
              style={{
                padding: "10px 12px",
                borderRadius: 10,
                border: "1px solid #333",
                background: "#fff",
                cursor: "pointer",
                fontWeight: 800,
              }}
            >
              저장
            </button>
          </div>
        </div>
      </div>

      {/* 목록 */}
      <div style={{ marginTop: 12 }}>
        {list.length === 0 ? (
          <div style={{ padding: 14, color: "#666" }}>알림이 없습니다.</div>
        ) : (
          <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
            {list.map((n) => {
              const id = getNotificationId(n);
              const isRead = getIsRead(n);
              const title = pickTitle(n);
              const msg = pickMessage(n);
              const createdAt = pickCreatedAt(n);

              return (
                <div
                  key={id ?? Math.random()}
                  style={{
                    border: "1px solid #ddd",
                    borderRadius: 14,
                    padding: 14,
                    background: isRead ? "#fff" : "#f6fbff",
                  }}
                >
                  <div style={{ display: "flex", justifyContent: "space-between", gap: 12 }}>
                    <div>
                      <div style={{ fontWeight: 900, fontSize: 16 }}>
                        {title}
                        {!isRead && (
                          <span style={{ marginLeft: 8, fontSize: 12, color: "#1f6feb", fontWeight: 900 }}>
                            NEW
                          </span>
                        )}
                      </div>
                      <div style={{ marginTop: 6, whiteSpace: "pre-wrap", color: "#333" }}>
                        {msg}
                      </div>
                      {createdAt ? (
                        <div style={{ marginTop: 8, fontSize: 12, color: "#888" }}>
                          {createdAt}
                        </div>
                      ) : null}
                    </div>

                    <div style={{ display: "flex", flexDirection: "column", gap: 8, minWidth: 120 }}>
                      <button
                        onClick={() => markAsRead(user, id)}
                        disabled={loading || isRead || !id}
                        style={{
                          padding: "10px 12px",
                          borderRadius: 10,
                          border: "1px solid #333",
                          background: "#fff",
                          cursor: "pointer",
                          fontWeight: 800,
                        }}
                      >
                        읽음
                      </button>

                      <button
                        onClick={() => removeNotification(id)}
                        disabled={loading || !id}
                        style={{
                          padding: "10px 12px",
                          borderRadius: 10,
                          border: "1px solid #333",
                          background: "#fff",
                          cursor: "pointer",
                          fontWeight: 800,
                        }}
                      >
                        삭제
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* 페이지네이션(서버가 page 지원할 때만 의미 있음) */}
      <div style={{ display: "flex", gap: 8, marginTop: 14, alignItems: "center" }}>
        <button
          onClick={goPrev}
          disabled={loading || page <= 1}
          style={{ padding: "8px 12px", borderRadius: 10, border: "1px solid #ccc" }}
        >
          이전
        </button>
        <div style={{ color: "#666", fontWeight: 800 }}>
          {page} / {totalPage}
        </div>
        <button
          onClick={goNext}
          disabled={loading || page >= totalPage}
          style={{ padding: "8px 12px", borderRadius: 10, border: "1px solid #ccc" }}
        >
          다음
        </button>
      </div>
    </div>
  );
}