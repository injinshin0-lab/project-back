// src/pages/mypage/MyReviewsPage.jsx
import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import toast from "react-hot-toast";

import useMypageStore from "@/stores/mypageStore";

/**
 * 내가 쓴 리뷰
 * - API: GET /api/v1/users/{userId}/reviews
 * - 페이지네이션/정렬은 백엔드 스펙에 따라 params로 넘길 수 있게 설계
 */

function getReviewId(r) {
  return r?.id ?? r?.reviewId ?? r?.review_id;
}

function formatDate(v) {
  if (!v) return "";
  // 문자열/타임스탬프 모두 대응
  const d = new Date(v);
  if (Number.isNaN(d.getTime())) return String(v);
  return d.toLocaleDateString("ko-KR");
}

function starText(n) {
  const v = Number(n);
  if (!Number.isFinite(v)) return "-";
  return "★".repeat(Math.max(0, Math.min(5, v))) + "☆".repeat(Math.max(0, 5 - v));
}

export default function MyReviewsPage() {
  const navigate = useNavigate();

  const myReviews = useMypageStore((s) => s.myReviews);
  const myReviewsLoading = useMypageStore((s) => s.myReviewsLoading);
  const fetchMyReviews = useMypageStore((s) => s.fetchMyReviews);

  // 간단 필터/페이징 (백엔드 스펙 맞추기 쉬움)
  const [page, setPage] = useState(1); // 서버가 0-based면 store/api에서 변환해도 됨
  const [size] = useState(10);

  useEffect(() => {
    fetchMyReviews({ page, size }).catch(() =>
      toast.error("리뷰 목록을 불러오지 못했습니다.")
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [page, size]);

  const list = useMemo(() => (Array.isArray(myReviews) ? myReviews : []), [myReviews]);

  return (
    <div className="max-w-5xl mx-auto px-4 py-8">
      <div className="flex items-end justify-between gap-3 flex-wrap">
        <div>
          <h1 className="text-2xl font-bold">내가 쓴 리뷰</h1>
          <p className="text-sm text-gray-500 mt-1">
            내가 작성한 리뷰를 확인할 수 있습니다.
          </p>
        </div>

        <div className="flex gap-2">
          <button
            type="button"
            onClick={() => navigate("/mypage")}
            className="px-3 py-2 rounded-md border text-sm hover:bg-gray-50"
          >
            마이페이지로
          </button>
          <button
            type="button"
            onClick={() => navigate("/products")}
            className="px-3 py-2 rounded-md border text-sm hover:bg-gray-50"
          >
            상품 보러가기
          </button>
        </div>
      </div>

      {/* 목록 */}
      <div className="mt-6">
        {myReviewsLoading ? (
          <div className="py-10 text-center text-gray-500">불러오는 중...</div>
        ) : list.length ? (
          <div className="space-y-3">
            {list.map((r, idx) => {
              const id = getReviewId(r) ?? idx;

              const productId =
                r?.productId ?? r?.product_id ?? r?.product?.id ?? null;

              const productName =
                r?.productName ??
                r?.product?.name ??
                r?.product_title ??
                "상품";

              const rating = r?.rating ?? r?.score ?? r?.star ?? null;

              const content = r?.content ?? r?.body ?? r?.review ?? "";

              const createdAt = r?.createdAt ?? r?.created_at ?? r?.createdDate ?? "";

              const images =
                r?.images ??
                r?.imageUrls ??
                r?.photos ??
                [];

              const imageList = Array.isArray(images) ? images : [];

              return (
                <div key={id} className="p-5 rounded-2xl border bg-white">
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <div className="font-bold text-lg truncate">
                        {productName}
                      </div>
                      <div className="mt-1 text-sm text-gray-600">
                        <span className="font-medium text-gray-900">
                          {starText(rating)}
                        </span>
                        <span className="ml-2">{formatDate(createdAt)}</span>
                      </div>
                    </div>

                    {productId && (
                      <button
                        type="button"
                        onClick={() => navigate(`/products/${productId}`)}
                        className="px-3 py-2 rounded-md border text-sm hover:bg-gray-50 shrink-0"
                      >
                        상품보기
                      </button>
                    )}
                  </div>

                  {content ? (
                    <div className="mt-3 text-sm text-gray-800 whitespace-pre-line">
                      {content}
                    </div>
                  ) : (
                    <div className="mt-3 text-sm text-gray-500">
                      내용이 없습니다.
                    </div>
                  )}

                  {imageList.length ? (
                    <div className="mt-4 flex gap-2 flex-wrap">
                      {imageList.slice(0, 6).map((url, i) => (
                        <div
                          key={`${id}-img-${i}`}
                          className="w-24 h-24 rounded-lg border bg-gray-100 overflow-hidden"
                        >
                          {/* url이 string이 아닐 수도 있어서 안전 처리 */}
                          {typeof url === "string" && url ? (
                            <img
                              src={url}
                              alt="review"
                              className="w-full h-full object-cover"
                              loading="lazy"
                            />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center text-xs text-gray-400">
                              이미지
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  ) : null}
                </div>
              );
            })}
          </div>
        ) : (
          <div className="py-16 text-center text-gray-500">
            작성한 리뷰가 없습니다.
          </div>
        )}
      </div>

      {/* 간단 페이지 이동(백엔드가 totalPages 주면 나중에 개선) */}
      <div className="mt-6 flex justify-center gap-2">
        <button
          type="button"
          onClick={() => setPage((p) => Math.max(1, p - 1))}
          className="px-4 py-2 rounded-md border text-sm hover:bg-gray-50"
        >
          이전
        </button>
        <div className="px-4 py-2 text-sm text-gray-700">페이지 {page}</div>
        <button
          type="button"
          onClick={() => setPage((p) => p + 1)}
          className="px-4 py-2 rounded-md border text-sm hover:bg-gray-50"
        >
          다음
        </button>
      </div>
    </div>
  );
}