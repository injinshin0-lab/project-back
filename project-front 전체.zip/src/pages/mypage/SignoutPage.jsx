// src/pages/mypage/SignoutPage.jsx
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import toast from "react-hot-toast";

import useAuthStore from "@/stores/authStore";
import useMypageStore from "@/stores/mypageStore";

/**
 * 회원탈퇴
 * - 탈퇴 사유 입력 후 계정 삭제
 * - API: POST /api/v1/users/{userId}/delete
 * - 성공 시 로그아웃 처리 + 로그인 화면 이동
 */

export default function SignoutPage() {
  const navigate = useNavigate();

  const user = useAuthStore((s) => s.user);
  const logout = useAuthStore((s) => s.logout);

  const loading = useMypageStore((s) => s.loading);
  const deleteAccount = useMypageStore((s) => s.deleteAccount);

  const [reason, setReason] = useState("");
  const [confirmed, setConfirmed] = useState(false);

  const userName =
    user?.name ||
    user?.user_name ||
    user?.username ||
    user?.loginId ||
    "사용자";

  const onSubmit = async (e) => {
    e.preventDefault();

    const v = reason.trim();
    if (!v) return toast.error("탈퇴 사유를 입력해주세요.");
    if (!confirmed) return toast.error("안내사항 확인에 체크해주세요.");

    const ok = window.confirm(
      "정말 탈퇴하시겠습니까?\n탈퇴 후에는 계정 복구가 어려울 수 있습니다."
    );
    if (!ok) return;

    try {
      await deleteAccount({ reason: v });

      // ✅ 서버 탈퇴 성공 후 로그아웃
      try {
        await logout();
      } catch {
        // 로그아웃 API 실패해도 진행
      }

      toast.success("회원탈퇴가 완료되었습니다.");
      navigate("/login", { replace: true });
    } catch (e2) {
      toast.error("회원탈퇴에 실패했습니다.");
    }
  };

  return (
    <div className="max-w-3xl mx-auto px-4 py-8">
      <div className="flex items-end justify-between gap-3 flex-wrap">
        <div>
          <h1 className="text-2xl font-bold text-red-600">회원탈퇴</h1>
          <p className="text-sm text-gray-600 mt-1">
            {userName} 님, 탈퇴 전 안내사항을 확인해주세요.
          </p>
        </div>

        <button
          type="button"
          onClick={() => navigate("/mypage")}
          className="px-3 py-2 rounded-md border text-sm hover:bg-gray-50"
        >
          마이페이지로
        </button>
      </div>

      <form onSubmit={onSubmit} className="mt-6 space-y-5">
        {/* 경고 */}
        <div className="p-6 rounded-2xl border bg-white">
          <div className="font-bold text-lg">꼭 확인해주세요</div>
          <ul className="mt-3 list-disc pl-5 text-sm text-gray-700 space-y-2">
            <li>탈퇴하면 계정 정보 및 일부 데이터는 복구가 어려울 수 있습니다.</li>
            <li>주문/배송/환불 진행 중인 내역이 있다면 처리 후 탈퇴를 권장합니다.</li>
            <li>탈퇴 후 동일 아이디/이메일 재가입 정책은 백엔드 규칙을 따릅니다.</li>
          </ul>

          <label className="mt-4 flex items-start gap-2 text-sm">
            <input
              type="checkbox"
              checked={confirmed}
              onChange={(e) => setConfirmed(e.target.checked)}
              className="mt-1"
            />
            <span className="text-gray-800">
              위 안내사항을 확인했으며, 탈퇴에 동의합니다.
            </span>
          </label>
        </div>

        {/* 탈퇴 사유 */}
        <div className="p-6 rounded-2xl border bg-white">
          <div className="font-bold text-lg">탈퇴 사유</div>
          <p className="mt-1 text-sm text-gray-600">
            서비스 개선에 참고하기 위해 사유를 입력해주세요.
          </p>

          <textarea
            value={reason}
            onChange={(e) => setReason(e.target.value)}
            className="mt-4 w-full min-h-[140px] px-3 py-2 border rounded-md"
            placeholder="예: 사용 빈도가 낮아요 / 상품이 부족해요 / 기타..."
          />
        </div>

        {/* 버튼 */}
        <div className="flex gap-2">
          <button
            type="submit"
            disabled={loading}
            className="flex-1 py-3 rounded-md bg-red-600 text-white font-medium hover:opacity-90 disabled:opacity-50"
          >
            {loading ? "처리 중..." : "탈퇴하기"}
          </button>

          <button
            type="button"
            onClick={() => navigate("/mypage")}
            disabled={loading}
            className="px-4 py-3 rounded-md border hover:bg-gray-50 disabled:opacity-50"
          >
            취소
          </button>
        </div>
      </form>
    </div>
  );
}