// src/pages/mypage/AddressesPage.jsx
import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import toast from "react-hot-toast";

import useMypageStore from "@/stores/mypageStore";

import loadDaumPostcode from "@/utils/loadDaumPostcode";

function getAddressId(a) {
  return a?.id ?? a?.addressId ?? a?.address_id;
}

function safe(v) {
  return String(v ?? "");
}

function buildAddressLine(a) {
  const postcode = a?.postcode || "";
  const addr1 = a?.address || "";
  const addr2 = a?.detailAddress || ""; // address2 대신 detail 사용
  const line = [postcode && `(${postcode})`, addr1, addr2].filter(Boolean).join(" ");
  return line || "-";
}

export default function AddressesPage() {
  const navigate = useNavigate();

  const { addresses, fetchAddresses, createAddress, updateAddress } = useMypageStore();
  const addressesLoading = useMypageStore((s) => s.addressesLoading);
  const deleteAddress = useMypageStore((s) => s.deleteAddress);

  const [openForm, setOpenForm] = useState(false);
  const [mode, setMode] = useState("create"); // create | edit
  const [editingId, setEditingId] = useState(null);
  
  const hasAddresses = useMemo(() => addresses.length > 0, [addresses]);

  const [form, setForm] = useState({
    label: "", // 배송지명(집/회사 등) - 백엔드 없으면 무시될 수 있음
    receiverName: "",
    receiverPhone: "",
    postcode: "",
    address1: "",
    address2: "",
    memo: "",
  });

  useEffect(() => {
    fetchAddresses();
  }, [fetchAddresses]);

  const onSearchAddress = async () => {
    try {
      await loadDaumPostcode();

      if (!window.daum || !window.daum.Postcode) {
        throw new Error("우편번호 서비스를 불러올 수 없습니다.");
      }

      new window.daum.Postcode({
        oncomplete: (data) => {
          let fullAddress = data.address;
          let extraAddress = "";

          if (data.addressType === "R") {
            if (data.bname !== "") extraAddress += data.bname;
            if (data.buildingName !== "") {
              extraAddress += extraAddress !== "" ? `, ${data.buildingName}` : data.buildingName;
            }
            fullAddress += extraAddress !== "" ? ` (${extraAddress})` : "";
          }

          // 폼 상태 업데이트 (postcode, address1)
          setForm((prev) => ({
            ...prev,
            postcode: data.zonecode, 
            address1: fullAddress,   
          }));
        },
      }).open();

    } catch (error) {
      console.error(error);
      toast.error("주소 검색창을 띄우는 데 실패했습니다.");
    }
  };

  const resetForm = () => {
    setForm({
      label: "",
      receiverName: "",
      receiverPhone: "",
      postcode: "",
      address1: "",
      address2: "",
      memo: "",
    });
    setEditingId(null);
    setMode("create");
  };

  const onOpenCreate = () => {
    resetForm();
    setOpenForm(true);
  };

  const onOpenEdit = (addr) => {
    const id = getAddressId(addr);
    setMode("edit");
    setEditingId(id);

    setForm({
      label: safe(addr?.label ?? addr?.name ?? ""),
      receiverName: safe(addr?.receiverName ?? addr?.name ?? addr?.recipient ?? ""),
      receiverPhone: safe(addr?.receiverPhone ?? addr?.phone ?? ""),
      postcode: safe(addr?.postcode ?? addr?.zipcode ?? ""),
      address1: safe(addr?.address1 ?? addr?.address ?? ""),
      address2: safe(addr?.address2 ?? addr?.detailAddress ?? ""),
      memo: safe(addr?.memo ?? addr?.message ?? ""),
    });

    setOpenForm(true);
  };

  const onClose = () => {
    setOpenForm(false);
    resetForm();
  };

  const onChange = (e) => {
    const { name, value } = e.target;
    setForm((p) => ({ ...p, [name]: value }));
  };

  const validate = () => {
    if (!form.receiverName.trim()) return "수령인 이름을 입력해주세요.";
    if (!form.receiverPhone.trim()) return "연락처를 입력해주세요.";
    if (!form.postcode.trim()) return "우편번호를 입력해주세요.";
    if (!form.address1.trim()) return "기본주소를 입력해주세요.";
    return null;
  };

  const buildPayload = () => {
    return {
      label: form.label.trim(),
      recipient: form.receiverName.trim(),
      recipientPhone: form.receiverPhone.trim(),
      postcode: form.postcode.trim(),
      address: form.address1.trim(),
      detailAddress: form.address2.trim(), // 상세주소는 detail로 매핑
      memo: form.memo.trim(),
    };
  };

  const onSubmit = async (e) => {
    e.preventDefault();

    const msg = validate();
    if (msg) return toast.error(msg);

    const payload = buildPayload();

    try {
      if (mode === "create") {
        await createAddress(payload);
        toast.success("배송지가 추가되었습니다.");
      } else {
        if (!editingId) return toast.error("수정할 주소를 찾지 못했습니다.");
        await updateAddress(editingId, payload);
        toast.success("배송지가 수정되었습니다.");
      }

      onClose();
    } catch (err) {
      toast.error(mode === "create" ? "추가에 실패했습니다." : "수정에 실패했습니다.");
    }
  };

  const onDelete = async (addr) => {
    const id = getAddressId(addr);
    if (!id) return toast.error("삭제할 주소를 찾지 못했습니다.");

    if (!window.confirm("이 배송지를 삭제할까요?")) return;

    try {
      await deleteAddress(id);
      toast.success("삭제되었습니다.");
    } catch {
      toast.error("삭제에 실패했습니다.");
    }
  };

  return (
    <div className="max-w-5xl mx-auto px-4 py-8">
      <div className="flex items-end justify-between gap-3 flex-wrap">
        <div>
          <h1 className="text-2xl font-bold">주소록 관리</h1>
          <p className="text-sm text-gray-500 mt-1">
            배송지를 추가/수정/삭제할 수 있습니다.
          </p>
        </div>

        <div className="flex gap-2">
          <button
            type="button"
            onClick={() => navigate("/mypage")}
            className="px-3 py-2 rounded-md border text-sm hover:bg-gray-50"
          >
            마이페이지로
          </button>
          <button
            type="button"
            onClick={onOpenCreate}
            className="px-4 py-2 rounded-md bg-black text-white text-sm hover:opacity-90"
          >
            + 배송지 추가
          </button>
        </div>
      </div>

      {/* 목록 */}
      <div className="mt-6">
        {addressesLoading ? (
          <div className="py-10 text-center text-gray-500">불러오는 중...</div>
        ) : hasAddresses ? (
          <div className="space-y-3">
            {addresses.map((a, idx) => {
              const id = getAddressId(a) ?? idx;
              const label = a?.label ?? a?.name ?? "배송지";
              const receiver = a?.receiverName ?? a?.recipient ?? a?.name ?? "-";
              const phone = a?.receiverPhone ?? a?.phone ?? "-";

              return (
                <div key={id} className="p-5 rounded-2xl border bg-white">
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <div className="font-bold text-lg truncate">{label}</div>
                      <div className="mt-1 text-sm text-gray-700">
                        <span className="font-medium">{receiver}</span>{" "}
                        <span className="text-gray-500">({phone})</span>
                      </div>
                      <div className="mt-1 text-sm text-gray-600">
                        {buildAddressLine(a)}
                      </div>
                      {a?.memo && (
                        <div className="mt-2 text-sm text-gray-500">
                          메모: {a.memo}
                        </div>
                      )}
                    </div>

                    <div className="flex gap-2 shrink-0">
                      <button
                        type="button"
                        onClick={() => onOpenEdit(a)}
                        className="px-3 py-2 rounded-md border text-sm hover:bg-gray-50"
                      >
                        수정
                      </button>
                      <button
                        type="button"
                        onClick={() => onDelete(a)}
                        className="px-3 py-2 rounded-md border text-sm hover:bg-gray-50"
                      >
                        삭제
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="py-16 text-center text-gray-500">
            등록된 배송지가 없습니다. “배송지 추가”를 눌러 등록해보세요.
          </div>
        )}
      </div>

      {/* 폼(간단 모달) */}
      {openForm && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center px-4 z-50">
          <div className="w-full max-w-xl rounded-2xl bg-white border p-6">
            <div className="flex items-end justify-between gap-3">
              <div>
                <div className="text-xl font-bold">
                  {mode === "create" ? "배송지 추가" : "배송지 수정"}
                </div>
                <div className="mt-1 text-sm text-gray-500">
                  수령인/주소 정보를 입력해주세요.
                </div>
              </div>
              <button
                type="button"
                onClick={onClose}
                className="px-3 py-2 rounded-md border text-sm hover:bg-gray-50"
              >
                닫기
              </button>
            </div>

            <form onSubmit={onSubmit} className="mt-5 space-y-3">
              <div>
                <label className="block text-sm font-medium mb-1">배송지명</label>
                <input
                  name="label"
                  value={form.label}
                  onChange={onChange}
                  className="w-full px-3 py-2 border rounded-md"
                  placeholder="예: 집, 회사"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <label className="block text-sm font-medium mb-1">수령인</label>
                  <input
                    name="receiverName"
                    value={form.receiverName}
                    onChange={onChange}
                    className="w-full px-3 py-2 border rounded-md"
                    placeholder="이름"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-1">연락처</label>
                  <input
                    name="receiverPhone"
                    value={form.receiverPhone}
                    onChange={onChange}
                    className="w-full px-3 py-2 border rounded-md"
                    placeholder="010-0000-0000"
                  />
                </div>
              </div>

             {/* 주소 입력 섹션: 우편번호 검색 버튼 추가 */}
             <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <label className="block text-sm font-medium mb-1">우편번호</label>
                  <div className="flex gap-2">
                    <input name="postcode" value={form.postcode} readOnly className="flex-1 px-3 py-2 border rounded-md bg-gray-50" placeholder="00000" />
                    <button type="button" onClick={onSearchAddress} className="px-3 py-2 bg-gray-800 text-white text-sm rounded-md hover:bg-black transition-colors">검색</button>
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1">기본주소</label>
                  <input name="address1" value={form.address1} readOnly className="w-full px-3 py-2 border rounded-md bg-gray-50" placeholder="주소 검색을 이용해주세요" />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium mb-1">상세주소</label>
                <input name="address2" value={form.address2} onChange={onChange} className="w-full px-3 py-2 border rounded-md" placeholder="상세주소" />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="submit"
                  className="flex-1 py-3 rounded-md bg-black text-white font-medium hover:opacity-90"
                >
                  {mode === "create" ? "추가하기" : "수정하기"}
                </button>
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-3 rounded-md border hover:bg-gray-50"
                >
                  취소
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}