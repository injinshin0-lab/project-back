// src/pages/search/SearchPage.jsx
import { useEffect, useMemo, useState } from "react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import toast from "react-hot-toast";

import { getProductsApi } from "@/api/productApi";

const PAGE_SIZE = 12;

function normalize(v) {
  return String(v ?? "").toLowerCase();
}

function formatPriceKRW(value) {
  const num = Number(value ?? 0);
  if (Number.isNaN(num)) return "-";
  return new Intl.NumberFormat("ko-KR").format(num);
}

function ProductCard({ product }) {
  const productId = String(product?.id ?? "");
  const image = product?.images?.[0];

  return (
    <Link
      to={`/products/${productId}`}
      className="block rounded-2xl border border-gray-200 bg-white overflow-hidden hover:shadow-sm transition"
    >
      <div className="aspect-square bg-gray-100 overflow-hidden">
        {image ? (
          <img
            src={image}
            alt={product?.name ?? "product"}
            className="w-full h-full object-cover"
            loading="lazy"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-gray-400 text-sm">
            이미지 없음
          </div>
        )}
      </div>

      <div className="p-4">
        <div className="text-xs text-gray-500">{product?.brand ?? "-"}</div>
        <div className="mt-1 font-semibold text-gray-900 line-clamp-2">
          {product?.name ?? "-"}
        </div>
        <div className="mt-2 text-lg font-bold">{formatPriceKRW(product?.price)}원</div>

        {Array.isArray(product?.tags) && product.tags.length > 0 && (
          <div className="mt-3 flex flex-wrap gap-2">
            {product.tags.slice(0, 3).map((t) => (
              <span
                key={t}
                className="px-2 py-1 rounded-full text-[11px] bg-gray-100 text-gray-700"
              >
                {t}
              </span>
            ))}
          </div>
        )}
      </div>
    </Link>
  );
}

function Pagination({ page, totalPages, onPage }) {
  if (totalPages <= 1) return null;

  const maxButtons = 5;
  const start = Math.max(1, page - Math.floor(maxButtons / 2));
  const end = Math.min(totalPages, start + maxButtons - 1);
  const pages = [];
  for (let p = start; p <= end; p += 1) pages.push(p);

  return (
    <div className="mt-8 flex items-center justify-center gap-2 flex-wrap">
      <button
        type="button"
        onClick={() => onPage(Math.max(1, page - 1))}
        disabled={page <= 1}
        className="h-10 px-4 rounded-xl border border-gray-200 disabled:text-gray-400"
      >
        이전
      </button>

      {pages.map((p) => (
        <button
          key={p}
          type="button"
          onClick={() => onPage(p)}
          className={[
            "h-10 px-4 rounded-xl border text-sm font-semibold",
            p === page ? "border-gray-900 text-gray-900" : "border-gray-200 text-gray-700",
          ].join(" ")}
        >
          {p}
        </button>
      ))}

      <button
        type="button"
        onClick={() => onPage(Math.min(totalPages, page + 1))}
        disabled={page >= totalPages}
        className="h-10 px-4 rounded-xl border border-gray-200 disabled:text-gray-400"
      >
        다음
      </button>
    </div>
  );
}

export default function SearchPage() {
  const navigate = useNavigate();
  const [sp, setSp] = useSearchParams();

  const q = (sp.get("q") ?? "").trim();
  const page = Math.max(1, Number(sp.get("page") ?? "1") || 1);

  const [loading, setLoading] = useState(true);
  const [all, setAll] = useState([]);
  const [error, setError] = useState(false);

  useEffect(() => {
    let mounted = true;

    async function fetchAll() {
      try {
        setError(false);
        setLoading(true);

        const data = await getProductsApi();
        const list = Array.isArray(data) ? data : Array.isArray(data?.items) ? data.items : [];

        if (!mounted) return;
        setAll(list);
      } catch (e) {
        if (!mounted) return;
        setError(true);
        setAll([]);
        toast.error("검색 데이터를 불러오지 못했어요.");
      } finally {
        if (!mounted) return;
        setLoading(false);
      }
    }

    fetchAll();
    return () => {
      mounted = false;
    };
  }, []);

  const filtered = useMemo(() => {
    if (!q) return [];
    const keyword = normalize(q);

    return all.filter((p) => {
      const name = normalize(p?.name);
      const brand = normalize(p?.brand);
      const tags = Array.isArray(p?.tags) ? p.tags.map(normalize).join(" ") : "";
      return name.includes(keyword) || brand.includes(keyword) || tags.includes(keyword);
    });
  }, [all, q]);

  const total = filtered.length;
  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));
  const safePage = Math.min(page, totalPages);

  const paged = useMemo(() => {
    const start = (safePage - 1) * PAGE_SIZE;
    const end = start + PAGE_SIZE;
    return filtered.slice(start, end);
  }, [filtered, safePage]);

  function goPage(nextPage) {
    const next = new URLSearchParams(sp);
    next.set("page", String(nextPage));
    setSp(next);
    // 스크롤 UX
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function goProducts() {
    navigate("/products");
  }

  if (!q) {
    return (
      <div className="max-w-6xl mx-auto px-4 py-8">
        <div className="p-6 rounded-2xl border border-gray-200 bg-white">
          <div className="text-lg font-bold">검색어를 입력해주세요</div>
          <p className="mt-2 text-sm text-gray-500">
            메인(/bogam)에서 검색하면 여기로 이동해요.
          </p>
          <button
            type="button"
            onClick={() => navigate("/bogam")}
            className="mt-4 h-11 px-5 rounded-xl bg-gray-900 text-white font-semibold hover:bg-gray-800"
          >
            메인으로
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <div className="flex items-end justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-2xl font-bold">검색 결과</h1>
          <p className="mt-2 text-sm text-gray-600">
            “<span className="font-semibold text-gray-900">{q}</span>” 검색 결과:{" "}
            <span className="font-semibold text-gray-900">{total}</span>개
          </p>
        </div>

        <button
          type="button"
          onClick={goProducts}
          className="h-11 px-5 rounded-xl border border-gray-200 font-semibold hover:bg-gray-50"
        >
          전체 상품 보기
        </button>
      </div>

      <div className="mt-6">
        {loading && (
          <div className="p-6 rounded-2xl border border-gray-200 bg-white text-gray-500">
            검색 중...
          </div>
        )}

        {!loading && error && (
          <div className="p-6 rounded-2xl border border-gray-200 bg-white">
            <div className="font-semibold">검색에 실패했어요</div>
            <p className="mt-1 text-sm text-gray-500">잠시 후 다시 시도해주세요.</p>
          </div>
        )}

        {!loading && !error && total === 0 && (
          <div className="p-6 rounded-2xl border border-gray-200 bg-white">
            <div className="font-semibold">결과가 없어요</div>
            <p className="mt-1 text-sm text-gray-500">
              다른 검색어로 다시 시도해보세요.
            </p>
          </div>
        )}

        {!loading && !error && total > 0 && (
          <>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {paged.map((p) => (
                <ProductCard key={p.id} product={p} />
              ))}
            </div>

            <Pagination page={safePage} totalPages={totalPages} onPage={goPage} />
          </>
        )}
      </div>
    </div>
  );
}