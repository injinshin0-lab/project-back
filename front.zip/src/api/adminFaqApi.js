import axios from 'axios';

const API_BASE_URL = '/api/v1/admin';

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

/**
 * FAQ 목록 조회
 * @param {Object} params - { keyword, page, size }
 * @returns {Promise} FAQ 목록과 페이지 정보
 */
export const getAdminFaqList = async (params = {}) => {
  try {
    const { keyword = '', page = 1, size = 10 } = params;

    const response = await api.get('/faq', {
      params: {
        keyword,
        page,
        size,
      },
    });

    return response.data;
  } catch (error) {
    console.error('FAQ 목록 조회 실패:', error);
    throw new Error(error.response?.data?.message || 'FAQ 목록을 불러오는데 실패했습니다.');
  }
};

/**
 * FAQ 상세 조회
 * @param {number} faqId - FAQ ID
 * @returns {Promise} FAQ 상세 정보
 */
export const getAdminFaq = async (faqId) => {
  try {
    const response = await api.get(`/faq/${faqId}`);
    return response.data;
  } catch (error) {
    console.error('FAQ 상세 조회 실패:', error);
    throw new Error(error.response?.data?.message || 'FAQ를 불러오는데 실패했습니다.');
  }
};

/**
 * FAQ 등록
 * @param {Object} faqData - { title, content }
 * @returns {Promise} 성공 여부 (0 or 1)
 */
export const createAdminFaq = async (faqData) => {
  try {
    const response = await api.post('/faq', faqData);
    return response.data;
  } catch (error) {
    console.error('FAQ 등록 실패:', error);
    throw new Error(error.response?.data?.message || 'FAQ 등록에 실패했습니다.');
  }
};

/**
 * FAQ 수정
 * @param {Object} faqData - { faqId, title, content }
 * @returns {Promise} 성공 여부 (0 or 1)
 */
export const updateAdminFaq = async (faqData) => {
  try {
    const response = await api.put('/faq', faqData);
    return response.data;
  } catch (error) {
    console.error('FAQ 수정 실패:', error);
    throw new Error(error.response?.data?.message || 'FAQ 수정에 실패했습니다.');
  }
};

/**
 * FAQ 삭제
 * @param {number} faqId - FAQ ID
 * @returns {Promise} 성공 여부 (0 or 1)
 */
export const deleteAdminFaq = async (faqId) => {
  try {
    const response = await api.delete(`/faq/${faqId}`);
    return response.data;
  } catch (error) {
    console.error('FAQ 삭제 실패:', error);
    throw new Error(error.response?.data?.message || 'FAQ 삭제에 실패했습니다.');
  }
};


