import axios from 'axios';

// 관리자 관련 API 함수들
const API_BASE_URL = '/api/v1/admin';

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

/**
 * 대시보드 데이터 조회
 */
export const getDashboard = async () => {
  try {
    const response = await api.get('/dashboard');
    return response.data;
  } catch (error) {
    console.error('대시보드 API 에러:', error);
    throw new Error(error.response?.data?.message || `대시보드 데이터를 불러오는데 실패했습니다. (${error.response?.status || ''})`);
  }
};

/**
 * 사용자 목록 조회
 */
export const getUserList = async (params = {}) => {
  try {
    const {
      startDate = '',
      endDate = '',
      keywordType = '',
      keyword = '',
      page = 1,
      size = 10,
    } = params;

    const response = await api.get('/user', {
      params: {
        startDate,
        endDate,
        keywordType,
        keyword,
        page,
        size,
      },
    });
    return response.data;
  } catch (error) {
    console.error('사용자 목록 API 에러:', error);
    throw new Error(error.response?.data?.message || `사용자 목록을 불러오는데 실패했습니다. (${error.response?.status || ''})`);
  }
};

/**
 * 사용자 상세 조회
 */
export const getUser = async (id) => {
  try {
    const response = await api.get(`/user/${id}`);
    return response.data;
  } catch (error) {
    console.error('사용자 상세 조회 에러:', error);
    throw new Error(error.response?.data?.message || `사용자 정보를 불러오는데 실패했습니다. (${error.response?.status || ''})`);
  }
};

/**
 * 주문 목록 조회
 */
export const getOrderList = async (params = {}) => {
  try {
    const {
      userId = null,
      startDate = '',
      endDate = '',
      page = 1,
      size = 10,
    } = params;

    const response = await api.get('/order', {
      params: {
        userId,
        startDate,
        endDate,
        page,
        size,
      },
    });
    return response.data;
  } catch (error) {
    console.error('주문 목록 API 에러:', error);
    throw new Error(error.response?.data?.message || `주문 목록을 불러오는데 실패했습니다. (${error.response?.status || ''})`);
  }
};

/**
 * 주문 배송상태 변경
 */
export const updateOrderStatus = async (orderId, status) => {
  try {
    const response = await api.put(`/order/${orderId}/status`, null, {
      params: { status },
    });
    return response.data;
  } catch (error) {
    console.error('주문 상태 변경 API 에러:', error);
    throw new Error(error.response?.data?.message || `주문 상태 변경에 실패했습니다. (${error.response?.status || ''})`);
  }
};

/**
 * 질문 목록 조회
 */
export const getQuestionList = async (params = {}) => {
  try {
    const {
      startDate = '',
      endDate = '',
      questionStatus = '',
      type = '',
      keywordType = '',
      keyword = '',
      page = 1,
      size = 10,
    } = params;

    const response = await api.get('/question', {
      params: {
        startDate,
        endDate,
        questionStatus,
        type,
        keywordType,
        keyword,
        page,
        size,
      },
    });
    return response.data;
  } catch (error) {
    console.error('질문 목록 API 에러:', error);
    throw new Error(error.response?.data?.message || `질문 목록을 불러오는데 실패했습니다. (${error.response?.status || ''})`);
  }
};

/**
 * 질문 상세 조회
 */
export const getQuestion = async (id) => {
  try {
    const response = await api.get(`/question/${id}`);
    return response.data;
  } catch (error) {
    console.error('질문 상세 조회 에러:', error);
    throw new Error(error.response?.data?.message || `질문 정보를 불러오는데 실패했습니다. (${error.response?.status || ''})`);
  }
};

/**
 * 질문 답변 등록
 */
export const insertAnswer = async (questionId, content) => {
  try {
    const response = await api.post('/question/answer', {
      questionid: questionId,
      content: content,
    });
    return response.data;
  } catch (error) {
    console.error('답변 등록 API 에러:', error);
    throw new Error(error.response?.data?.message || `답변 등록에 실패했습니다. (${error.response?.status || ''})`);
  }
};

/**
 * 카테고리 목록 조회
 */
export const getCategoryList = async () => {
  try {
    const response = await api.get('/category');
    return response.data;
  } catch (error) {
    console.error('카테고리 목록 조회 에러:', error);
    throw new Error(error.response?.data?.message || `카테고리 목록을 불러오는데 실패했습니다. (${error.response?.status || ''})`);
  }
};

/**
 * 카테고리 등록
 */
export const createCategory = async (category) => {
  try {
    const response = await api.post('/category', category);
    return response.data;
  } catch (error) {
    console.error('카테고리 등록 에러:', error);
    throw new Error(error.response?.data?.message || `카테고리 등록에 실패했습니다. (${error.response?.status || ''})`);
  }
};

/**
 * 카테고리 수정
 */
export const updateCategory = async (category) => {
  try {
    const response = await api.put('/category', category);
    return response.data;
  } catch (error) {
    console.error('카테고리 수정 에러:', error);
    throw new Error(error.response?.data?.message || `카테고리 수정에 실패했습니다. (${error.response?.status || ''})`);
  }
};

/**
 * 카테고리 삭제
 */
export const deleteCategory = async (id) => {
  try {
    const response = await api.delete('/category', {
      params: { id },
    });
    return response.data;
  } catch (error) {
    console.error('카테고리 삭제 에러:', error);
    throw new Error(error.response?.data?.message || `카테고리 삭제에 실패했습니다. (${error.response?.status || ''})`);
  }
};
