import axios from 'axios';

// 개발 환경에서는 프록시를 사용하므로 상대 경로 사용
// 프로덕션에서는 절대 경로로 변경 필요
const API_BASE_URL = '/api/v1';

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

/**
 * FAQ 목록 조회
 * @param {Object} params - { keyword, page, size }
 * @returns {Promise} FAQ 목록과 페이지 정보
 */
export const getFaqList = async (params = {}) => {
  try {
    const { keyword = '', page = 1, size = 10 } = params;

    const response = await api.get('/faq', {
      params: {
        keyword,
        page,
        size,
      },
    });

    return response.data;
  } catch (error) {
    console.error('FAQ 목록 조회 실패:', error);
    throw new Error(error.response?.data?.message || 'FAQ 목록을 불러오는데 실패했습니다.');
  }
};

/**
 * FAQ 상세 조회
 * @param {number} id - FAQ ID
 * @returns {Promise} FAQ 상세 정보
 */
export const getFaq = async (id) => {
  try {
    const response = await api.get(`/faq/${id}`);
    return response.data;
  } catch (error) {
    console.error('FAQ 상세 조회 실패:', error);
    throw new Error(error.response?.data?.message || 'FAQ를 불러오는데 실패했습니다.');
  }
};

/**
 * FAQ 등록
 * @param {Object} faqData - { title, content }
 * @returns {Promise} 생성된 FAQ ID
 */
export const createFaq = async (faqData) => {
  try {
    const response = await api.post('/faq', faqData);
    return response.data;
  } catch (error) {
    console.error('FAQ 등록 실패:', error);
    throw new Error(error.response?.data?.message || 'FAQ 등록에 실패했습니다.');
  }
};

/**
 * FAQ 수정
 * @param {Object} faqData - { id, title, content }
 * @returns {Promise} 수정된 행 수
 */
export const updateFaq = async (faqData) => {
  try {
    const response = await api.put('/faq', faqData);
    return response.data;
  } catch (error) {
    console.error('FAQ 수정 실패:', error);
    throw new Error(error.response?.data?.message || 'FAQ 수정에 실패했습니다.');
  }
};

/**
 * FAQ 삭제
 * @param {number} id - FAQ ID
 * @returns {Promise} 삭제된 행 수
 */
export const deleteFaq = async (id) => {
  try {
    const response = await api.delete(`/faq/${id}`);
    return response.data;
  } catch (error) {
    console.error('FAQ 삭제 실패:', error);
    throw new Error(error.response?.data?.message || 'FAQ 삭제에 실패했습니다.');
  }
};
