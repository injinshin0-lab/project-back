import axios from 'axios';

const API_BASE_URL = '/api/v1';

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

/**
 * 알림 목록 조회
 * @param {number} userId - 사용자 ID
 * @returns {Promise} 알림 목록
 */
export const getAlarmList = async (userId) => {
  try {
    const response = await api.get(`/alarm`, { params: { userId } });
    return response.data;
  } catch (error) {
    console.error('알림 목록 조회 실패:', error);
    throw new Error(error.response?.data?.message || '알림 목록을 불러오는데 실패했습니다.');
  }
};
