import axios from 'axios';

const API_BASE_URL = '/api/v1';

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

/**
 * 상품별 리뷰 목록 조회
 * @param {number} productId - 상품 ID
 * @returns {Promise} 리뷰 목록
 */
export const getReviewsByProduct = async (productId) => {
  try {
    const response = await api.get(`/review/product/${productId}`);
    return response.data;
  } catch (error) {
    console.error('리뷰 목록 조회 실패:', error);
    throw new Error(error.response?.data?.message || '리뷰 목록을 불러오는데 실패했습니다.');
  }
};

/**
 * 전체 리뷰 목록 조회
 * @returns {Promise} 리뷰 목록
 */
export const getAllReviews = async () => {
  try {
    const response = await api.get('/review');
    return response.data;
  } catch (error) {
    console.error('전체 리뷰 목록 조회 실패:', error);
    throw new Error(error.response?.data?.message || '리뷰 목록을 불러오는데 실패했습니다.');
  }
};

/**
 * 사용자별 리뷰 목록 조회
 * @param {number} userId - 사용자 ID
 * @returns {Promise} 리뷰 목록
 */
export const getReviewsByUserId = async (userId) => {
  try {
    const response = await api.get(`/review/user/${userId}`);
    return response.data;
  } catch (error) {
    console.error('사용자별 리뷰 목록 조회 실패:', error);
    throw new Error(error.response?.data?.message || '리뷰 목록을 불러오는데 실패했습니다.');
  }
};

/**
 * 리뷰 작성 가능 여부 확인
 * @param {number} userId - 사용자 ID
 * @param {number} productId - 상품 ID
 * @returns {Promise<boolean>} 리뷰 작성 가능 여부
 */
export const canWriteReview = async (userId, productId) => {
  try {
    const response = await api.get(`/review/can-write/${userId}/${productId}`);
    return response.data;
  } catch (error) {
    console.error('리뷰 작성 가능 여부 확인 실패:', error);
    return false;
  }
};

/**
 * 리뷰 상세 조회
 * @param {number} reviewId - 리뷰 ID
 * @returns {Promise} 리뷰 상세 정보
 */
export const getReview = async (reviewId) => {
  try {
    const response = await api.get(`/review/${reviewId}`);
    return response.data;
  } catch (error) {
    console.error('리뷰 상세 조회 실패:', error);
    throw new Error(error.response?.data?.message || '리뷰를 불러오는데 실패했습니다.');
  }
};

/**
 * 리뷰 작성
 * @param {Object} formData - FormData 객체 (userId, productId, content, rating, images)
 * @returns {Promise}
 */
export const insertReview = async (formData) => {
  try {
    const response = await api.post('/review', formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    });
    return response.data;
  } catch (error) {
    console.error('리뷰 작성 실패:', error);
    throw new Error(error.response?.data?.message || '리뷰 작성에 실패했습니다.');
  }
};



