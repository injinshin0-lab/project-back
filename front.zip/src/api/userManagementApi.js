import axios from 'axios';

const API_BASE_URL = '/api/v1/admin';

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

/**
 * 회원 목록 조회
 * @param {Object} params - { startDate, endDate, keywordType, keyword, page, size }
 * @returns {Promise} 회원 목록과 페이지 정보
 */
export const getUserList = async (params = {}) => {
  try {
    const { startDate, endDate, keywordType, keyword, page = 1, size = 10 } = params;

    const response = await api.get('/user-management', {
      params: {
        startDate,
        endDate,
        keywordType,
        keyword,
        page,
        size,
      },
    });

    return response.data;
  } catch (error) {
    console.error('회원 목록 조회 실패:', error);
    throw new Error(error.response?.data?.message || '회원 목록을 불러오는데 실패했습니다.');
  }
};

/**
 * 회원 상세 조회
 * @param {number} id - 회원 ID
 * @returns {Promise} 회원 상세 정보
 */
export const getUser = async (id) => {
  try {
    const response = await api.get(`/user-management/${id}`);
    return response.data;
  } catch (error) {
    console.error('회원 상세 조회 실패:', error);
    throw new Error(error.response?.data?.message || '회원 정보를 불러오는데 실패했습니다.');
  }
};



