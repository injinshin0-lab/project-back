import axios from 'axios';

const API_BASE_URL = '/api/v1';

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// auto-login API의 401 에러를 조용히 처리하기 위한 인터셉터
api.interceptors.response.use(
  (response) => response,
  (error) => {
    // auto-login API의 401 에러는 조용히 처리
    if (error.config?.url?.includes('/login/auto-login') && error.response?.status === 401) {
      // 에러를 조용히 반환 (브라우저 콘솔에 표시되지 않도록)
      const silentError = Object.create(error);
      silentError.silent = true; // 조용한 에러 플래그
      return Promise.reject(silentError);
    }
    // 다른 에러는 기존대로 처리
    return Promise.reject(error);
  }
);

/**
 * 자동 로그인 (세션 기반)
 * @returns {Promise} 사용자 정보 { isAuthenticated, user_id, name, role }
 */
export const autoLogin = async () => {
  try {
    const response = await api.post('/login/auto-login');
    return response.data;
  } catch (error) {
    // 401 에러는 로그인하지 않은 정상적인 상태이므로 조용히 처리
    if (error.response?.status === 401) {
      // 에러를 조용히 던지기 위해 원본 에러를 그대로 반환
      // 콘솔에 표시되지 않도록 에러 객체를 수정하지 않음
      const silentError = new Error(error.response?.data?.message || '로그인 상태가 아닙니다.');
      silentError.response = error.response;
      silentError.status = 401;
      throw silentError;
    }
    console.error('자동 로그인 실패:', error);
    throw new Error(error.response?.data?.message || '자동 로그인에 실패했습니다.');
  }
};

/**
 * 자동 로그인 토큰으로 사용자 조회 (deprecated)
 * @param {string} token - 자동 로그인 토큰
 * @returns {Promise} 사용자 정보
 */
export const getAutoLoginToken = async (token) => {
  try {
    const response = await api.post('/login/auto-login-token', null, {
      params: { token },
    });
    return response.data;
  } catch (error) {
    console.error('자동 로그인 토큰 조회 실패:', error);
    throw new Error(error.response?.data?.message || '자동 로그인에 실패했습니다.');
  }
};

/**
 * 로그인
 * @param {Object} loginData - { loginId, password, saveId, autoLogin }
 * @returns {Promise} 사용자 정보
 */
export const login = async (loginData) => {
  try {
    // 백엔드 DTO에서 @JsonProperty("userId")로 매핑되어 있으므로 userId로 변환
    const requestData = {
      userId: loginData.loginId,
      password: loginData.password
    };
    const response = await api.post('/login', requestData);
    return response.data;
  } catch (error) {
    console.error('로그인 실패:', error);
    throw new Error(error.response?.data?.message || '로그인에 실패했습니다.');
  }
};

/**
 * 카테고리 목록 조회
 * @returns {Promise} 카테고리 목록
 */
export const getCategories = async () => {
  try {
    const response = await api.get('/login/categories');
    return response.data;
  } catch (error) {
    console.error('카테고리 목록 조회 실패:', error);
    throw new Error(error.response?.data?.message || '카테고리 목록을 불러오는데 실패했습니다.');
  }
};

/**
 * 아이디 중복 체크
 * @param {string} loginId - 로그인 ID
 * @returns {Promise} 중복 여부 (true: 중복, false: 사용 가능)
 */
export const checkId = async (loginId) => {
  try {
    const response = await api.post('/login/check-id', null, {
      params: { loginId },
    });
    return response.data;
  } catch (error) {
    console.error('아이디 중복 체크 실패:', error);
    throw new Error(error.response?.data?.message || '아이디 중복 체크에 실패했습니다.');
  }
};

/**
 * 이메일 인증 코드 발송
 * @param {string} email - 이메일 주소
 * @returns {Promise}
 */
export const sendEmailCode = async (email) => {
  try {
    const response = await api.post('/login/email/send-code', { email });
    return response.data;
  } catch (error) {
    console.error('이메일 인증 코드 발송 실패:', error);
    throw new Error(error.response?.data?.message || '이메일 인증 코드 발송에 실패했습니다.');
  }
};

/**
 * 이메일 인증 코드 확인
 * @param {Object} codeData - { email, authCode }
 * @returns {Promise} 인증 성공 여부
 */
export const checkEmailCode = async (codeData) => {
  try {
    const response = await api.post('/login/email/verify-code', codeData);
    return response.data;
  } catch (error) {
    console.error('이메일 인증 코드 확인 실패:', error);
    throw new Error(error.response?.data?.message || '이메일 인증 코드 확인에 실패했습니다.');
  }
};

/**
 * 회원가입
 * @param {Object} signUpData - { userId, loginId, password, name, email, phone, address, categoryId }
 * @returns {Promise}
 */
export const signUp = async (signUpData) => {
  try {
    const response = await api.post('/login/signup', signUpData);
    return response.data;
  } catch (error) {
    console.error('회원가입 실패:', error);
    throw new Error(error.response?.data?.message || '회원가입에 실패했습니다.');
  }
};

/**
 * 로그아웃
 * @param {number} userId - 사용자 ID
 * @returns {Promise}
 */
export const logout = async (userId) => {
  try {
    const response = await api.post(`/user/logout/${userId}`);
    return response.data;
  } catch (error) {
    console.error('로그아웃 실패:', error);
    throw new Error(error.response?.data?.message || '로그아웃에 실패했습니다.');
  }
};

/**
 * 이메일 인증 코드 발송 (아이디/비밀번호 찾기용)
 * @param {string} email - 이메일 주소
 * @returns {Promise}
 */
export const sendEmailAuthCode = async (email) => {
  try {
    const response = await api.post('/login/email/send-code', { email });
    return response.data;
  } catch (error) {
    console.error('이메일 인증 코드 발송 실패:', error);
    throw new Error(error.response?.data?.message || '이메일 인증 코드 발송에 실패했습니다.');
  }
};

/**
 * 이메일 인증 코드 확인 (아이디/비밀번호 찾기용)
 * @param {Object} codeData - { email, authCode }
 * @returns {Promise} 인증 성공 여부
 */
export const verifyEmailAuthCode = async (codeData) => {
  try {
    const response = await api.post('/login/email/verify-code', codeData);
    return response.data;
  } catch (error) {
    console.error('이메일 인증 코드 확인 실패:', error);
    throw new Error(error.response?.data?.message || '이메일 인증 코드 확인에 실패했습니다.');
  }
};

/**
 * 아이디 찾기
 * @param {Object} findData - { name, email }
 * @returns {Promise}
 */
export const findUserId = async (findData) => {
  try {
    const response = await api.post('/login/find-id', findData);
    return response.data;
  } catch (error) {
    console.error('아이디 찾기 실패:', error);
    throw new Error(error.response?.data?.message || '아이디 찾기에 실패했습니다.');
  }
};

/**
 * 비밀번호 찾기
 * @param {Object} findData - { loginId, email }
 * @returns {Promise}
 */
export const findPassword = async (findData) => {
  try {
    const response = await api.post('/login/find-password', findData);
    return response.data;
  } catch (error) {
    console.error('비밀번호 찾기 실패:', error);
    throw new Error(error.response?.data?.message || '비밀번호 찾기에 실패했습니다.');
  }
};



