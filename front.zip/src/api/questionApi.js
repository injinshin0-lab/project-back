import axios from 'axios';

const API_BASE_URL = '/api/v1';

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

/**
 * 사용자별 문의 목록 조회
 * @param {number} userId - 사용자 ID
 * @returns {Promise} 문의 목록
 */
export const getQuestionList = async (userId) => {
  try {
    const response = await api.get('/question', {
      params: { userId },
    });
    return response.data;
  } catch (error) {
    console.error('문의 목록 조회 실패:', error);
    throw new Error(error.response?.data?.message || '문의 목록을 불러오는데 실패했습니다.');
  }
};

/**
 * 문의 상세 조회
 * @param {number} questionId - 문의 ID
 * @returns {Promise} 문의 상세 정보
 */
export const getQuestion = async (questionId) => {
  try {
    const response = await api.get(`/question/${questionId}`);
    return response.data;
  } catch (error) {
    console.error('문의 상세 조회 실패:', error);
    throw new Error(error.response?.data?.message || '문의를 불러오는데 실패했습니다.');
  }
};

/**
 * 문의 작성
 * @param {Object} formData - FormData 객체 (userId, productId, title, content, type, images)
 * @returns {Promise}
 */
export const insertQuestion = async (formData) => {
  try {
    const response = await api.post('/question', formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    });
    return response.data;
  } catch (error) {
    console.error('문의 작성 실패:', error);
    throw new Error(error.response?.data?.message || '문의 작성에 실패했습니다.');
  }
};



