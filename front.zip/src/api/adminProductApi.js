import axios from 'axios';

// 관리자 상품 관련 API 함수들
const API_BASE_URL = '/api/v1/admin';

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

/**
 * 관리자 상품 목록 조회
 * @param {Object} params - { page, size, keyword, sort, order, categoryId }
 * @returns {Promise} 상품 목록과 페이지 정보
 */
export const getAdminProductList = async (params = {}) => {
  try {
    const { page = 1, size = 10, keyword, sort, order, categoryId } = params;
    
    const response = await api.get('/product', {
      params: {
        page,
        size,
        keyword,
        sort,
        order,
        categoryId,
      },
    });
    
    return response.data;
  } catch (error) {
    console.error('상품 목록 조회 실패:', error);
    throw new Error(error.response?.data?.message || '상품 목록을 불러오는데 실패했습니다.');
  }
};

/**
 * 관리자 상품 상세 조회
 * @param {number} id - 상품 ID
 * @returns {Promise} 상품 상세 정보
 */
export const getAdminProduct = async (id) => {
  try {
    const response = await api.get(`/product/${id}`);
    return response.data;
  } catch (error) {
    console.error('상품 상세 조회 실패:', error);
    throw new Error(error.response?.data?.message || '상품을 불러오는데 실패했습니다.');
  }
};

/**
 * 상품 등록
 * @param {FormData} formData - FormData 객체 (파일 업로드 포함)
 * @returns {Promise} 생성된 상품 ID
 */
export const createProduct = async (formData) => {
  try {
    const response = await api.post('/product', formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    });
    return response.data;
  } catch (error) {
    console.error('상품 등록 실패:', error);
    throw new Error(error.response?.data?.message || '상품 등록에 실패했습니다.');
  }
};

/**
 * 상품 수정
 * @param {FormData} formData - FormData 객체 (파일 업로드 포함)
 * @returns {Promise}
 */
export const updateProduct = async (formData) => {
  try {
    const response = await api.put('/product', formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    });
    return response.data;
  } catch (error) {
    console.error('상품 수정 실패:', error);
    throw new Error(error.response?.data?.message || '상품 수정에 실패했습니다.');
  }
};

/**
 * 상품 삭제
 * @param {number} id - 상품 ID
 * @returns {Promise}
 */
export const deleteProduct = async (id) => {
  try {
    const response = await api.delete(`/product/${id}`);
    return response.data;
  } catch (error) {
    console.error('상품 삭제 실패:', error);
    throw new Error(error.response?.data?.message || '상품 삭제에 실패했습니다.');
  }
};

/**
 * 상품별 리뷰 목록 조회
 * @param {number} id - 상품 ID
 * @returns {Promise} 리뷰 목록
 */
export const getReviewsByProduct = async (id) => {
  try {
    const response = await api.get(`/review/product/${id}`);
    return response.data;
  } catch (error) {
    console.error('리뷰 목록 조회 실패:', error);
    throw new Error(error.response?.data?.message || '리뷰 목록을 불러오는데 실패했습니다.');
  }
};

/**
 * 리뷰 상세 조회
 * @param {number} id - 리뷰 ID
 * @returns {Promise} 리뷰 상세 정보
 */
export const getReview = async (id) => {
  try {
    const response = await api.get(`/review/${id}`);
    return response.data;
  } catch (error) {
    console.error('리뷰 상세 조회 실패:', error);
    throw new Error(error.response?.data?.message || '리뷰를 불러오는데 실패했습니다.');
  }
};

/**
 * 리뷰 삭제
 * @param {number} id - 리뷰 ID
 * @returns {Promise}
 */
export const deleteReview = async (id) => {
  try {
    const response = await api.delete(`/review/${id}`);
    return response.data;
  } catch (error) {
    console.error('리뷰 삭제 실패:', error);
    throw new Error(error.response?.data?.message || '리뷰 삭제에 실패했습니다.');
  }
};
