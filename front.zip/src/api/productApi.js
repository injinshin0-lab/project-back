import axios from 'axios';

// 상품 관련 API 함수들
const API_BASE_URL = '/api/v1';

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

/**
 * 상품 목록 조회
 * @param {Object} params - { categoryId, page, size, keyword, sort, order, userId }
 * @returns {Promise} 상품 목록과 페이지 정보
 */
export const getProductList = async (params = {}) => {
  try {
    const {
      categoryId,
      page = 1,
      size = 10,
      keyword,
      sort,
      order,
      userId,
    } = params;

    const response = await api.get('/product', {
      params: {
        categoryId,
        page,
        size,
        keyword,
        sort,
        order,
        userId,
      },
    });

    return response.data;
  } catch (error) {
    console.error('상품 목록 조회 실패:', error);
    throw new Error(error.response?.data?.message || '상품 목록을 불러오는데 실패했습니다.');
  }
};

/**
 * 상품 상세 조회
 * @param {number} productId - 상품 ID
 * @param {number} userId - 사용자 ID (선택)
 * @returns {Promise} 상품 상세 정보
 */
export const getProduct = async (productId, userId = null) => {
  try {
    const response = await api.get(`/product/${productId}`, {
      params: {
        userId,
      },
    });

    return response.data;
  } catch (error) {
    console.error('상품 상세 조회 실패:', error);
    throw new Error(error.response?.data?.message || '상품을 불러오는데 실패했습니다.');
  }
};

/**
 * 카테고리 목록 조회
 * @returns {Promise} 카테고리 목록
 */
export const getAllCategories = async () => {
  try {
    const response = await api.get('/product/categories');
    return response.data;
  } catch (error) {
    console.error('카테고리 목록 조회 실패:', error);
    throw new Error(error.response?.data?.message || '카테고리 목록을 불러오는데 실패했습니다.');
  }
};

/**
 * 장바구니 목록 조회
 * @param {number} userId - 사용자 ID
 * @returns {Promise} 장바구니 목록
 */
export const getCartList = async (userId) => {
  try {
    const response = await api.get('/cart', {
      params: { userId },
    });

    return response.data;
  } catch (error) {
    console.error('장바구니 목록 조회 실패:', error);
    throw new Error(error.response?.data?.message || '장바구니 목록을 불러오는데 실패했습니다.');
  }
};

/**
 * 장바구니에 상품 추가
 * @param {Object} cartData - { userId, productId, quantity, productName, price, imageUrl }
 * @returns {Promise}
 */
export const addCartItem = async (cartData) => {
  try {
    const response = await api.post('/cart', cartData);
    return response.data;
  } catch (error) {
    console.error('장바구니 추가 실패:', error);
    throw new Error(error.response?.data?.message || '장바구니에 상품을 추가하는데 실패했습니다.');
  }
};

/**
 * 장바구니에서 상품 수량 감소/삭제
 * @param {Object} cartData - { userId, productId }
 * @returns {Promise}
 */
export const removeCartItem = async (cartData) => {
  try {
    const response = await api.delete('/cart/item', {
      data: cartData,
    });

    return response.data;
  } catch (error) {
    console.error('장바구니 아이템 제거 실패:', error);
    throw new Error(error.response?.data?.message || '장바구니에서 상품을 제거하는데 실패했습니다.');
  }
};

/**
 * 장바구니 전체 삭제
 * @param {Object} cartData - { userId }
 * @returns {Promise}
 */
export const removeCart = async (cartData) => {
  try {
    const response = await api.delete('/cart', {
      data: cartData,
    });

    return response.data;
  } catch (error) {
    console.error('장바구니 전체 삭제 실패:', error);
    throw new Error(error.response?.data?.message || '장바구니를 비우는데 실패했습니다.');
  }
};

/**
 * 위시리스트 토글 (추가/삭제)
 * @param {number} userId - 사용자 ID
 * @param {number} productId - 상품 ID
 * @returns {Promise}
 */
export const toggleWish = async (userId, productId) => {
  try {
    const response = await api.post('/wishlist/toggle', null, {
      params: { userId, productId },
    });

    return response.data;
  } catch (error) {
    console.error('위시리스트 토글 실패:', error);
    throw new Error(error.response?.data?.message || '위시리스트를 업데이트하는데 실패했습니다.');
  }
};

/**
 * 위시리스트 조회
 * @param {number} userId - 사용자 ID
 * @returns {Promise} 위시리스트 상품 목록
 */
export const getWishList = async (userId) => {
  try {
    const response = await api.get('/wishlist', {
      params: { userId },
    });

    return response.data;
  } catch (error) {
    console.error('위시리스트 조회 실패:', error);
    throw new Error(error.response?.data?.message || '위시리스트를 불러오는데 실패했습니다.');
  }
};

/**
 * 최근 본 상품 목록 조회
 * @param {number} userId - 사용자 ID
 * @returns {Promise} 최근 본 상품 목록
 */
export const getRecentProductList = async (userId) => {
  try {
    const response = await api.get('/recent-product', {
      params: { userId },
    });

    return response.data;
  } catch (error) {
    console.error('최근 본 상품 목록 조회 실패:', error);
    throw new Error(error.response?.data?.message || '최근 본 상품 목록을 불러오는데 실패했습니다.');
  }
};

/**
 * 최근 본 상품 삭제
 * @param {number} userId - 사용자 ID
 * @param {number} productId - 상품 ID
 * @returns {Promise}
 */
export const deleteRecentProduct = async (userId, productId) => {
  try {
    const response = await api.delete('/recent-product', {
      params: { userId, productId },
    });

    return response.data;
  } catch (error) {
    console.error('최근 본 상품 삭제 실패:', error);
    throw new Error(error.response?.data?.message || '최근 본 상품을 삭제하는데 실패했습니다.');
  }
};

/**
 * 주문하기
 * @param {Object} orderData - { id, payType, addressId, totalPrice }
 * @returns {Promise}
 */
export const createOrder = async (orderData) => {
  try {
    const response = await api.post('/order', orderData);
    return response.data;
  } catch (error) {
    console.error('주문 생성 실패:', error);
    throw new Error(error.response?.data?.message || '주문에 실패했습니다.');
  }
};

/**
 * 주문 목록 조회
 * @param {Object} params - { userId, startDate, endDate, page, size }
 * @returns {Promise} 주문 목록과 페이지 정보
 */
export const getOrderList = async (params = {}) => {
  try {
    const { userId, startDate, endDate, page = 1, size = 10 } = params;

    const response = await api.get('/order', {
      params: {
        userId,
        startDate,
        endDate,
        page,
        size,
      },
    });

    return response.data;
  } catch (error) {
    console.error('주문 목록 조회 실패:', error);
    throw new Error(error.response?.data?.message || '주문 목록을 불러오는데 실패했습니다.');
  }
};
