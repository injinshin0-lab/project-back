import axios from 'axios';

const API_BASE_URL = '/api/v1';

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

/**
 * 로그아웃
 * @param {number} userId - 사용자 ID
 * @returns {Promise}
 */
export const logout = async (userId) => {
  try {
    const response = await api.post(`/user/logout/${userId}`);
    return response.data;
  } catch (error) {
    console.error('로그아웃 실패:', error);
    throw new Error(error.response?.data?.message || '로그아웃에 실패했습니다.');
  }
};

/**
 * 이메일 인증 코드 발송
 * @param {string} email - 이메일 주소
 * @returns {Promise}
 */
export const sendEmailCode = async (email) => {
  try {
    const response = await api.post('/user/email/send-code', null, {
      params: { email },
    });
    return response.data;
  } catch (error) {
    console.error('이메일 인증 코드 발송 실패:', error);
    throw new Error(error.response?.data?.message || '이메일 인증 코드 발송에 실패했습니다.');
  }
};

/**
 * 이메일 인증 코드 확인
 * @param {Object} data - { email, authCode }
 * @returns {Promise<boolean>}
 */
export const checkEmailCode = async (data) => {
  try {
    const response = await api.post('/user/email/check-code', data);
    return response.data;
  } catch (error) {
    console.error('이메일 인증 코드 확인 실패:', error);
    throw new Error(error.response?.data?.message || '이메일 인증 코드 확인에 실패했습니다.');
  }
};

/**
 * 사용자 선택 카테고리 목록 조회
 * @param {number} userId - 사용자 ID
 * @returns {Promise} 카테고리 목록
 */
export const getUserCategories = async (userId) => {
  try {
    const response = await api.get('/user/categories', {
      params: { userId },
    });
    return response.data;
  } catch (error) {
    console.error('카테고리 목록 조회 실패:', error);
    throw new Error(error.response?.data?.message || '카테고리 목록을 불러오는데 실패했습니다.');
  }
};

/**
 * 사용자 선택 카테고리 업데이트
 * @param {number} userId - 사용자 ID
 * @param {Array<number>} categoryIds - 카테고리 ID 리스트
 * @returns {Promise}
 */
export const updateUserCategories = async (userId, categoryIds) => {
  try {
    const response = await api.put('/user/categories', categoryIds, {
      params: { userId },
    });
    return response.data;
  } catch (error) {
    console.error('카테고리 업데이트 실패:', error);
    throw new Error(error.response?.data?.message || '카테고리 업데이트에 실패했습니다.');
  }
};

/**
 * 사용자 정보 업데이트
 * @param {Object} userData - { userId, phone, categoryId }
 * @returns {Promise}
 */
export const updateUser = async (userData) => {
  try {
    const response = await api.put('/user', userData);
    return response.data;
  } catch (error) {
    console.error('사용자 정보 업데이트 실패:', error);
    throw new Error(error.response?.data?.message || '사용자 정보 업데이트에 실패했습니다.');
  }
};

/**
 * 비밀번호 확인
 * @param {number} userId - 사용자 ID
 * @param {string} password - 비밀번호
 * @returns {Promise<boolean>}
 */
export const checkPassword = async (userId, password) => {
  try {
    const response = await api.post('/user/check-password', null, {
      params: { userId, password },
    });
    return response.data;
  } catch (error) {
    console.error('비밀번호 확인 실패:', error);
    throw new Error(error.response?.data?.message || '비밀번호 확인에 실패했습니다.');
  }
};

/**
 * 비밀번호 변경
 * @param {number} userId - 사용자 ID
 * @param {string} newPassword - 새 비밀번호
 * @returns {Promise}
 */
export const updatePassword = async (userId, newPassword) => {
  try {
    const response = await api.put('/user/password', null, {
      params: { userId, newPassword },
    });
    return response.data;
  } catch (error) {
    console.error('비밀번호 변경 실패:', error);
    throw new Error(error.response?.data?.message || '비밀번호 변경에 실패했습니다.');
  }
};

/**
 * 주소 목록 조회
 * @param {number} userId - 사용자 ID
 * @returns {Promise} 주소 목록
 */
export const getAddressList = async (userId) => {
  try {
    const response = await api.get('/user/address', {
      params: { userId },
    });
    return response.data;
  } catch (error) {
    console.error('주소 목록 조회 실패:', error);
    throw new Error(error.response?.data?.message || '주소 목록을 불러오는데 실패했습니다.');
  }
};

/**
 * 주소 추가
 * @param {Object} addressData - 주소 정보
 * @returns {Promise}
 */
export const insertAddress = async (addressData) => {
  try {
    const response = await api.post('/user/address', addressData);
    return response.data;
  } catch (error) {
    console.error('주소 추가 실패:', error);
    throw new Error(error.response?.data?.message || '주소 추가에 실패했습니다.');
  }
};

/**
 * 주소 수정
 * @param {Object} addressData - 주소 정보
 * @returns {Promise}
 */
export const updateAddress = async (addressData) => {
  try {
    const response = await api.put('/user/address', addressData);
    return response.data;
  } catch (error) {
    console.error('주소 수정 실패:', error);
    throw new Error(error.response?.data?.message || '주소 수정에 실패했습니다.');
  }
};

/**
 * 주소 삭제
 * @param {number} addressId - 주소 ID
 * @param {number} userId - 사용자 ID
 * @returns {Promise}
 */
export const deleteAddress = async (addressId, userId) => {
  try {
    const response = await api.delete('/user/address', {
      params: { addressId, userId },
    });
    return response.data;
  } catch (error) {
    console.error('주소 삭제 실패:', error);
    throw new Error(error.response?.data?.message || '주소 삭제에 실패했습니다.');
  }
};

/**
 * 회원 탈퇴
 * @param {number} userId - 사용자 ID
 * @param {string} password - 비밀번호
 * @returns {Promise}
 */
export const deleteUser = async (userId, password) => {
  try {
    const response = await api.delete('/user', {
      params: { userId, password },
    });
    return response.data;
  } catch (error) {
    console.error('회원 탈퇴 실패:', error);
    throw new Error(error.response?.data?.message || '회원 탈퇴에 실패했습니다.');
  }
};




