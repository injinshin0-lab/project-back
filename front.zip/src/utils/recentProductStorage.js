// 최근 본 상품 로컬스토리지 관리 유틸리티

const STORAGE_KEY = 'recentProducts';
const MAX_ITEMS = 50; // 최대 저장 개수

/**
 * 로컬스토리지에서 최근 본 상품 목록 가져오기
 * @returns {Array} 최근 본 상품 목록
 */
export const getRecentProductsFromStorage = () => {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (!stored) return [];
    return JSON.parse(stored);
  } catch (error) {
    console.error('최근 본 상품 로컬스토리지 읽기 실패:', error);
    return [];
  }
};

/**
 * 로컬스토리지에 최근 본 상품 저장
 * @param {Object} product - 상품 정보 { productId, productName, price, imageUrl, category }
 */
export const saveRecentProductToStorage = (product) => {
  try {
    const recentProducts = getRecentProductsFromStorage();
    
    // 이미 있는 상품이면 제거 (중복 제거)
    const filtered = recentProducts.filter(p => p.productId !== product.productId);
    
    // 최신 상품을 맨 앞에 추가
    const updated = [product, ...filtered].slice(0, MAX_ITEMS);
    
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
  } catch (error) {
    console.error('최근 본 상품 로컬스토리지 저장 실패:', error);
  }
};

/**
 * 로컬스토리지에서 최근 본 상품 삭제
 * @param {number} productId - 상품 ID
 */
export const deleteRecentProductFromStorage = (productId) => {
  try {
    const recentProducts = getRecentProductsFromStorage();
    const updated = recentProducts.filter(p => p.productId !== productId);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
  } catch (error) {
    console.error('최근 본 상품 로컬스토리지 삭제 실패:', error);
  }
};

/**
 * 로컬스토리지에서 최근 본 상품 모두 삭제
 */
export const clearRecentProductsFromStorage = () => {
  try {
    localStorage.removeItem(STORAGE_KEY);
  } catch (error) {
    console.error('최근 본 상품 로컬스토리지 전체 삭제 실패:', error);
  }
};










