// 로컬스토리지에 자동로그인 정보 저장/조회/삭제 유틸리티

const AUTH_STORAGE_KEY = 'autoLoginUser';

/**
 * 로컬스토리지에 사용자 정보 저장
 * @param {Object} userData - { id, name, role }
 */
export const saveUserToStorage = (userData) => {
  try {
    const userInfo = {
      id: userData.id || userData.user_id,
      name: userData.name,
      role: userData.role,
      savedAt: new Date().toISOString()
    };
    localStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(userInfo));
  } catch (error) {
    console.error('로컬스토리지 저장 실패:', error);
  }
};

/**
 * 로컬스토리지에서 사용자 정보 조회
 * @returns {Object|null} 사용자 정보 또는 null
 */
export const getUserFromStorage = () => {
  try {
    const stored = localStorage.getItem(AUTH_STORAGE_KEY);
    if (!stored) return null;
    
    const userInfo = JSON.parse(stored);
    return {
      id: userInfo.id,
      name: userInfo.name,
      role: userInfo.role
    };
  } catch (error) {
    console.error('로컬스토리지 조회 실패:', error);
    return null;
  }
};

/**
 * 로컬스토리지에서 사용자 정보 삭제
 */
export const removeUserFromStorage = () => {
  try {
    localStorage.removeItem(AUTH_STORAGE_KEY);
  } catch (error) {
    console.error('로컬스토리지 삭제 실패:', error);
  }
};










