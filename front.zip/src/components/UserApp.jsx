import { useState } from 'react'
import FaqPage from '../pages/FaqPage'
import ProductPage from '../pages/ProductPage'
import CartPage from '../pages/CartPage'
import OrderPage from '../pages/OrderPage'
import WishlistPage from '../pages/WishlistPage'
import RecentProductPage from '../pages/RecentProductPage'
import UserProfilePage from '../pages/UserProfilePage'
import ReviewPage from '../pages/ReviewPage'
import QuestionPage from '../pages/QuestionPage'
import AlarmPage from '../pages/AlarmPage'

function UserApp({ user, onLogout, onNavigateToPage: parentNavigateToPage }) {
  const [currentPage, setCurrentPage] = useState('product')

  const navigateToPage = (page, productId = null) => {
    setCurrentPage(page)
    // 부모의 navigateToPage도 호출 (URL 업데이트)
    if (parentNavigateToPage) {
      parentNavigateToPage(page, productId)
    }
  }

  return (
    <div className="app">
      <nav className="app-nav">
        <button
          className={currentPage === 'product' ? 'active' : ''}
          onClick={() => setCurrentPage('product')}
        >
          상품
        </button>
        <button
          className={currentPage === 'cart' ? 'active' : ''}
          onClick={() => setCurrentPage('cart')}
        >
          장바구니
        </button>
        <button
          className={currentPage === 'order' ? 'active' : ''}
          onClick={() => setCurrentPage('order')}
        >
          주문
        </button>
        <button
          className={currentPage === 'wishlist' ? 'active' : ''}
          onClick={() => setCurrentPage('wishlist')}
        >
          찜목록
        </button>
        <button
          className={currentPage === 'recent-product' ? 'active' : ''}
          onClick={() => setCurrentPage('recent-product')}
        >
          최근 본 상품
        </button>
        <button
          className={currentPage === 'faq' ? 'active' : ''}
          onClick={() => setCurrentPage('faq')}
        >
          FAQ
        </button>
        <button
          className={currentPage === 'user-profile' ? 'active' : ''}
          onClick={() => setCurrentPage('user-profile')}
        >
          회원정보
        </button>
        <button
          className={currentPage === 'review' ? 'active' : ''}
          onClick={() => setCurrentPage('review')}
        >
          리뷰
        </button>
        <button
          className={currentPage === 'question' ? 'active' : ''}
          onClick={() => setCurrentPage('question')}
        >
          문의
        </button>
        <button
          className={currentPage === 'alarm' ? 'active' : ''}
          onClick={() => setCurrentPage('alarm')}
        >
          알림
        </button>
        {onLogout && (
          <button
            onClick={onLogout}
            style={{ marginLeft: 'auto' }}
          >
            로그아웃
          </button>
        )}
      </nav>
      {currentPage === 'product' && (
        <ProductPage 
          user={user} 
          onNavigateToPage={navigateToPage}
          initialProductId={(() => {
            const urlParams = new URLSearchParams(window.location.search)
            const productId = urlParams.get('productId')
            return productId ? parseInt(productId) : null
          })()}
          key={`product-${currentPage}-${(() => {
            const urlParams = new URLSearchParams(window.location.search)
            return urlParams.get('productId') || 'list'
          })()}`} // productId가 변경되면 컴포넌트 재마운트
        />
      )}
      {currentPage === 'recent-product' && (
        <RecentProductPage 
          user={user}
          onBack={() => navigateToPage('product')}
          onNavigateToPage={navigateToPage}
        />
      )}
      {currentPage === 'cart' && <CartPage user={user} />}
      {currentPage === 'order' && <OrderPage user={user} />}
      {currentPage === 'wishlist' && <WishlistPage user={user} />}
      {currentPage === 'recent-product' && (
        <RecentProductPage 
          user={user}
          onBack={() => navigateToPage('product')}
          onNavigateToPage={navigateToPage}
        />
      )}
      {currentPage === 'faq' && <FaqPage />}
      {currentPage === 'user-profile' && <UserProfilePage user={user} onLogout={onLogout} />}
      {currentPage === 'review' && <ReviewPage user={user} />}
      {currentPage === 'question' && <QuestionPage user={user} />}
      {currentPage === 'alarm' && <AlarmPage user={user} />}
    </div>
  )
}

export default UserApp
