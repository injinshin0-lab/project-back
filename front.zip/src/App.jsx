import { useState, useEffect } from 'react'
import ProductPage from './pages/ProductPage'
import LoginPage from './pages/LoginPage'
import AdminPage from './pages/AdminPage'
import UserApp from './components/UserApp'
import RecentProductPage from './pages/RecentProductPage'
import { autoLogin, login, logout } from './api/loginApi'
import { saveUserToStorage, getUserFromStorage, removeUserFromStorage } from './utils/authStorage'
import './App.css'

function App() {
  const [user, setUser] = useState(null)
  const [loading, setLoading] = useState(true)
  const [currentPage, setCurrentPage] = useState('product')

  // 페이지 로드 시 자동 로그인 체크 및 URL에서 페이지 정보 읽기
  useEffect(() => {
    // URL에서 페이지 정보 읽기
    const urlParams = new URLSearchParams(window.location.search)
    const pageFromUrl = urlParams.get('page') || 'product'
    setCurrentPage(pageFromUrl)
    
    checkAutoLogin()
  }, [])

  // 브라우저 뒤로가기/앞으로가기 처리
  useEffect(() => {
    const handlePopState = (event) => {
      const urlParams = new URLSearchParams(window.location.search)
      const pageFromUrl = urlParams.get('page') || 'product'
      setCurrentPage(pageFromUrl)
    }

    window.addEventListener('popstate', handlePopState)
    return () => {
      window.removeEventListener('popstate', handlePopState)
    }
  }, [])

  // 페이지 이동 함수 (히스토리에 추가)
  const navigateToPage = (page, productId = null) => {
    setCurrentPage(page)
    let newUrl = `${window.location.pathname}?page=${page}`
    if (productId) {
      newUrl += `&productId=${productId}`
    }
    window.history.pushState({ page, productId }, '', newUrl)
  }

  // URL에서 productId 가져오기
  const getProductIdFromUrl = () => {
    const urlParams = new URLSearchParams(window.location.search)
    const productId = urlParams.get('productId')
    return productId ? parseInt(productId) : null
  }

  const checkAutoLogin = async () => {
    try {
      // 먼저 브라우저 로컬스토리지에서 확인
      const storedUser = getUserFromStorage()
      if (storedUser) {
        // 로컬스토리지에 정보가 있으면 서버에 요청하지 않고 바로 사용
        setUser(storedUser)
      } else {
        // 로컬스토리지에 정보가 없을 때만 서버에 요청
        try {
          const userData = await autoLogin()
          if (userData && userData.isAuthenticated) {
            const user = {
              id: userData.user_id,
              name: userData.name,
              role: userData.role
            }
            setUser(user)
            saveUserToStorage(user)
          } else {
            setUser(null)
          }
        } catch (error) {
          // 서버 요청 실패 (401 등) - 로그인하지 않은 상태 (정상적인 경우이므로 에러 로그 출력 안 함)
          // 401 에러나 조용한 에러는 콘솔에 출력하지 않음
          if (error.response?.status !== 401 && !error.silent) {
            console.error('자동 로그인 실패:', error)
          }
          setUser(null)
        }
      }
    } catch (error) {
      // 예상치 못한 에러
      console.error('자동 로그인 체크 중 에러:', error)
      setUser(null)
    } finally {
      setLoading(false)
    }
  }

  const handleLoginSuccess = async (loginData) => {
    try {
      const userData = await login(loginData)
      // 로그인 성공 후 다시 auto-login으로 role 포함 정보 가져오기
      try {
        const autoLoginData = await autoLogin()
        if (autoLoginData.isAuthenticated) {
          const user = {
            id: autoLoginData.user_id,
            name: autoLoginData.name,
            role: autoLoginData.role
          }
          setUser(user)
          // 로컬스토리지에 저장
          saveUserToStorage(user)
          // 로그인 후 상품 페이지로 이동
          navigateToPage('product')
        }
      } catch (autoLoginError) {
        // auto-login 실패해도 로그인 응답 데이터로 처리
        if (userData && userData.user_id) {
          const user = {
            id: userData.user_id,
            name: userData.name,
            role: 'USER' // 기본값, 세션에서 가져올 수 없을 때
          }
          setUser(user)
          saveUserToStorage(user)
          navigateToPage('product')
        } else {
          throw autoLoginError
        }
      }
    } catch (error) {
      throw error
    }
  }

  const handleLogout = async () => {
    if (user) {
      try {
        // 세션 로그아웃 시도 (인터넷이 켜져있을 때)
        try {
          await logout(user.id)
        } catch (error) {
          console.error('세션 로그아웃 실패 (인터넷이 꺼져있을 수 있음):', error)
        }
      } catch (error) {
        console.error('로그아웃 실패:', error)
      }
    }
    // 로컬스토리지에서 사용자 정보 삭제
    removeUserFromStorage()
    setUser(null)
    // 로그아웃 후 상품 페이지로 이동
    navigateToPage('product')
  }

  // 로딩 중
  if (loading) {
    return <div style={{ padding: '20px', textAlign: 'center' }}>로딩 중...</div>
  }

  // 로그인 페이지
  if (currentPage === 'login') {
    return <LoginPage onLoginSuccess={handleLoginSuccess} onBack={() => navigateToPage('product')} />
  }

  // ADMIN 권한인 경우
  if (user && user.role === 'ADMIN') {
    return <AdminPage onLogout={handleLogout} onBack={() => navigateToPage('product')} />
  }

  // 메인 페이지: 상품 리스트 (로그인 없이도 접근 가능)
  if (currentPage === 'user' && user) {
    return <UserApp user={user} onLogout={handleLogout} />
  }

  // 최근 본 상품 페이지
  if (currentPage === 'recent-product') {
    return (
      <RecentProductPage 
        user={user}
        onBack={() => navigateToPage('product')}
        onNavigateToPage={navigateToPage}
      />
    )
  }
  
  return (
    <ProductPage 
      user={user}
      onLogin={() => navigateToPage('login')}
      onNavigateToUserApp={() => {
        if (user) {
          navigateToPage('user')
        }
      }}
      onNavigateToPage={navigateToPage}
      initialProductId={getProductIdFromUrl()}
      key={`product-${currentPage}-${getProductIdFromUrl() || 'list'}`} // productId가 변경되면 컴포넌트 재마운트
    />
  )
}

export default App
