import { useState, useEffect } from 'react';
import { getProductList, getProduct, getAllCategories, toggleWish, addCartItem } from '../api/productApi';
import { getReviewsByProduct } from '../api/reviewApi';
import { saveRecentProductToStorage } from '../utils/recentProductStorage';
import './ProductPage.css';

function ProductPage({ user, onLogin, onNavigateToUserApp, onNavigateToPage, initialProductId = null }) {
  const [productList, setProductList] = useState([]);
  const [categories, setCategories] = useState([]);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [keyword, setKeyword] = useState('');
  const [categoryId, setCategoryId] = useState(null);
  const [searchKeyword, setSearchKeyword] = useState(''); // 실제 검색에 사용되는 키워드
  const [searchCategoryId, setSearchCategoryId] = useState(null); // 실제 검색에 사용되는 카테고리
  const [page, setPage] = useState(1);
  const [totalPage, setTotalPage] = useState(1);
  const [showReviews, setShowReviews] = useState(false);
  const [reviews, setReviews] = useState([]);
  const [reviewsLoading, setReviewsLoading] = useState(false);

  // 이미지 URL 보정 함수 (상대경로면 백엔드 도메인 붙이기)
  const resolveImageUrl = (url) => {
    if (!url) return '';
    return url.startsWith('http') ? url : `http://localhost:8080${url}`;
  };

  const fetchProductList = async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await getProductList({
        keyword: searchKeyword,
        categoryId: searchCategoryId,
        page,
        size: 10,
        userId: user?.id || null,
      });
      setProductList(response.list || []);
      setTotalPage(response.totalPage || 1);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = () => {
    setSearchKeyword(keyword);
    setSearchCategoryId(categoryId);
    setPage(1); // 검색 시 첫 페이지로 이동
  };

  const fetchCategories = async () => {
    try {
      const categoriesData = await getAllCategories();
      setCategories(categoriesData || []);
    } catch (err) {
      console.error('카테고리 조회 실패:', err);
    }
  };

  const fetchProductDetail = async (productId) => {
    setLoading(true);
    setError(null);
    try {
      const product = await getProduct(productId, user?.id || null);
      setSelectedProduct(product);
      
      // 최근 본 상품 저장
      if (product) {
        const recentProduct = {
          productId: product.productId,
          productName: product.productName,
          price: product.price,
          imageUrl: product.imageUrl,
          category: product.category ? {
            id: product.category.id,
            categoryName: product.category.categoryName
          } : null
        };
        
        // 로그인 상태에 관계없이 로컬스토리지에 저장
        // (로그인 상태일 경우 백엔드 API가 추가되면 여기에 DB 저장 로직 추가)
        saveRecentProductToStorage(recentProduct);
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const fetchReviews = async (productId) => {
    if (!productId) return;
    setReviewsLoading(true);
    try {
      const data = await getReviewsByProduct(productId);
      setReviews(data || []);
    } catch (err) {
      console.error('리뷰 조회 실패:', err);
    } finally {
      setReviewsLoading(false);
    }
  };

  const handleToggleReviews = (productId) => {
    if (!showReviews) {
      fetchReviews(productId);
    }
    setShowReviews(!showReviews);
  };


  // 찜하기 토글 핸들러
  const handleToggleWish = async (e, productId) => {
    e.stopPropagation(); // 상품 클릭 이벤트 방지
    
    if (!user) {
      alert('로그인이 필요합니다.');
      return;
    }

    try {
      await toggleWish(user.id, productId);
      
      // 상품 목록의 찜 상태 업데이트
      setProductList(prevList =>
        prevList.map(product =>
          product.productId === productId
            ? { ...product, isWished: !product.isWished }
            : product
        )
      );

      // 선택된 상품이 있으면 그 상품의 찜 상태도 업데이트
      if (selectedProduct && selectedProduct.productId === productId) {
        setSelectedProduct(prev => ({
          ...prev,
          isWished: !prev.isWished
        }));
      }
    } catch (err) {
      console.error('찜하기 토글 실패:', err);
      alert('찜하기 상태 변경에 실패했습니다: ' + err.message);
    }
  };

  // 장바구니에 상품 추가 핸들러
  const handleAddToCart = async () => {
    if (!user) {
      alert('로그인이 필요합니다.');
      return;
    }

    if (!selectedProduct) {
      return;
    }

    try {
      await addCartItem({
        userId: user.id,
        productId: selectedProduct.productId,
        quantity: 1,
        productName: selectedProduct.productName,
        price: selectedProduct.price,
        imageUrl: selectedProduct.imageUrl
      });
      
      // 장바구니 담기 성공 후 선택 옵션 제공
      const userChoice = window.confirm(
        '장바구니에 추가되었습니다.\n\n확인을 누르면 장바구니로 이동합니다.\n취소를 누르면 쇼핑을 계속합니다.'
      );
      
      if (userChoice) {
        // 확인 버튼: 장바구니로 이동
        if (onNavigateToPage) {
          onNavigateToPage('cart');
        }
      }
      // 취소 버튼: 쇼핑 계속하기 (현재 페이지 유지, 추가 작업 없음)
    } catch (err) {
      console.error('장바구니 추가 실패:', err);
      alert('장바구니 추가에 실패했습니다: ' + err.message);
    }
  };


  useEffect(() => {
    fetchProductList();
  }, [page, searchKeyword, searchCategoryId, user?.id]);

  useEffect(() => {
    fetchCategories();
  }, []);

  // 컴포넌트 마운트 시 또는 initialProductId 변경 시 상품 상세보기 표시
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const productIdFromUrl = urlParams.get('productId');
    const productId = productIdFromUrl ? parseInt(productIdFromUrl) : initialProductId;
    
    if (productId) {
      // 상세보기 표시
      fetchProductDetail(productId);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [initialProductId]);

  // URL 변경 감지 (popstate 이벤트)
  useEffect(() => {
    const handleUrlChange = () => {
      const urlParams = new URLSearchParams(window.location.search);
      const productIdFromUrl = urlParams.get('productId');
      if (productIdFromUrl) {
        const productId = parseInt(productIdFromUrl);
        if (!selectedProduct || selectedProduct.productId !== productId) {
          fetchProductDetail(productId);
        }
      } else if (selectedProduct) {
        // productId가 없으면 상세보기 닫기
        setSelectedProduct(null);
      }
    };

    // 초기 체크
    handleUrlChange();

    // popstate 이벤트 리스너 (뒤로가기/앞으로가기)
    window.addEventListener('popstate', handleUrlChange);
    
    return () => {
      window.removeEventListener('popstate', handleUrlChange);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className="product-page">
      <div className="product-header">
        <h1>상품 목록</h1>
        <div className="header-actions">
          {onNavigateToPage && (
            <button 
              onClick={() => onNavigateToPage('recent-product')}
              style={{ marginRight: '10px' }}
            >
              최근 본 상품
            </button>
          )}
          {user ? (
            <>
              <span>안녕하세요, {user.name}님</span>
              {user.role === 'ADMIN' ? (
                <button onClick={() => onNavigateToUserApp && onNavigateToUserApp()}>
                  관리자 페이지
                </button>
              ) : (
                <button onClick={() => onNavigateToUserApp && onNavigateToUserApp()}>
                  마이페이지
                </button>
              )}
            </>
          ) : (
            <button onClick={onLogin}>로그인</button>
          )}
        </div>
      </div>
      
      <div className="search-section">
        <input
          type="text"
          value={keyword}
          onChange={(e) => setKeyword(e.target.value)}
          placeholder="검색어"
          onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
        />
        <select
          value={categoryId || ''}
          onChange={(e) => setCategoryId(e.target.value ? parseInt(e.target.value) : null)}
        >
          <option value="">전체 카테고리</option>
          {categories.map((cat) => (
            <option key={cat.id} value={cat.id}>
              {cat.categoryName}
            </option>
          ))}
        </select>
        <button onClick={handleSearch}>검색</button>
      </div>

      {error && <div className="error-message">{error}</div>}

      {selectedProduct ? (
        <div className="product-detail">
          <button 
            onClick={() => {
              setSelectedProduct(null);
              // URL에서 productId 파라미터 제거
              if (onNavigateToPage) {
                onNavigateToPage('product');
              } else {
                // URL 직접 수정
                const url = new URL(window.location);
                url.searchParams.delete('productId');
                window.history.pushState({}, '', url);
              }
            }}
          >
            목록으로
          </button>
          <h2>{selectedProduct.productName}</h2>
          {selectedProduct.imageUrl && (
            <img 
              src={selectedProduct.imageUrl.startsWith('http') ? selectedProduct.imageUrl : `http://localhost:8080${selectedProduct.imageUrl}`}
              alt={selectedProduct.productName} 
              style={{ maxWidth: '300px', marginBottom: '20px' }}
              onError={(e) => {
                e.target.style.display = 'none';
              }}
            />
          )}
          <p><strong>원산지:</strong> {selectedProduct.originName}</p>
          <p><strong>가격:</strong> {selectedProduct.price?.toLocaleString()}원</p>
          {selectedProduct.averageRating !== null && selectedProduct.averageRating !== undefined && (
            <p>
              <strong>평균 평점:</strong> 
              <span style={{ color: '#ff9800', fontWeight: 'bold', marginLeft: '5px' }}>
                ⭐ {selectedProduct.averageRating.toFixed(1)}
              </span>
              {selectedProduct.reviewCount > 0 && (
                <span style={{ color: '#666', fontSize: '14px', marginLeft: '10px' }}>
                  ({selectedProduct.reviewCount}개 리뷰)
                </span>
              )}
            </p>
          )}
          <p><strong>설명:</strong> {selectedProduct.content}</p>
          {selectedProduct.category && (
            <p><strong>카테고리:</strong> {selectedProduct.category.categoryName}</p>
          )}
          <div className="product-detail-actions">
            {user && (
              <>
                <button
                  className={`wish-button-detail ${selectedProduct.isWished ? 'wished' : ''}`}
                  onClick={() => handleToggleWish({ stopPropagation: () => {} }, selectedProduct.productId)}
                  title={selectedProduct.isWished ? '찜 해제' : '찜하기'}
                >
                  {selectedProduct.isWished ? '❤️ 찜함' : '🤍 찜하기'}
                </button>
                <button
                  className="cart-button"
                  onClick={handleAddToCart}
                >
                  🛒 장바구니 담기
                </button>
              </>
            )}
            {!user && (
              <p style={{ color: '#666', fontStyle: 'italic' }}>로그인 후 찜하기와 장바구니 기능을 이용할 수 있습니다.</p>
            )}
          </div>
          <div className="product-reviews-section" style={{ marginTop: '30px', borderTop: '1px solid #e0e0e0', paddingTop: '20px' }}>
            <div style={{ display: 'flex', gap: '10px', marginBottom: '20px' }}>
              <button
                onClick={() => handleToggleReviews(selectedProduct.productId)}
                style={{
                  padding: '10px 20px',
                  backgroundColor: '#007bff',
                  color: 'white',
                  border: 'none',
                  borderRadius: '4px',
                  cursor: 'pointer',
                  fontSize: '16px'
                }}
              >
                {showReviews ? '리뷰 접기' : '리뷰 보기'}
              </button>
              <span style={{ padding: '10px 20px', color: '#666', fontSize: '14px', alignSelf: 'center' }}>
                리뷰 작성은 주문내역에서 배송완료한 상품에 대해 가능합니다.
              </span>
            </div>

            {showReviews && (
              <div className="reviews-container">
                {reviewsLoading ? (
                  <div>리뷰 로딩 중...</div>
                ) : reviews.length === 0 ? (
                  <div style={{ padding: '20px', textAlign: 'center', color: '#666' }}>
                    등록된 리뷰가 없습니다.
                  </div>
                ) : (
                  <div className="reviews-list">
                    {reviews.map((review) => (
                      <div key={review.reviewId} style={{
                        padding: '15px',
                        marginBottom: '15px',
                        border: '1px solid #e0e0e0',
                        borderRadius: '8px',
                        backgroundColor: '#f9f9f9'
                      }}>
                        <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '10px' }}>
                          <span style={{ fontWeight: 'bold' }}>{review.loginId || '익명'}</span>
                          <div>
                            <span style={{ marginRight: '10px' }}>평점: {review.rating}⭐</span>
                            {review.createdAt && (
                              <span style={{ color: '#666', fontSize: '14px' }}>{review.createdAt}</span>
                            )}
                          </div>
                        </div>
                        <div style={{ color: '#333', lineHeight: '1.6' }}>{review.content}</div>
                        {review.reviewImages && review.reviewImages.length > 0 && (
                          <div style={{ marginTop: '10px', display: 'flex', gap: '10px', flexWrap: 'wrap' }}>
                            {review.reviewImages.map((img, idx) => (
                              <img
                                key={idx}
                                src={resolveImageUrl(img.imageUrl)}
                                alt={`리뷰 이미지 ${idx + 1}`}
                                style={{
                                  maxWidth: '150px',
                                  maxHeight: '150px',
                                  borderRadius: '4px',
                                  objectFit: 'cover'
                                }}
                              />
                            ))}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      ) : (
        <>
          {loading ? (
            <div>로딩 중...</div>
          ) : (
            <div className="product-list">
              {productList.length === 0 ? (
                <div>등록된 상품이 없습니다.</div>
              ) : (
                <div className="product-grid">
                  {productList.map((product) => (
                    <div key={product.productId} className="product-item" onClick={() => fetchProductDetail(product.productId)}>
                      {product.imageUrl && (
                        <img 
                          src={product.imageUrl.startsWith('http') ? product.imageUrl : `http://localhost:8080${product.imageUrl}`}
                          alt={product.productName}
                          onError={(e) => {
                            e.target.style.display = 'none';
                          }}
                        />
                      )}
                      <div className="product-info">
                        <h3>{product.productName}</h3>
                        <p>{product.price?.toLocaleString()}원</p>
                        {product.averageRating !== null && product.averageRating !== undefined && product.averageRating > 0 && (
                          <p style={{ margin: '5px 0', color: '#ff9800', fontWeight: 'bold' }}>
                            ⭐ {product.averageRating.toFixed(1)}
                            {product.reviewCount > 0 && (
                              <span style={{ color: '#666', fontSize: '12px', marginLeft: '5px', fontWeight: 'normal' }}>
                                ({product.reviewCount})
                              </span>
                            )}
                          </p>
                        )}
                        {product.category && <p className="category">{product.category.categoryName}</p>}
                      </div>
                      <button
                        className={`wish-button ${product.isWished ? 'wished' : ''}`}
                        onClick={(e) => handleToggleWish(e, product.productId)}
                        title={product.isWished ? '찜 해제' : '찜하기'}
                      >
                        {product.isWished ? '❤️' : '🤍'}
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          <div className="pagination">
            <button disabled={page === 1} onClick={() => setPage(page - 1)}>이전</button>
            <span>{page} / {totalPage}</span>
            <button disabled={page >= totalPage} onClick={() => setPage(page + 1)}>다음</button>
          </div>
        </>
      )}
    </div>
  );
}

export default ProductPage;
