import { useState, useEffect } from 'react';
import {
  getAdminProductList,
  getAdminProduct,
  createProduct,
  updateProduct,
  deleteProduct,
  getReviewsByProduct,
  deleteReview,
} from '../api/adminProductApi';
import { getCategoryList } from '../api/adminApi';
import './AdminProductPage.css';

function AdminProductPage() {
  const [products, setProducts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPage, setTotalPage] = useState(1);
  const [pageSize] = useState(10);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  // 검색 및 필터 상태
  const [searchKeyword, setSearchKeyword] = useState('');
  const [selectedCategoryId, setSelectedCategoryId] = useState(null);
  const [sortBy, setSortBy] = useState('');
  const [sortOrder, setSortOrder] = useState('desc');

  // 상품 등록/수정 폼 상태
  const [showForm, setShowForm] = useState(false);
  const [editingProduct, setEditingProduct] = useState(null);
  const [formData, setFormData] = useState({
    productName: '',
    category: null,
    originName: '',
    content: '',
    price: '',
    imageUrl: '',
  });

  // 리뷰 상태
  const [showReviews, setShowReviews] = useState(false);
  const [reviews, setReviews] = useState([]);
  const [selectedProductId, setSelectedProductId] = useState(null);

  // 카테고리 목록 로드
  useEffect(() => {
    loadCategories();
  }, []);

  // 상품 목록 로드
  useEffect(() => {
    loadProducts();
  }, [currentPage, searchKeyword, selectedCategoryId, sortBy, sortOrder]);

  const loadCategories = async () => {
    try {
      const data = await getCategoryList();
      setCategories(data);
    } catch (err) {
      console.error('카테고리 로드 실패:', err);
    }
  };

  const loadProducts = async () => {
    setLoading(true);
    setError(null);
    try {
      const params = {
        page: currentPage,
        size: pageSize,
        keyword: searchKeyword || undefined,
        categoryId: selectedCategoryId || undefined,
        sort: sortBy || undefined,
        order: sortOrder || undefined,
      };
      const data = await getAdminProductList(params);
      setProducts(data.list || []);
      setTotalPage(data.totalPage || 1);
      setCurrentPage(data.currentPage || 1);
    } catch (err) {
      setError(err.message);
      console.error('상품 목록 로드 실패:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = () => {
    setCurrentPage(1);
    loadProducts();
  };

  const handleReset = () => {
    setSearchKeyword('');
    setSelectedCategoryId(null);
    setSortBy('');
    setSortOrder('desc');
    setCurrentPage(1);
  };

  const handleCreate = () => {
    setEditingProduct(null);
    setFormData({
      productName: '',
      category: null,
      originName: '',
      content: '',
      price: '',
      imageUrl: '',
    });
    setShowForm(true);
  };

  const handleEdit = async (productId) => {
    try {
      const product = await getAdminProduct(productId);
      setEditingProduct(product);
      setFormData({
        productName: product.productName || '',
        category: product.category || null,
        originName: product.originName || '',
        content: product.content || '',
        price: product.price || '',
        imageUrl: product.imageUrl || '',
      });
      setShowForm(true);
    } catch (err) {
      setError(err.message);
      console.error('상품 상세 로드 실패:', err);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      const productData = {
        productId: editingProduct?.productId || null,
        productName: formData.productName,
        category: formData.category,
        originName: formData.originName,
        content: formData.content,
        price: parseInt(formData.price) || 0,
        imageUrl: formData.imageUrl,
      };

      if (editingProduct) {
        await updateProduct(productData);
        alert('상품이 수정되었습니다.');
      } else {
        await createProduct(productData);
        alert('상품이 등록되었습니다.');
      }

      setShowForm(false);
      loadProducts();
    } catch (err) {
      setError(err.message);
      console.error('상품 저장 실패:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (productId) => {
    if (!confirm('정말 삭제하시겠습니까?')) {
      return;
    }

    try {
      const result = await deleteProduct(productId);
      if (result === 1) {
        alert('상품이 삭제되었습니다.');
        loadProducts();
      } else {
        alert('삭제에 실패했습니다.');
      }
    } catch (err) {
      setError(err.message);
      console.error('상품 삭제 실패:', err);
    }
  };

  const handleViewReviews = async (productId) => {
    try {
      const reviewList = await getReviewsByProduct(productId);
      setReviews(reviewList);
      setSelectedProductId(productId);
      setShowReviews(true);
    } catch (err) {
      setError(err.message);
      console.error('리뷰 로드 실패:', err);
    }
  };

  const handleDeleteReview = async (reviewId) => {
    if (!confirm('정말 리뷰를 삭제하시겠습니까?')) {
      return;
    }

    try {
      const result = await deleteReview(reviewId);
      if (result === 1) {
        alert('리뷰가 삭제되었습니다.');
        handleViewReviews(selectedProductId);
      } else {
        alert('삭제에 실패했습니다.');
      }
    } catch (err) {
      setError(err.message);
      console.error('리뷰 삭제 실패:', err);
    }
  };

  const formatPrice = (price) => {
    return new Intl.NumberFormat('ko-KR').format(price);
  };

  return (
    <div className="admin-product-page">
      <div className="admin-product-header">
        <h1>상품 관리</h1>
        <button className="btn-primary" onClick={handleCreate}>
          상품 등록
        </button>
      </div>

      {error && <div className="error-message">{error}</div>}

      {/* 검색 및 필터 영역 */}
      <div className="search-filter-section">
        <div className="search-group">
          <input
            type="text"
            placeholder="상품명, 원산지, 내용 검색"
            value={searchKeyword}
            onChange={(e) => setSearchKeyword(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
            className="search-input"
          />
          <select
            value={selectedCategoryId || ''}
            onChange={(e) => setSelectedCategoryId(e.target.value ? parseInt(e.target.value) : null)}
            className="category-select"
          >
            <option value="">전체 카테고리</option>
            {categories.map((cat) => (
              <option key={cat.id} value={cat.id}>
                {cat.categoryName}
              </option>
            ))}
          </select>
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value)}
            className="sort-select"
          >
            <option value="">정렬 기준</option>
            <option value="productName">상품명</option>
            <option value="price">가격</option>
            <option value="id">등록일</option>
          </select>
          <select
            value={sortOrder}
            onChange={(e) => setSortOrder(e.target.value)}
            className="sort-order-select"
          >
            <option value="asc">오름차순</option>
            <option value="desc">내림차순</option>
          </select>
          <button className="btn-search" onClick={handleSearch}>
            검색
          </button>
          <button className="btn-reset" onClick={handleReset}>
            초기화
          </button>
        </div>
      </div>

      {/* 상품 목록 */}
      {loading ? (
        <div className="loading">로딩 중...</div>
      ) : (
        <>
          <div className="product-table-container">
            <table className="product-table">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>상품명</th>
                  <th>카테고리</th>
                  <th>원산지</th>
                  <th>가격</th>
                  <th>이미지</th>
                  <th>작업</th>
                </tr>
              </thead>
              <tbody>
                {products.length === 0 ? (
                  <tr>
                    <td colSpan="7" className="no-data">
                      등록된 상품이 없습니다.
                    </td>
                  </tr>
                ) : (
                  products.map((product) => (
                    <tr key={product.productId}>
                      <td>{product.productId}</td>
                      <td className="product-name">{product.productName}</td>
                      <td>{product.category?.categoryName || '-'}</td>
                      <td>{product.originName || '-'}</td>
                      <td className="price">{formatPrice(product.price)}원</td>
                      <td>
                        {product.imageUrl ? (
                          <img
                            src={product.imageUrl}
                            alt={product.productName}
                            className="product-thumbnail"
                          />
                        ) : (
                          <span className="no-image">이미지 없음</span>
                        )}
                      </td>
                      <td className="action-buttons">
                        <button
                          className="btn-edit"
                          onClick={() => handleEdit(product.productId)}
                        >
                          수정
                        </button>
                        <button
                          className="btn-delete"
                          onClick={() => handleDelete(product.productId)}
                        >
                          삭제
                        </button>
                        <button
                          className="btn-reviews"
                          onClick={() => handleViewReviews(product.productId)}
                        >
                          리뷰
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>

          {/* 페이지네이션 */}
          {totalPage > 1 && (
            <div className="pagination">
              <button
                disabled={currentPage === 1}
                onClick={() => setCurrentPage(currentPage - 1)}
              >
                이전
              </button>
              <span>
                {currentPage} / {totalPage}
              </span>
              <button
                disabled={currentPage === totalPage}
                onClick={() => setCurrentPage(currentPage + 1)}
              >
                다음
              </button>
            </div>
          )}
        </>
      )}

      {/* 상품 등록/수정 폼 모달 */}
      {showForm && (
        <div className="modal-overlay" onClick={() => setShowForm(false)}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <h2>{editingProduct ? '상품 수정' : '상품 등록'}</h2>
              <button className="close-btn" onClick={() => setShowForm(false)}>
                ×
              </button>
            </div>
            <form onSubmit={handleSubmit}>
              <div className="form-group">
                <label>상품명 *</label>
                <input
                  type="text"
                  value={formData.productName}
                  onChange={(e) =>
                    setFormData({ ...formData, productName: e.target.value })
                  }
                  required
                />
              </div>
              <div className="form-group">
                <label>카테고리 *</label>
                <select
                  value={formData.category?.categoryId || ''}
                  onChange={(e) => {
                    const selectedCat = categories.find(
                      (cat) => cat.id === parseInt(e.target.value)
                    );
                    setFormData({
                      ...formData,
                      category: selectedCat
                        ? {
                            categoryId: selectedCat.id,
                            categoryName: selectedCat.categoryName,
                            parentId: selectedCat.parentId,
                            level: selectedCat.depth,
                          }
                        : null,
                    });
                  }}
                  required
                >
                  <option value="">선택하세요</option>
                  {categories.map((cat) => (
                    <option key={cat.id} value={cat.id}>
                      {cat.categoryName}
                    </option>
                  ))}
                </select>
              </div>
              <div className="form-group">
                <label>원산지</label>
                <input
                  type="text"
                  value={formData.originName}
                  onChange={(e) =>
                    setFormData({ ...formData, originName: e.target.value })
                  }
                />
              </div>
              <div className="form-group">
                <label>내용</label>
                <textarea
                  value={formData.content}
                  onChange={(e) =>
                    setFormData({ ...formData, content: e.target.value })
                  }
                  rows="5"
                />
              </div>
              <div className="form-group">
                <label>가격 *</label>
                <input
                  type="number"
                  value={formData.price}
                  onChange={(e) =>
                    setFormData({ ...formData, price: e.target.value })
                  }
                  required
                  min="0"
                />
              </div>
              <div className="form-group">
                <label>이미지 URL</label>
                <input
                  type="url"
                  value={formData.imageUrl}
                  onChange={(e) =>
                    setFormData({ ...formData, imageUrl: e.target.value })
                  }
                />
              </div>
              <div className="form-actions">
                <button type="submit" className="btn-primary" disabled={loading}>
                  {editingProduct ? '수정' : '등록'}
                </button>
                <button
                  type="button"
                  className="btn-secondary"
                  onClick={() => setShowForm(false)}
                >
                  취소
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 리뷰 목록 모달 */}
      {showReviews && (
        <div className="modal-overlay" onClick={() => setShowReviews(false)}>
          <div className="modal-content reviews-modal" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <h2>리뷰 목록</h2>
              <button className="close-btn" onClick={() => setShowReviews(false)}>
                ×
              </button>
            </div>
            <div className="reviews-list">
              {reviews.length === 0 ? (
                <div className="no-data">리뷰가 없습니다.</div>
              ) : (
                reviews.map((review) => (
                  <div key={review.reviewId} className="review-item">
                    <div className="review-header">
                      <span className="review-user">{review.loginId}</span>
                      <span className="review-rating">⭐ {review.rating}</span>
                      <button
                        className="btn-delete-small"
                        onClick={() => handleDeleteReview(review.reviewId)}
                      >
                        삭제
                      </button>
                    </div>
                    <div className="review-content">{review.content}</div>
                    {review.reviewImages && review.reviewImages.length > 0 && (
                      <div className="review-images">
                        {review.reviewImages.map((img) => (
                          <img
                            key={img.reviewImageId}
                            src={img.imageUrl}
                            alt="리뷰 이미지"
                            className="review-image"
                          />
                        ))}
                      </div>
                    )}
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default AdminProductPage;
