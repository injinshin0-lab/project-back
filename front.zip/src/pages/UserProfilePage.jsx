import { useState, useEffect } from 'react';
import {
  getUserCategories,
  updateUserCategories,
  updateUser,
  checkPassword,
  updatePassword,
  getAddressList,
  insertAddress,
  updateAddress,
  deleteAddress,
  deleteUser,
  logout,
} from '../api/userProfileApi';
import { getAllCategories } from '../api/productApi';
import { removeUserFromStorage } from '../utils/authStorage';
import './UserProfilePage.css';

function UserProfilePage({ user, onLogout }) {
  const [userId, setUserId] = useState(user?.id || null);
  const [activeTab, setActiveTab] = useState('profile');

  // 사용자 정보
  const [userInfo, setUserInfo] = useState({
    userId: 1,
    phone: '',
    categoryId: [],
  });

  // 카테고리
  const [userCategories, setUserCategories] = useState([]);
  const [allCategories, setAllCategories] = useState([]);
  const [selectedCategories, setSelectedCategories] = useState([]);

  // 비밀번호
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  // 주소
  const [addressList, setAddressList] = useState([]);
  const [showAddressForm, setShowAddressForm] = useState(false);
  const [addressForm, setAddressForm] = useState({
    addressId: null,
    userId: 1,
    recipient: '',
    postcode: '',
    address: '',
    detailAddress: '',
    isDefault: false,
    recipientPhone: '',
  });

  const [error, setError] = useState(null);

  // user prop이 변경되면 userId 업데이트
  useEffect(() => {
    if (user?.id) {
      setUserId(user.id);
    }
  }, [user]);

  useEffect(() => {
    if (userId) {
      fetchUserCategories();
      fetchAllCategories();
      fetchAddressList();
    }
  }, [userId]);

  const fetchUserCategories = async () => {
    try {
      const categories = await getUserCategories(userId);
      setUserCategories(categories || []);
      setSelectedCategories((categories || []).map((c) => c.id));
    } catch (err) {
      setError(err.message);
    }
  };

  const fetchAllCategories = async () => {
    try {
      const categories = await getAllCategories();
      setAllCategories(categories || []);
    } catch (err) {
      console.error('전체 카테고리 조회 실패:', err);
    }
  };

  const fetchAddressList = async () => {
    try {
      const addresses = await getAddressList(userId);
      setAddressList(addresses || []);
    } catch (err) {
      setError(err.message);
    }
  };

  const handleUpdateCategories = async () => {
    try {
      await updateUserCategories(userId, selectedCategories);
      alert('카테고리가 업데이트되었습니다.');
      fetchUserCategories();
    } catch (err) {
      alert('카테고리 업데이트 실패: ' + err.message);
    }
  };

  const handleUpdateUser = async () => {
    try {
      await updateUser({ ...userInfo, userId });
      alert('사용자 정보가 업데이트되었습니다.');
    } catch (err) {
      alert('사용자 정보 업데이트 실패: ' + err.message);
    }
  };

  const handleCheckPassword = async () => {
    try {
      const result = await checkPassword(userId, currentPassword);
      if (result) {
        alert('비밀번호가 확인되었습니다.');
      } else {
        alert('비밀번호가 일치하지 않습니다.');
      }
    } catch (err) {
      alert('비밀번호 확인 실패: ' + err.message);
    }
  };

  const handleUpdatePassword = async () => {
    if (newPassword !== confirmPassword) {
      alert('새 비밀번호와 확인 비밀번호가 일치하지 않습니다.');
      return;
    }
    try {
      await updatePassword(userId, newPassword);
      alert('비밀번호가 변경되었습니다.');
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
    } catch (err) {
      alert('비밀번호 변경 실패: ' + err.message);
    }
  };

  const handleSaveAddress = async () => {
    try {
      if (addressForm.addressId) {
        await updateAddress({ ...addressForm, userId });
      } else {
        await insertAddress({ ...addressForm, userId });
      }
      alert('주소가 저장되었습니다.');
      setShowAddressForm(false);
      setAddressForm({
        addressId: null,
        userId: 1,
        recipient: '',
        postcode: '',
        address: '',
        detailAddress: '',
        isDefault: false,
        recipientPhone: '',
      });
      fetchAddressList();
    } catch (err) {
      alert('주소 저장 실패: ' + err.message);
    }
  };

  const handleDeleteAddress = async (addressId) => {
    if (!confirm('주소를 삭제하시겠습니까?')) return;
    try {
      await deleteAddress(addressId, userId);
      alert('주소가 삭제되었습니다.');
      fetchAddressList();
    } catch (err) {
      alert('주소 삭제 실패: ' + err.message);
    }
  };

  const handleDeleteUser = async () => {
    if (!user || !user.id) {
      alert('로그인이 필요합니다.');
      return;
    }
    
    const password = prompt('비밀번호를 입력하세요:');
    if (!password) return;
    if (!confirm('정말 회원 탈퇴하시겠습니까?')) return;
    
    try {
      await deleteUser(user.id, password);
      // 로컬스토리지에서 사용자 정보 삭제
      removeUserFromStorage();
      alert('회원 탈퇴가 완료되었습니다.');
      // 로그아웃 처리
      if (onLogout) {
        onLogout();
      } else {
        // onLogout이 없으면 페이지 새로고침
        window.location.href = '/';
      }
    } catch (err) {
      alert('회원 탈퇴 실패: ' + err.message);
    }
  };

  const handleLogout = async () => {
    try {
      await logout(user?.id || userId);
      alert('로그아웃되었습니다.');
      if (onLogout) {
        onLogout();
      }
    } catch (err) {
      alert('로그아웃 실패: ' + err.message);
    }
  };

  return (
    <div className="user-profile-page">
      <h1>회원정보 관리</h1>

      <div className="user-section">
        <button onClick={handleLogout}>로그아웃</button>
      </div>

      {error && <div className="error-message">{error}</div>}

      <div className="tabs">
        <button
          className={activeTab === 'profile' ? 'active' : ''}
          onClick={() => setActiveTab('profile')}
        >
          프로필
        </button>
        <button
          className={activeTab === 'category' ? 'active' : ''}
          onClick={() => setActiveTab('category')}
        >
          관심 카테고리
        </button>
        <button
          className={activeTab === 'password' ? 'active' : ''}
          onClick={() => setActiveTab('password')}
        >
          비밀번호 변경
        </button>
        <button
          className={activeTab === 'address' ? 'active' : ''}
          onClick={() => setActiveTab('address')}
        >
          주소 관리
        </button>
      </div>

      {activeTab === 'profile' && (
        <div className="tab-content">
          <h2>사용자 정보 수정</h2>
          <div className="form-group">
            <label>전화번호: </label>
            <input
              type="text"
              value={userInfo.phone}
              onChange={(e) => setUserInfo({ ...userInfo, phone: e.target.value })}
              placeholder="전화번호"
            />
          </div>
          <button onClick={handleUpdateUser}>정보 수정</button>
          <div style={{ marginTop: '20px', borderTop: '1px solid #ddd', paddingTop: '20px' }}>
            <h3>회원 탈퇴</h3>
            <button onClick={handleDeleteUser} className="delete-btn">
              회원 탈퇴
            </button>
          </div>
        </div>
      )}

      {activeTab === 'category' && (
        <div className="tab-content">
          <h2>관심 카테고리 관리</h2>
          <div className="category-list">
            {allCategories.map((category) => (
              <label key={category.id} className="category-item">
                <input
                  type="checkbox"
                  checked={selectedCategories.includes(category.id)}
                  onChange={(e) => {
                    if (e.target.checked) {
                      setSelectedCategories([...selectedCategories, category.id]);
                    } else {
                      setSelectedCategories(selectedCategories.filter((id) => id !== category.id));
                    }
                  }}
                />
                <span>{category.categoryName}</span>
              </label>
            ))}
          </div>
          <button onClick={handleUpdateCategories}>카테고리 업데이트</button>
        </div>
      )}

      {activeTab === 'password' && (
        <div className="tab-content">
          <h2>비밀번호 변경</h2>
          <div className="form-group">
            <label>현재 비밀번호: </label>
            <input
              type="password"
              value={currentPassword}
              onChange={(e) => setCurrentPassword(e.target.value)}
              placeholder="현재 비밀번호"
            />
            <button onClick={handleCheckPassword} style={{ marginLeft: '10px' }}>
              확인
            </button>
          </div>
          <div className="form-group">
            <label>새 비밀번호: </label>
            <input
              type="password"
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
              placeholder="새 비밀번호"
            />
          </div>
          <div className="form-group">
            <label>새 비밀번호 확인: </label>
            <input
              type="password"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              placeholder="새 비밀번호 확인"
            />
          </div>
          <button onClick={handleUpdatePassword}>비밀번호 변경</button>
        </div>
      )}

      {activeTab === 'address' && (
        <div className="tab-content">
          <h2>주소 관리</h2>
          <button
            onClick={() => {
              setAddressForm({
                addressId: null,
                userId,
                recipient: '',
                postcode: '',
                address: '',
                detailAddress: '',
                isDefault: false,
                recipientPhone: '',
              });
              setShowAddressForm(true);
            }}
            style={{ marginBottom: '20px' }}
          >
            주소 추가
          </button>

          {showAddressForm && (
            <div className="address-form">
              <h3>{addressForm.addressId ? '주소 수정' : '주소 추가'}</h3>
              <div className="form-group">
                <label>받는 사람: </label>
                <input
                  type="text"
                  value={addressForm.recipient}
                  onChange={(e) => setAddressForm({ ...addressForm, recipient: e.target.value })}
                  placeholder="받는 사람"
                />
              </div>
              <div className="form-group">
                <label>우편번호: </label>
                <input
                  type="text"
                  value={addressForm.postcode}
                  onChange={(e) => setAddressForm({ ...addressForm, postcode: e.target.value })}
                  placeholder="우편번호"
                />
              </div>
              <div className="form-group">
                <label>주소: </label>
                <input
                  type="text"
                  value={addressForm.address}
                  onChange={(e) => setAddressForm({ ...addressForm, address: e.target.value })}
                  placeholder="주소"
                />
              </div>
              <div className="form-group">
                <label>상세주소: </label>
                <input
                  type="text"
                  value={addressForm.detailAddress}
                  onChange={(e) =>
                    setAddressForm({ ...addressForm, detailAddress: e.target.value })
                  }
                  placeholder="상세주소"
                />
              </div>
              <div className="form-group">
                <label>받는 사람 전화번호: </label>
                <input
                  type="text"
                  value={addressForm.recipientPhone}
                  onChange={(e) =>
                    setAddressForm({ ...addressForm, recipientPhone: e.target.value })
                  }
                  placeholder="전화번호"
                />
              </div>
              <div className="form-group">
                <label>
                  <input
                    type="checkbox"
                    checked={addressForm.isDefault}
                    onChange={(e) =>
                      setAddressForm({ ...addressForm, isDefault: e.target.checked })
                    }
                  />
                  기본 주소로 설정
                </label>
              </div>
              <div>
                <button onClick={handleSaveAddress}>저장</button>
                <button
                  onClick={() => setShowAddressForm(false)}
                  style={{ marginLeft: '10px' }}
                >
                  취소
                </button>
              </div>
            </div>
          )}

          <div className="address-list">
            {addressList.length === 0 ? (
              <div>등록된 주소가 없습니다.</div>
            ) : (
              addressList.map((address) => (
                <div key={address.addressId} className="address-item">
                  {address.isDefault && <span className="default-badge">기본</span>}
                  <p>
                    <strong>받는 사람:</strong> {address.recipient} ({address.recipientPhone})
                  </p>
                  <p>
                    <strong>주소:</strong> [{address.postcode}] {address.address}{' '}
                    {address.detailAddress}
                  </p>
                  <div>
                    <button
                      onClick={() => {
                        setAddressForm(address);
                        setShowAddressForm(true);
                      }}
                    >
                      수정
                    </button>
                    <button
                      onClick={() => handleDeleteAddress(address.addressId)}
                      className="delete-btn"
                      style={{ marginLeft: '10px' }}
                    >
                      삭제
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
}

export default UserProfilePage;




