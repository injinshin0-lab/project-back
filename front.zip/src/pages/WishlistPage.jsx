import { useState, useEffect } from 'react';
import { getWishList, toggleWish } from '../api/productApi';
import './WishlistPage.css';

function WishlistPage({ user }) {
  const [wishList, setWishList] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [userId, setUserId] = useState(user?.id || null);

  const fetchWishList = async () => {
    setLoading(true);
    setError(null);
    try {
      const wishData = await getWishList(userId);
      setWishList(wishData || []);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (user?.id) {
      setUserId(user.id);
    }
  }, [user]);

  useEffect(() => {
    if (userId) {
      fetchWishList();
    }
  }, [userId]);

  const handleToggleWish = async (productId) => {
    try {
      await toggleWish(userId, productId);
      alert('찜하기 상태가 변경되었습니다.');
      fetchWishList();
    } catch (err) {
      alert('찜하기 실패: ' + err.message);
    }
  };

  return (
    <div className="wishlist-page">
      <h1>찜하기</h1>

      {error && <div className="error-message">{error}</div>}

      {loading ? (
        <div>로딩 중...</div>
      ) : (
        <>
          {wishList.length === 0 ? (
            <div className="empty-wishlist">찜한 상품이 없습니다.</div>
          ) : (
            <div className="wishlist-grid">
              {wishList.map((product) => (
                <div key={product.productId} className="wishlist-item">
                  {product.imageUrl && (
                    <img src={product.imageUrl} alt={product.productName} />
                  )}
                  <h3>{product.productName}</h3>
                  <p className="price">{product.price?.toLocaleString()}원</p>
                  {product.category && (
                    <p className="category">{product.category.categoryName}</p>
                  )}
                  <button
                    onClick={() => handleToggleWish(product.productId)}
                    className="remove-btn"
                  >
                    찜하기 해제
                  </button>
                </div>
              ))}
            </div>
          )}
        </>
      )}
    </div>
  );
}

export default WishlistPage;




