import { useState, useEffect } from 'react';
import { getUserList, getUser } from '../api/userManagementApi';
import './UserManagementPage.css';

function UserManagementPage() {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [page, setPage] = useState(1);
  const [totalPage, setTotalPage] = useState(1);
  const [selectedUser, setSelectedUser] = useState(null);
  
  const [search, setSearch] = useState({
    startDate: '',
    endDate: '',
    keywordType: '',
    keyword: '',
  });

  const fetchUserList = async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await getUserList({
        ...search,
        page,
        size: 10,
      });
      setUsers(response.list || []);
      setTotalPage(response.totalPage || 1);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUserList();
  }, [page]);

  const handleViewUser = async (id) => {
    try {
      const user = await getUser(id);
      setSelectedUser(user);
    } catch (err) {
      setError(err.message);
    }
  };

  const handleSearch = () => {
    setPage(1);
    fetchUserList();
  };

  return (
    <div className="user-management-page">
      <h1>회원 관리</h1>
      {error && <div className="error-message">{error}</div>}

      <div className="search-section">
        <div className="search-row">
          <div className="search-item">
            <label>시작일:</label>
            <input
              type="date"
              value={search.startDate}
              onChange={(e) => setSearch({ ...search, startDate: e.target.value })}
            />
          </div>
          <div className="search-item">
            <label>종료일:</label>
            <input
              type="date"
              value={search.endDate}
              onChange={(e) => setSearch({ ...search, endDate: e.target.value })}
            />
          </div>
        </div>
        <div className="search-row">
          <div className="search-item">
            <label>검색 조건:</label>
            <select
              value={search.keywordType}
              onChange={(e) => setSearch({ ...search, keywordType: e.target.value })}
            >
              <option value="">전체</option>
              <option value="loginId">아이디</option>
              <option value="name">이름</option>
              <option value="email">이메일</option>
            </select>
          </div>
          <div className="search-item">
            <label>검색어:</label>
            <input
              type="text"
              value={search.keyword}
              onChange={(e) => setSearch({ ...search, keyword: e.target.value })}
              placeholder="검색어 입력"
            />
          </div>
          <button onClick={handleSearch} className="btn-primary">검색</button>
        </div>
      </div>

      {loading ? (
        <div>로딩 중...</div>
      ) : (
        <div>
          {users.length === 0 ? (
            <div className="empty-message">조회된 회원이 없습니다.</div>
          ) : (
            <div className="user-list">
              <table>
                <thead>
                  <tr>
                    <th>ID</th>
                    <th>아이디</th>
                    <th>이름</th>
                    <th>이메일</th>
                    <th>전화번호</th>
                    <th>가입일</th>
                    <th>최종 로그인</th>
                    <th>작업</th>
                  </tr>
                </thead>
                <tbody>
                  {users.map((user) => (
                    <tr key={user.id}>
                      <td>{user.id}</td>
                      <td>{user.loginId}</td>
                      <td>{user.userName}</td>
                      <td>{user.email}</td>
                      <td>{user.phone}</td>
                      <td>{user.createdAt}</td>
                      <td>{user.lastLoginAt || '-'}</td>
                      <td>
                        <button
                          className="btn-link"
                          onClick={() => handleViewUser(user.id)}
                        >
                          상세보기
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
          <div className="pagination">
            <button disabled={page === 1} onClick={() => setPage(page - 1)}>
              이전
            </button>
            <span>
              {page} / {totalPage}
            </span>
            <button disabled={page >= totalPage} onClick={() => setPage(page + 1)}>
              다음
            </button>
          </div>
        </div>
      )}

      {selectedUser && (
        <div className="modal">
          <div className="modal-content">
            <span className="close" onClick={() => setSelectedUser(null)}>
              &times;
            </span>
            <h2>회원 상세 정보</h2>
            <div className="user-detail">
              <p><strong>ID:</strong> {selectedUser.id}</p>
              <p><strong>아이디:</strong> {selectedUser.loginId}</p>
              <p><strong>이름:</strong> {selectedUser.userName}</p>
              <p><strong>이메일:</strong> {selectedUser.email}</p>
              <p><strong>전화번호:</strong> {selectedUser.phone}</p>
              <p><strong>가입일:</strong> {selectedUser.createdAt}</p>
              <p><strong>최종 로그인:</strong> {selectedUser.lastLoginAt || '-'}</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default UserManagementPage;












