import { useState, useEffect } from 'react';
import {
  login,
  getCategories,
  signUp,
  sendEmailAuthCode,
  verifyEmailAuthCode,
  findUserId,
  findPassword,
} from '../api/loginApi';
import './LoginPage.css';

function LoginPage({ onLoginSuccess, onBack }) {
  const [activeTab, setActiveTab] = useState('login');
  
  // 로그인
  const [loginData, setLoginData] = useState({
    loginId: '',
    password: '',
    saveId: false,
    autoLogin: false,
  });
  
  // 아이디 찾기
  const [findIdData, setFindIdData] = useState({
    name: '',
    email: '',
  });
  const [findIdEmailCode, setFindIdEmailCode] = useState('');
  const [findIdEmailVerified, setFindIdEmailVerified] = useState(false);
  
  // 비밀번호 찾기
  const [findPasswordData, setFindPasswordData] = useState({
    loginId: '',
    email: '',
  });
  const [findPasswordEmailCode, setFindPasswordEmailCode] = useState('');
  const [findPasswordEmailVerified, setFindPasswordEmailVerified] = useState(false);
  
  // 회원가입
  const [signUpData, setSignUpData] = useState({
    loginId: '',
    password: '',
    name: '',
    email: '',
    phone: '',
    zipcode: '',
    address: '',
    addressDetail: '',
    categoryId: [],
  });
  
  // 카테고리
  const [categories, setCategories] = useState([]);
  
  const [error, setError] = useState(null);

  useEffect(() => {
    if (activeTab === 'signup') {
      fetchCategories();
    }
  }, [activeTab]);

  const fetchCategories = async () => {
    try {
      const data = await getCategories();
      setCategories(data || []);
    } catch (err) {
      setError(err.message);
    }
  };

  const handleLogin = async (e) => {
    e.preventDefault();
    setError(null);
    try {
      const user = await login(loginData);
      // 부모 컴포넌트에 로그인 성공 알림
      if (onLoginSuccess) {
        await onLoginSuccess(loginData);
      } else {
        alert('로그인 성공');
      }
    } catch (err) {
      setError(err.message);
    }
  };

  // 아이디 찾기 - 이메일 인증 코드 발송
  const handleFindIdSendEmailCode = async () => {
    setError(null);
    try {
      await sendEmailAuthCode(findIdData.email);
      alert('인증번호가 발송되었습니다.');
    } catch (err) {
      setError(err.message);
    }
  };

  // 아이디 찾기 - 이메일 인증 코드 확인
  const handleFindIdVerifyEmailCode = async () => {
    setError(null);
    try {
      await verifyEmailAuthCode({
        email: findIdData.email,
        authCode: findIdEmailCode,
      });
      setFindIdEmailVerified(true);
      alert('이메일 인증 성공');
    } catch (err) {
      setError(err.message);
    }
  };

  // 아이디 찾기
  const handleFindUserId = async (e) => {
    e.preventDefault();
    setError(null);
    if (!findIdEmailVerified) {
      setError('이메일 인증을 먼저 완료해주세요.');
      return;
    }
    try {
      await findUserId(findIdData);
      alert('아이디를 이메일로 전송했습니다. 이메일을 확인해주세요.');
      setFindIdData({ name: '', email: '' });
      setFindIdEmailCode('');
      setFindIdEmailVerified(false);
      setActiveTab('login');
    } catch (err) {
      setError(err.message);
    }
  };

  // 비밀번호 찾기 - 이메일 인증 코드 발송
  const handleFindPasswordSendEmailCode = async () => {
    setError(null);
    try {
      await sendEmailAuthCode(findPasswordData.email);
      alert('인증번호가 발송되었습니다.');
    } catch (err) {
      setError(err.message);
    }
  };

  // 비밀번호 찾기 - 이메일 인증 코드 확인
  const handleFindPasswordVerifyEmailCode = async () => {
    setError(null);
    try {
      await verifyEmailAuthCode({
        email: findPasswordData.email,
        authCode: findPasswordEmailCode,
      });
      setFindPasswordEmailVerified(true);
      alert('이메일 인증 성공');
    } catch (err) {
      setError(err.message);
    }
  };

  // 비밀번호 찾기
  const handleFindPassword = async (e) => {
    e.preventDefault();
    setError(null);
    if (!findPasswordEmailVerified) {
      setError('이메일 인증을 먼저 완료해주세요.');
      return;
    }
    try {
      await findPassword(findPasswordData);
      alert('임시 비밀번호를 이메일로 전송했습니다. 이메일을 확인해주세요.');
      setFindPasswordData({ loginId: '', email: '' });
      setFindPasswordEmailCode('');
      setFindPasswordEmailVerified(false);
      setActiveTab('login');
    } catch (err) {
      setError(err.message);
    }
  };

  const handleSignUp = async (e) => {
    e.preventDefault();
    setError(null);
    try {
      // 백엔드 DTO에 맞게 필드명 변환
      const signUpPayload = {
        loginId: signUpData.loginId,
        password: signUpData.password,
        name: signUpData.name,
        email: signUpData.email,
        phone: signUpData.phone,
        zipcode: signUpData.zipcode,
        address: signUpData.address,
        addressDetail: signUpData.addressDetail,
        categoryId: signUpData.categoryId,
      };
      await signUp(signUpPayload);
      alert('회원가입 성공');
      setSignUpData({
        loginId: '',
        password: '',
        name: '',
        email: '',
        phone: '',
        zipcode: '',
        address: '',
        addressDetail: '',
        categoryId: [],
      });
      setActiveTab('login');
    } catch (err) {
      setError(err.message);
    }
  };

  const toggleCategory = (categoryId) => {
    setSignUpData((prev) => ({
      ...prev,
      categoryId: prev.categoryId.includes(categoryId)
        ? prev.categoryId.filter((id) => id !== categoryId)
        : [...prev.categoryId, categoryId],
    }));
  };

  return (
    <div className="login-page">
      <div className="login-header">
        <h1>로그인</h1>
        {onBack && (
          <button onClick={onBack} className="back-button">
            뒤로가기
          </button>
        )}
      </div>
      {error && <div className="error-message">{error}</div>}

      <div className="tabs">
        <button
          className={activeTab === 'login' ? 'active' : ''}
          onClick={() => setActiveTab('login')}
        >
          로그인
        </button>
        <button
          className={activeTab === 'find-id' ? 'active' : ''}
          onClick={() => setActiveTab('find-id')}
        >
          아이디 찾기
        </button>
        <button
          className={activeTab === 'find-password' ? 'active' : ''}
          onClick={() => setActiveTab('find-password')}
        >
          비밀번호 찾기
        </button>
        <button
          className={activeTab === 'signup' ? 'active' : ''}
          onClick={() => setActiveTab('signup')}
        >
          회원가입
        </button>
      </div>

      {activeTab === 'login' && (
        <div className="tab-content">
          <h2>로그인</h2>
          <form onSubmit={handleLogin}>
            <div className="form-group">
              <label>아이디:</label>
              <input
                type="text"
                value={loginData.loginId}
                onChange={(e) => setLoginData({ ...loginData, loginId: e.target.value })}
                required
              />
            </div>
            <div className="form-group">
              <label>비밀번호:</label>
              <input
                type="password"
                value={loginData.password}
                onChange={(e) => setLoginData({ ...loginData, password: e.target.value })}
                required
              />
            </div>
            <div className="form-group">
              <label>
                <input
                  type="checkbox"
                  checked={loginData.saveId}
                  onChange={(e) => setLoginData({ ...loginData, saveId: e.target.checked })}
                />
                아이디 저장
              </label>
            </div>
            <div className="form-group">
              <label>
                <input
                  type="checkbox"
                  checked={loginData.autoLogin}
                  onChange={(e) => setLoginData({ ...loginData, autoLogin: e.target.checked })}
                />
                자동 로그인
              </label>
            </div>
            <button type="submit" className="btn-primary">로그인</button>
          </form>
        </div>
      )}

      {activeTab === 'find-id' && (
        <div className="tab-content">
          <h2>아이디 찾기</h2>
          <form onSubmit={handleFindUserId}>
            <div className="form-group">
              <label>이름:</label>
              <input
                type="text"
                value={findIdData.name}
                onChange={(e) => setFindIdData({ ...findIdData, name: e.target.value })}
                required
              />
            </div>
            <div className="form-group">
              <label>이메일:</label>
              <input
                type="email"
                value={findIdData.email}
                onChange={(e) => setFindIdData({ ...findIdData, email: e.target.value })}
                required
              />
              <button type="button" onClick={handleFindIdSendEmailCode} className="btn-secondary">
                인증번호 발송
              </button>
            </div>
            <div className="form-group">
              <label>인증번호:</label>
              <input
                type="text"
                value={findIdEmailCode}
                onChange={(e) => setFindIdEmailCode(e.target.value)}
                placeholder="인증번호 입력"
                required
              />
              <button type="button" onClick={handleFindIdVerifyEmailCode} className="btn-secondary">
                인증 확인
              </button>
            </div>
            {findIdEmailVerified && (
              <div className="success-message">이메일 인증 완료</div>
            )}
            <button type="submit" className="btn-primary" disabled={!findIdEmailVerified}>
              아이디 찾기
            </button>
          </form>
        </div>
      )}

      {activeTab === 'find-password' && (
        <div className="tab-content">
          <h2>비밀번호 찾기</h2>
          <form onSubmit={handleFindPassword}>
            <div className="form-group">
              <label>아이디:</label>
              <input
                type="text"
                value={findPasswordData.loginId}
                onChange={(e) => setFindPasswordData({ ...findPasswordData, loginId: e.target.value })}
                required
              />
            </div>
            <div className="form-group">
              <label>이메일:</label>
              <input
                type="email"
                value={findPasswordData.email}
                onChange={(e) => setFindPasswordData({ ...findPasswordData, email: e.target.value })}
                required
              />
              <button type="button" onClick={handleFindPasswordSendEmailCode} className="btn-secondary">
                인증번호 발송
              </button>
            </div>
            <div className="form-group">
              <label>인증번호:</label>
              <input
                type="text"
                value={findPasswordEmailCode}
                onChange={(e) => setFindPasswordEmailCode(e.target.value)}
                placeholder="인증번호 입력"
                required
              />
              <button type="button" onClick={handleFindPasswordVerifyEmailCode} className="btn-secondary">
                인증 확인
              </button>
            </div>
            {findPasswordEmailVerified && (
              <div className="success-message">이메일 인증 완료</div>
            )}
            <button type="submit" className="btn-primary" disabled={!findPasswordEmailVerified}>
              비밀번호 찾기
            </button>
          </form>
        </div>
      )}

      {activeTab === 'signup' && (
        <div className="tab-content">
          <h2>회원가입</h2>
          <form onSubmit={handleSignUp}>
            <div className="form-group">
              <label>아이디:</label>
              <input
                type="text"
                value={signUpData.loginId}
                onChange={(e) => setSignUpData({ ...signUpData, loginId: e.target.value })}
                required
              />
            </div>
            <div className="form-group">
              <label>비밀번호:</label>
              <input
                type="password"
                value={signUpData.password}
                onChange={(e) => setSignUpData({ ...signUpData, password: e.target.value })}
                required
              />
            </div>
            <div className="form-group">
              <label>이름:</label>
              <input
                type="text"
                value={signUpData.name}
                onChange={(e) => setSignUpData({ ...signUpData, name: e.target.value })}
                required
              />
            </div>
            <div className="form-group">
              <label>이메일:</label>
              <input
                type="email"
                value={signUpData.email}
                onChange={(e) => setSignUpData({ ...signUpData, email: e.target.value })}
                required
              />
            </div>
            <div className="form-group">
              <label>전화번호:</label>
              <input
                type="text"
                value={signUpData.phone}
                onChange={(e) => setSignUpData({ ...signUpData, phone: e.target.value })}
                required
              />
            </div>
            <div className="form-group">
              <label>우편번호:</label>
              <input
                type="text"
                value={signUpData.zipcode}
                onChange={(e) => setSignUpData({ ...signUpData, zipcode: e.target.value })}
                placeholder="우편번호"
                required
              />
            </div>
            <div className="form-group">
              <label>주소:</label>
              <input
                type="text"
                value={signUpData.address}
                onChange={(e) => setSignUpData({ ...signUpData, address: e.target.value })}
                placeholder="기본 주소"
                required
              />
            </div>
            <div className="form-group">
              <label>상세주소:</label>
              <input
                type="text"
                value={signUpData.addressDetail}
                onChange={(e) => setSignUpData({ ...signUpData, addressDetail: e.target.value })}
                placeholder="상세 주소"
                required
              />
            </div>
            <div className="form-group">
              <label>관심 카테고리:</label>
              <div className="category-list">
                {categories.map((category) => (
                  <label key={category.id} className="category-item">
                    <input
                      type="checkbox"
                      checked={signUpData.categoryId.includes(category.id)}
                      onChange={() => toggleCategory(category.id)}
                    />
                    {category.categoryName}
                  </label>
                ))}
              </div>
            </div>
            <button type="submit" className="btn-primary">회원가입</button>
          </form>
        </div>
      )}
    </div>
  );
}

export default LoginPage;
