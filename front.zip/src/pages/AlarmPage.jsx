import { useState, useEffect } from 'react';
import { getAlarmList } from '../api/alarmApi';
import './AlarmPage.css';

function AlarmPage({ user }) {
  const [userId, setUserId] = useState(user?.id || null);
  const [alarms, setAlarms] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (user?.id) {
      setUserId(user.id);
    }
  }, [user]);

  useEffect(() => {
    if (userId) {
      fetchAlarmList();
    }
  }, [userId]);

  const fetchAlarmList = async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await getAlarmList(userId);
      setAlarms(data || []);
    } catch (err) {
      setError(err.message);
      console.error('알림 목록 로드 실패:', err);
    } finally {
      setLoading(false);
    }
  };

  const getTypeLabel = (type) => {
    switch (type) {
      case '문의완료':
        return '문의 답변';
      case '대기중':
        return '배송 대기';
      case '배송중':
        return '배송 중';
      case '배송완료':
        return '배송 완료';
      default:
        return type;
    }
  };

  const getTypeClass = (type) => {
    switch (type) {
      case '문의완료':
        return 'alarm-type-answer';
      case '대기중':
        return 'alarm-type-waiting';
      case '배송중':
        return 'alarm-type-shipping';
      case '배송완료':
        return 'alarm-type-completed';
      default:
        return '';
    }
  };

  return (
    <div className="alarm-page">
      <h1>알림</h1>


      {loading && <div className="loading">로딩 중...</div>}
      {error && <div className="error">에러: {error}</div>}

      {!loading && !error && (
        <div className="alarm-list">
          {alarms.length === 0 ? (
            <div className="empty-message">알림이 없습니다.</div>
          ) : (
            alarms.map((alarm) => (
              <div key={alarm.inquiryAlarmId || alarm.deliveryAlarmId} className={`alarm-item ${getTypeClass(alarm.type)}`}>
                <div className="alarm-header">
                  <span className="alarm-type">{getTypeLabel(alarm.type)}</span>
                  {alarm.createdAt && (
                    <span className="alarm-date">{alarm.createdAt}</span>
                  )}
                </div>
                <div className="alarm-content">{alarm.content}</div>
                {alarm.title && alarm.title !== alarm.content && (
                  <div className="alarm-title">{alarm.title}</div>
                )}
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
}

export default AlarmPage;
