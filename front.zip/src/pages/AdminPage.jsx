import { useState, useEffect, Fragment } from 'react';
import {
  getDashboard,
  getUserList,
  getUser,
  getOrderList,
  updateOrderStatus,
  getQuestionList,
  getQuestion,
  insertAnswer,
  getCategoryList,
  createCategory,
  updateCategory,
  deleteCategory,
} from '../api/adminApi';
import {
  getAdminProductList,
  getAdminProduct,
  createProduct,
  updateProduct,
  deleteProduct,
  getReviewsByProduct,
  deleteReview,
} from '../api/adminProductApi';
import AdminFaqPage from './AdminFaqPage';
import './AdminPage.css';

function AdminPage({ onLogout }) {
  const [activeTab, setActiveTab] = useState('dashboard');

  // 대시보드
  const [dashboard, setDashboard] = useState(null);

  // 사용자 관리
  const [users, setUsers] = useState([]);
  const [userPage, setUserPage] = useState(1);
  const [userTotalPage, setUserTotalPage] = useState(1);
  const [userSearch, setUserSearch] = useState({
    startDate: '',
    endDate: '',
    keywordType: '',
    keyword: '',
  });
  const [selectedUser, setSelectedUser] = useState(null);

  // 주문 관리
  const [orders, setOrders] = useState([]);
  const [orderPage, setOrderPage] = useState(1);
  const [orderTotalPage, setOrderTotalPage] = useState(1);
  const [orderSearch, setOrderSearch] = useState({
    userId: null,
    startDate: '',
    endDate: '',
  });
  const [selectedOrder, setSelectedOrder] = useState(null);

  // 질문 관리
  const [questions, setQuestions] = useState([]);
  const [questionPage, setQuestionPage] = useState(1);
  const [questionTotalPage, setQuestionTotalPage] = useState(1);
  const [questionSearch, setQuestionSearch] = useState({
    startDate: '',
    endDate: '',
    questionStatus: '',
    type: '',
    keywordType: '',
    keyword: '',
  });
  const [selectedQuestion, setSelectedQuestion] = useState(null);
  const [showAnswerForm, setShowAnswerForm] = useState(false);
  const [answerContent, setAnswerContent] = useState('');

  // 카테고리 관리
  const [categories, setCategories] = useState([]);
  const [expandedCategories, setExpandedCategories] = useState(new Set());
  const [showCategoryForm, setShowCategoryForm] = useState(false);
  const [categoryForm, setCategoryForm] = useState({
    id: null,
    categoryName: '',
    parentId: null,
    depth: 1,
  });
  const [categoryFormMode, setCategoryFormMode] = useState('create');

  // 상품 관리
  const [products, setProducts] = useState([]);
  const [productPage, setProductPage] = useState(1);
  const [productTotalPage, setProductTotalPage] = useState(1);
  const [productSearch, setProductSearch] = useState({
    keyword: '',
    categoryId: null,
  });
  const [showProductForm, setShowProductForm] = useState(false);
  const [productFormData, setProductFormData] = useState({
    productId: null,
    productName: '',
    categoryId: null,
    originName: '',
    content: '',
    price: '',
    imageFile: null,
    imageUrl: '',
  });
  const [productFormMode, setProductFormMode] = useState('create');
  const [productPreview, setProductPreview] = useState(null);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [showProductDetail, setShowProductDetail] = useState(false);
  const [productReviews, setProductReviews] = useState([]);
  const [reviewsLoading, setReviewsLoading] = useState(false);

  // 이미지 URL 보정 함수 (상대경로면 백엔드 도메인 붙이기)
  const resolveImageUrl = (url) => {
    if (!url) return '';
    return url.startsWith('http') ? url : `http://localhost:8080${url}`;
  };

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  // 대시보드 데이터 로드
  const fetchDashboard = async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await getDashboard();
      setDashboard(data);
    } catch (err) {
      setError(err.message);
      console.error('대시보드 로드 실패:', err);
    } finally {
      setLoading(false);
    }
  };

  // 사용자 목록 로드
  const fetchUsers = async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await getUserList({
        ...userSearch,
        page: userPage,
        size: 10,
      });
      setUsers(response.list || []);
      setUserTotalPage(response.totalPage || 1);
      setUserPage(response.currentPage || 1);
    } catch (err) {
      setError(err.message);
      console.error('사용자 목록 로드 실패:', err);
    } finally {
      setLoading(false);
    }
  };

  // 주문 목록 로드
  const fetchOrders = async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await getOrderList({
        ...orderSearch,
        page: orderPage,
        size: 10,
      });
      setOrders(response.list || []);
      setOrderTotalPage(response.totalPage || 1);
      setOrderPage(response.currentPage || 1);
    } catch (err) {
      setError(err.message);
      console.error('주문 목록 로드 실패:', err);
    } finally {
      setLoading(false);
    }
  };

  // 질문 목록 로드
  const fetchQuestions = async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await getQuestionList({
        ...questionSearch,
        page: questionPage,
        size: 10,
      });
      setQuestions(response.list || []);
      setQuestionTotalPage(response.totalPage || 1);
      setQuestionPage(response.currentPage || 1);
    } catch (err) {
      setError(err.message);
      console.error('질문 목록 로드 실패:', err);
    } finally {
      setLoading(false);
    }
  };

  // 카테고리 목록 로드
  const fetchCategories = async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await getCategoryList();
      setCategories(data || []);
    } catch (err) {
      setError(err.message);
      console.error('카테고리 목록 로드 실패:', err);
    } finally {
      setLoading(false);
    }
  };

  // 질문 상세 조회
  const handleViewQuestion = async (id) => {
    try {
      const question = await getQuestion(id);
      setSelectedQuestion(question);
      setShowAnswerForm(false);
      setAnswerContent('');
    } catch (err) {
      setError(err.message);
      alert('질문 조회에 실패했습니다: ' + err.message);
    }
  };

  // 답변 등록
  const handleSubmitAnswer = async () => {
    if (!answerContent.trim()) {
      alert('답변 내용을 입력해주세요.');
      return;
    }
    try {
      await insertAnswer(selectedQuestion.id, answerContent);
      alert('답변이 등록되었습니다.');
      setShowAnswerForm(false);
      setAnswerContent('');
      fetchQuestions();
      if (selectedQuestion) {
        handleViewQuestion(selectedQuestion.id);
      }
    } catch (err) {
      setError(err.message);
      alert('답변 등록에 실패했습니다: ' + err.message);
    }
  };

  // 카테고리 등록/수정
  const handleSubmitCategory = async (e) => {
    e.preventDefault();
    try {
      if (categoryFormMode === 'create') {
        await createCategory(categoryForm);
        alert('카테고리가 등록되었습니다.');
      } else {
        await updateCategory(categoryForm);
        alert('카테고리가 수정되었습니다.');
      }
      setShowCategoryForm(false);
      setCategoryForm({ id: null, categoryName: '', parentId: null, depth: 1 });
      fetchCategories();
    } catch (err) {
      setError(err.message);
      alert(`${categoryFormMode === 'create' ? '등록' : '수정'}에 실패했습니다: ` + err.message);
    }
  };

  // 카테고리 수정 모드
  const handleEditCategory = (category) => {
    setCategoryForm({
      id: category.id,
      categoryName: category.categoryName,
      parentId: category.parentId,
      depth: category.depth,
    });
    setCategoryFormMode('edit');
    setShowCategoryForm(true);
  };

  // 카테고리 삭제
  const handleDeleteCategory = async (id) => {
    if (!window.confirm('정말 삭제하시겠습니까?')) {
      return;
    }
    try {
      await deleteCategory(id);
      alert('카테고리가 삭제되었습니다.');
      fetchCategories();
    } catch (err) {
      setError(err.message);
      alert('카테고리 삭제에 실패했습니다: ' + err.message);
    }
  };

  // 카테고리 트리 토글
  const toggleCategory = (categoryId) => {
    const newExpanded = new Set(expandedCategories);
    if (newExpanded.has(categoryId)) {
      newExpanded.delete(categoryId);
    } else {
      newExpanded.add(categoryId);
    }
    setExpandedCategories(newExpanded);
  };

  // 카테고리를 트리 구조로 변환
  const buildCategoryTree = (categories) => {
    const categoryMap = new Map();
    const rootCategories = [];

    // 모든 카테고리를 맵에 저장
    categories.forEach(cat => {
      categoryMap.set(cat.id, { ...cat, children: [] });
    });

    // 부모-자식 관계 구성
    categories.forEach(cat => {
      if (cat.parentId === null || cat.parentId === undefined) {
        rootCategories.push(categoryMap.get(cat.id));
      } else {
        const parent = categoryMap.get(cat.parentId);
        if (parent) {
          parent.children.push(categoryMap.get(cat.id));
        }
      }
    });

    return rootCategories;
  };

  // 트리 노드 렌더링 (재귀)
  const renderCategoryNode = (category, level = 0) => {
    const hasChildren = category.children && category.children.length > 0;
    const isExpanded = expandedCategories.has(category.id);
    const indent = level * 30;

    return (
      <Fragment key={category.id}>
        <tr className="category-tree-node">
          <td>{category.id}</td>
          <td style={{ paddingLeft: `${indent + 10}px` }}>
            {hasChildren && (
              <button
                onClick={() => toggleCategory(category.id)}
                className="category-tree-toggle"
                title={isExpanded ? '접기' : '펼치기'}
              >
                {isExpanded ? '▼' : '▶'}
              </button>
            )}
            {!hasChildren && <span className="category-tree-indent" style={{ marginLeft: '20px' }} />}
            {category.categoryName}
          </td>
          <td>{category.parentId || '-'}</td>
          <td>{category.depth}</td>
          <td>
            <button onClick={() => handleEditCategory(category)}>수정</button>
            <button onClick={() => handleDeleteCategory(category.id)}>삭제</button>
          </td>
        </tr>
        {hasChildren && isExpanded && category.children.map(child => renderCategoryNode(child, level + 1))}
      </Fragment>
    );
  };

  // 상품 목록 조회
  const fetchProducts = async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await getAdminProductList({
        page: productPage,
        size: 10,
        keyword: productSearch.keyword || undefined,
        categoryId: productSearch.categoryId || undefined,
      });
      setProducts(response.list || []);
      setProductTotalPage(response.totalPage || 1);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  // 상품 등록/수정 폼 열기
  const handleOpenProductForm = (product = null) => {
    if (product) {
      setProductFormMode('edit');
      setProductFormData({
        productId: product.productId,
        productName: product.productName || '',
        categoryId: product.category?.id || null,
        originName: product.originName || '',
        content: product.content || '',
        price: product.price || '',
        imageFile: null,
        imageUrl: product.imageUrl || '',
      });
      setProductPreview(product.imageUrl || null);
    } else {
      setProductFormMode('create');
      setProductFormData({
        productId: null,
        productName: '',
        categoryId: null,
        originName: '',
        content: '',
        price: '',
        imageFile: null,
        imageUrl: '',
      });
      setProductPreview(null);
    }
    setShowProductForm(true);
  };

  // 상품 이미지 파일 선택 핸들러
  const handleImageFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setProductFormData({ ...productFormData, imageFile: file, imageUrl: '' });
      // 미리보기 생성
      const reader = new FileReader();
      reader.onloadend = () => {
        setProductPreview(reader.result);
      };
      reader.readAsDataURL(file);
    }
  };

  // 상품 등록/수정
  const handleSubmitProduct = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      const selectedCategory = categories.find(cat => cat.id === productFormData.categoryId);
      
      // FormData 생성 (파일 업로드용)
      const formData = new FormData();
      if (productFormMode === 'edit' && productFormData.productId) {
        formData.append('productId', productFormData.productId);
      }
      formData.append('productName', productFormData.productName);
      if (selectedCategory) {
        formData.append('category.categoryId', selectedCategory.id);
        formData.append('category.categoryName', selectedCategory.categoryName);
        formData.append('category.parentId', selectedCategory.parentId || '');
        formData.append('category.level', selectedCategory.depth || '');
      }
      formData.append('originName', productFormData.originName || '');
      formData.append('content', productFormData.content || '');
      formData.append('price', productFormData.price);
      if (productFormData.imageFile) {
        formData.append('imageFile', productFormData.imageFile);
      } else if (productFormData.imageUrl) {
        formData.append('imageUrl', productFormData.imageUrl);
      }

      if (productFormMode === 'create') {
        await createProduct(formData);
        alert('상품이 등록되었습니다.');
      } else {
        await updateProduct(formData);
        alert('상품이 수정되었습니다.');
      }
      setShowProductForm(false);
      fetchProducts();
    } catch (err) {
      setError(err.message);
      alert(`${productFormMode === 'create' ? '등록' : '수정'}에 실패했습니다: ` + err.message);
    } finally {
      setLoading(false);
    }
  };

  // 상품 삭제
  const handleDeleteProduct = async (productId) => {
    if (!confirm('정말 삭제하시겠습니까?')) return;
    try {
      await deleteProduct(productId);
      alert('상품이 삭제되었습니다.');
      setShowProductDetail(false);
      setSelectedProduct(null);
      fetchProducts();
    } catch (err) {
      setError(err.message);
      alert('삭제에 실패했습니다: ' + err.message);
    }
  };

  // 상품 상세보기
  const handleViewProduct = async (productId) => {
    try {
      const product = await getAdminProduct(productId);
      setSelectedProduct(product);
      setShowProductDetail(true);
      // 리뷰 목록 가져오기
      fetchProductReviews(productId);
    } catch (err) {
      setError(err.message);
      alert('상품 조회에 실패했습니다: ' + err.message);
    }
  };

  // 상품 리뷰 목록 가져오기
  const fetchProductReviews = async (productId) => {
    setReviewsLoading(true);
    try {
      const reviews = await getReviewsByProduct(productId);
      setProductReviews(reviews || []);
    } catch (err) {
      console.error('리뷰 목록 조회 실패:', err);
      setProductReviews([]);
    } finally {
      setReviewsLoading(false);
    }
  };

  // 리뷰 삭제
  const handleDeleteReview = async (reviewId) => {
    if (!confirm('정말 이 리뷰를 삭제하시겠습니까?')) {
      return;
    }

    try {
      await deleteReview(reviewId);
      alert('리뷰가 삭제되었습니다.');
      // 리뷰 목록 새로고침
      if (selectedProduct) {
        fetchProductReviews(selectedProduct.productId);
      }
    } catch (err) {
      console.error('리뷰 삭제 실패:', err);
      alert('리뷰 삭제에 실패했습니다: ' + err.message);
    }
  };

  // 사용자 상세 조회
  const handleViewUser = async (id) => {
    try {
      const user = await getUser(id);
      setSelectedUser(user);
    } catch (err) {
      setError(err.message);
      alert('사용자 조회에 실패했습니다: ' + err.message);
    }
  };

  // 주문 상세 조회
  const handleViewOrder = (order) => {
    setSelectedOrder(order);
  };

  // 주문 배송상태 변경
  const handleUpdateOrderStatus = async (orderId, newStatus) => {
    if (!confirm(`주문 #${orderId}의 배송상태를 '${newStatus}'로 변경하시겠습니까?`)) {
      return;
    }

    setLoading(true);
    setError(null);
    try {
      await updateOrderStatus(orderId, newStatus);
      alert('배송상태가 변경되었습니다. 주문한 유저에게 알림이 전송되었습니다.');
      // 주문 목록 새로고침
      await fetchOrders();
      // 선택된 주문이 있으면 업데이트
      if (selectedOrder && selectedOrder.id === orderId) {
        const updatedOrder = { ...selectedOrder, status: newStatus };
        setSelectedOrder(updatedOrder);
      }
    } catch (err) {
      setError(err.message);
      alert('배송상태 변경 실패: ' + err.message);
    } finally {
      setLoading(false);
    }
  };

  // 탭 변경 시 데이터 로드
  useEffect(() => {
    if (activeTab === 'dashboard') {
      fetchDashboard();
    } else if (activeTab === 'user') {
      setUserPage(1);
      fetchUsers();
    } else if (activeTab === 'order') {
      setOrderPage(1);
      fetchOrders();
    } else if (activeTab === 'question') {
      setQuestionPage(1);
      fetchQuestions();
    } else if (activeTab === 'category') {
      fetchCategories();
    } else if (activeTab === 'product') {
      fetchProducts();
      fetchCategories();
    }
  }, [activeTab]);

  // 페이지 변경 시 데이터 재로드
  useEffect(() => {
    if (activeTab === 'user') {
      fetchUsers();
    }
  }, [userPage]);

  useEffect(() => {
    if (activeTab === 'order') {
      fetchOrders();
    }
  }, [orderPage]);

  useEffect(() => {
    if (activeTab === 'question') {
      fetchQuestions();
    }
  }, [questionPage]);

  useEffect(() => {
    if (activeTab === 'product') {
      fetchProducts();
    }
  }, [productPage]);

  return (
    <div className="admin-page">
      <div className="admin-header">
        <h1>관리자 페이지</h1>
        {onLogout && (
          <button
            onClick={onLogout}
            style={{
              padding: '8px 16px',
              marginLeft: 'auto',
              backgroundColor: '#dc3545',
              color: 'white',
              border: 'none',
              borderRadius: '4px',
              cursor: 'pointer',
              fontSize: '14px'
            }}
          >
            로그아웃
          </button>
        )}
      </div>

      <div className="admin-tabs">
        <button
          className={activeTab === 'dashboard' ? 'active' : ''}
          onClick={() => setActiveTab('dashboard')}
        >
          대시보드
        </button>
        <button
          className={activeTab === 'user' ? 'active' : ''}
          onClick={() => setActiveTab('user')}
        >
          사용자 관리
        </button>
        <button
          className={activeTab === 'order' ? 'active' : ''}
          onClick={() => setActiveTab('order')}
        >
          주문 관리
        </button>
        <button
          className={activeTab === 'question' ? 'active' : ''}
          onClick={() => setActiveTab('question')}
        >
          질문 관리
        </button>
        <button
          className={activeTab === 'category' ? 'active' : ''}
          onClick={() => setActiveTab('category')}
        >
          카테고리 관리
        </button>
        <button
          className={activeTab === 'product' ? 'active' : ''}
          onClick={() => setActiveTab('product')}
        >
          상품 관리
        </button>
        <button
          className={activeTab === 'faq' ? 'active' : ''}
          onClick={() => setActiveTab('faq')}
        >
          FAQ 관리
        </button>
      </div>

      {error && <div className="error-message">{error}</div>}

      {loading && <div className="loading">로딩 중...</div>}

      {/* 대시보드 */}
      {activeTab === 'dashboard' && dashboard && (
        <div className="dashboard-content">
          <div className="dashboard-stats">
            <div className="stat-card">
              <h3>총 회원 수</h3>
              <p className="stat-value">{dashboard.totalUserCount?.toLocaleString() || 0}</p>
            </div>
            <div className="stat-card">
              <h3>총 상품 수</h3>
              <p className="stat-value">{dashboard.totalProductCount?.toLocaleString() || 0}</p>
            </div>
            <div className="stat-card">
              <h3>총 주문 수</h3>
              <p className="stat-value">{dashboard.totalOrderCount?.toLocaleString() || 0}</p>
            </div>
            <div className="stat-card">
              <h3>총 매출액</h3>
              <p className="stat-value">{dashboard.totalSalesAmount?.toLocaleString() || 0}원</p>
            </div>
          </div>
        </div>
      )}

      {/* 사용자 관리 */}
      {activeTab === 'user' && !loading && (
        <div className="user-content">
          <div className="search-section">
            <input
              type="date"
              value={userSearch.startDate}
              onChange={(e) => setUserSearch({ ...userSearch, startDate: e.target.value })}
              placeholder="시작일"
            />
            <input
              type="date"
              value={userSearch.endDate}
              onChange={(e) => setUserSearch({ ...userSearch, endDate: e.target.value })}
              placeholder="종료일"
            />
            <select
              value={userSearch.keywordType}
              onChange={(e) => setUserSearch({ ...userSearch, keywordType: e.target.value })}
            >
              <option value="">검색 유형</option>
              <option value="loginId">아이디</option>
              <option value="name">이름</option>
              <option value="email">이메일</option>
            </select>
            <input
              type="text"
              value={userSearch.keyword}
              onChange={(e) => setUserSearch({ ...userSearch, keyword: e.target.value })}
              placeholder="검색어"
              onKeyPress={(e) => e.key === 'Enter' && fetchUsers()}
            />
            <button onClick={fetchUsers}>검색</button>
            <button
              onClick={() => {
                setUserSearch({ startDate: '', endDate: '', keywordType: '', keyword: '' });
                fetchUsers();
              }}
            >
              초기화
            </button>
          </div>
          {users.length === 0 ? (
            <div className="empty-message">등록된 사용자가 없습니다.</div>
          ) : (
            <>
              <table className="data-table">
                <thead>
                  <tr>
                    <th>ID</th>
                    <th>아이디</th>
                    <th>이름</th>
                    <th>이메일</th>
                    <th>전화번호</th>
                    <th>가입일</th>
                    <th>마지막 로그인</th>
                    <th>작업</th>
                  </tr>
                </thead>
                <tbody>
                  {users.map((user) => (
                    <tr key={user.id}>
                      <td>{user.id}</td>
                      <td>{user.loginId}</td>
                      <td>{user.userName}</td>
                      <td>{user.email}</td>
                      <td>{user.phone}</td>
                      <td>{user.createdAt}</td>
                      <td>{user.lastLoginAt || '-'}</td>
                      <td>
                        <button onClick={() => handleViewUser(user.id)}>상세</button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {userTotalPage > 1 && (
                <div className="pagination">
                  <button onClick={() => setUserPage(userPage - 1)} disabled={userPage === 1}>
                    이전
                  </button>
                  <span>{userPage} / {userTotalPage}</span>
                  <button
                    onClick={() => setUserPage(userPage + 1)}
                    disabled={userPage === userTotalPage}
                  >
                    다음
                  </button>
                </div>
              )}
            </>
          )}
          {selectedUser && (
            <div className="modal-overlay" onClick={() => setSelectedUser(null)}>
              <div className="modal-content" onClick={(e) => e.stopPropagation()}>
                <h2>사용자 상세</h2>
                <div className="detail-info">
                  <p><strong>ID:</strong> {selectedUser.id}</p>
                  <p><strong>아이디:</strong> {selectedUser.loginId}</p>
                  <p><strong>이름:</strong> {selectedUser.userName}</p>
                  <p><strong>이메일:</strong> {selectedUser.email}</p>
                  <p><strong>전화번호:</strong> {selectedUser.phone}</p>
                  <p><strong>가입일:</strong> {selectedUser.createdAt}</p>
                  <p><strong>마지막 로그인:</strong> {selectedUser.lastLoginAt || '-'}</p>
                </div>
                <button onClick={() => setSelectedUser(null)}>닫기</button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* 주문 관리 */}
      {activeTab === 'order' && !loading && (
        <div className="order-content">
          <div className="search-section">
            <input
              type="number"
              value={orderSearch.userId || ''}
              onChange={(e) =>
                setOrderSearch({
                  ...orderSearch,
                  userId: e.target.value ? Number(e.target.value) : null,
                })
              }
              placeholder="사용자 ID"
            />
            <input
              type="date"
              value={orderSearch.startDate}
              onChange={(e) => setOrderSearch({ ...orderSearch, startDate: e.target.value })}
            />
            <input
              type="date"
              value={orderSearch.endDate}
              onChange={(e) => setOrderSearch({ ...orderSearch, endDate: e.target.value })}
            />
            <button onClick={fetchOrders}>검색</button>
            <button
              onClick={() => {
                setOrderSearch({ userId: null, startDate: '', endDate: '' });
                fetchOrders();
              }}
            >
              초기화
            </button>
          </div>
          {orders.length === 0 ? (
            <div className="empty-message">등록된 주문이 없습니다.</div>
          ) : (
            <>
              <table className="data-table">
                <thead>
                  <tr>
                    <th>ID</th>
                    <th>아이디</th>
                    <th>수령인</th>
                    <th>전화번호</th>
                    <th>결제방법</th>
                    <th>총액</th>
                    <th>상태</th>
                    <th>주문일</th>
                    <th>작업</th>
                  </tr>
                </thead>
                <tbody>
                  {orders.map((order) => (
                    <tr key={order.id}>
                      <td>{order.id}</td>
                      <td>{order.loginId}</td>
                      <td>{order.recipient}</td>
                      <td>{order.recipientPhone}</td>
                      <td>{order.payType}</td>
                      <td>{order.totalPrice?.toLocaleString()}원</td>
                      <td>
                        <select
                          value={order.status || ''}
                          onChange={(e) => handleUpdateOrderStatus(order.id, e.target.value)}
                          style={{ padding: '4px 8px', fontSize: '14px' }}
                        >
                          <option value="ORDERED">주문완료</option>
                          <option value="PREPARING">준비중</option>
                          <option value="SHIPPING">배송중</option>
                          <option value="DELIVERED">배송완료</option>
                          <option value="CANCELLED">취소</option>
                        </select>
                      </td>
                      <td>{order.createdAt}</td>
                      <td>
                        <button onClick={() => handleViewOrder(order)}>상세</button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {orderTotalPage > 1 && (
                <div className="pagination">
                  <button onClick={() => setOrderPage(orderPage - 1)} disabled={orderPage === 1}>
                    이전
                  </button>
                  <span>{orderPage} / {orderTotalPage}</span>
                  <button
                    onClick={() => setOrderPage(orderPage + 1)}
                    disabled={orderPage === orderTotalPage}
                  >
                    다음
                  </button>
                </div>
              )}
            </>
          )}
          {selectedOrder && (
            <div className="modal-overlay" onClick={() => setSelectedOrder(null)}>
              <div className="modal-content" onClick={(e) => e.stopPropagation()}>
                <h2>주문 상세</h2>
                <div className="detail-info">
                  <p><strong>주문 ID:</strong> {selectedOrder.id}</p>
                  <p><strong>아이디:</strong> {selectedOrder.loginId}</p>
                  <p><strong>수령인:</strong> {selectedOrder.recipient}</p>
                  <p><strong>전화번호:</strong> {selectedOrder.recipientPhone}</p>
                  <p><strong>결제방법:</strong> {selectedOrder.payType}</p>
                  <p><strong>주소:</strong> ({selectedOrder.postcode}) {selectedOrder.address} {selectedOrder.detailAddress}</p>
                  <p><strong>총액:</strong> {selectedOrder.totalPrice?.toLocaleString()}원</p>
                  <p><strong>상태:</strong> 
                    <select
                      value={selectedOrder.status || ''}
                      onChange={(e) => handleUpdateOrderStatus(selectedOrder.id, e.target.value)}
                      style={{ marginLeft: '10px', padding: '4px 8px', fontSize: '14px' }}
                    >
                      <option value="ORDERED">주문완료</option>
                      <option value="PREPARING">준비중</option>
                      <option value="SHIPPING">배송중</option>
                      <option value="DELIVERED">배송완료</option>
                      <option value="CANCELLED">취소</option>
                    </select>
                  </p>
                  <p><strong>주문일:</strong> {selectedOrder.createdAt}</p>
                  {selectedOrder.orderItems && selectedOrder.orderItems.length > 0 && (
                    <div>
                      <strong>주문 상품:</strong>
                      <ul>
                        {selectedOrder.orderItems.map((item, idx) => (
                          <li key={idx}>
                            {item.productName} - {item.quantity}개 - {item.price?.toLocaleString()}원
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
                <button onClick={() => setSelectedOrder(null)}>닫기</button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* 질문 관리 */}
      {activeTab === 'question' && !loading && (
        <div className="question-content">
          <div className="search-section">
            <input
              type="date"
              value={questionSearch.startDate}
              onChange={(e) =>
                setQuestionSearch({ ...questionSearch, startDate: e.target.value })
              }
            />
            <input
              type="date"
              value={questionSearch.endDate}
              onChange={(e) => setQuestionSearch({ ...questionSearch, endDate: e.target.value })}
            />
            <select
              value={questionSearch.questionStatus}
              onChange={(e) =>
                setQuestionSearch({ ...questionSearch, questionStatus: e.target.value })
              }
            >
              <option value="">상태</option>
              <option value="PENDING">대기</option>
              <option value="ANSWERED">답변완료</option>
            </select>
            <select
              value={questionSearch.type}
              onChange={(e) => setQuestionSearch({ ...questionSearch, type: e.target.value })}
            >
              <option value="">유형</option>
              <option value="PRODUCT">상품</option>
              <option value="ORDER">주문</option>
              <option value="ETC">기타</option>
            </select>
            <select
              value={questionSearch.keywordType}
              onChange={(e) =>
                setQuestionSearch({ ...questionSearch, keywordType: e.target.value })
              }
            >
              <option value="">검색 유형</option>
              <option value="title">제목</option>
              <option value="content">내용</option>
            </select>
            <input
              type="text"
              value={questionSearch.keyword}
              onChange={(e) => setQuestionSearch({ ...questionSearch, keyword: e.target.value })}
              placeholder="검색어"
              onKeyPress={(e) => e.key === 'Enter' && fetchQuestions()}
            />
            <button onClick={fetchQuestions}>검색</button>
            <button
              onClick={() => {
                setQuestionSearch({
                  startDate: '',
                  endDate: '',
                  questionStatus: '',
                  type: '',
                  keywordType: '',
                  keyword: '',
                });
                fetchQuestions();
              }}
            >
              초기화
            </button>
          </div>
          {questions.length === 0 ? (
            <div className="empty-message">등록된 질문이 없습니다.</div>
          ) : (
            <>
              <table className="data-table">
                <thead>
                  <tr>
                    <th>ID</th>
                    <th>제목</th>
                    <th>상태</th>
                    <th>유형</th>
                    <th>작성일</th>
                    <th>작업</th>
                  </tr>
                </thead>
                <tbody>
                  {questions.map((question) => (
                    <tr key={question.id}>
                      <td>{question.id}</td>
                      <td>{question.title}</td>
                      <td>{question.questionStatus}</td>
                      <td>{question.type}</td>
                      <td>{question.createdAt}</td>
                      <td>
                        <button onClick={() => handleViewQuestion(question.id)}>상세/답변</button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {questionTotalPage > 1 && (
                <div className="pagination">
                  <button
                    onClick={() => setQuestionPage(questionPage - 1)}
                    disabled={questionPage === 1}
                  >
                    이전
                  </button>
                  <span>{questionPage} / {questionTotalPage}</span>
                  <button
                    onClick={() => setQuestionPage(questionPage + 1)}
                    disabled={questionPage === questionTotalPage}
                  >
                    다음
                  </button>
                </div>
              )}
            </>
          )}
          {selectedQuestion && (
            <div
              className="modal-overlay"
              onClick={() => {
                setSelectedQuestion(null);
                setShowAnswerForm(false);
              }}
            >
              <div className="modal-content" onClick={(e) => e.stopPropagation()}>
                <h2>질문 상세</h2>
                <div className="detail-info">
                  <p><strong>제목:</strong> {selectedQuestion.title}</p>
                  <p><strong>내용:</strong> {selectedQuestion.content}</p>
                  <p><strong>상태:</strong> {selectedQuestion.questionStatus}</p>
                  <p><strong>유형:</strong> {selectedQuestion.type}</p>
                  <p><strong>작성일:</strong> {selectedQuestion.createdAt}</p>
                  {selectedQuestion.questionImages &&
                    selectedQuestion.questionImages.length > 0 && (
                      <div>
                        <strong>이미지:</strong>
                        <div className="image-list">
                          {selectedQuestion.questionImages.map((img) => (
                            <img
                              key={img.id}
                              src={resolveImageUrl(img.imageUrl)}
                              alt="질문 이미지"
                              className="question-image"
                            />
                          ))}
                        </div>
                      </div>
                    )}
                  {selectedQuestion.answer && selectedQuestion.answer.content && (
                    <div className="answer-section">
                      <strong>답변:</strong>
                      <div className="answer-content">{selectedQuestion.answer.content}</div>
                    </div>
                  )}
                </div>
                {!showAnswerForm && selectedQuestion.questionStatus !== 'ANSWERED' && (
                  <button onClick={() => setShowAnswerForm(true)}>답변 작성</button>
                )}
                {showAnswerForm && (
                  <div>
                    <textarea
                      value={answerContent}
                      onChange={(e) => setAnswerContent(e.target.value)}
                      placeholder="답변 내용을 입력하세요"
                      rows="5"
                      className="answer-textarea"
                    />
                    <div className="form-actions">
                      <button onClick={handleSubmitAnswer}>등록</button>
                      <button onClick={() => setShowAnswerForm(false)}>취소</button>
                    </div>
                  </div>
                )}
                <button
                  onClick={() => {
                    setSelectedQuestion(null);
                    setShowAnswerForm(false);
                  }}
                  className="close-btn"
                >
                  닫기
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* 상품 관리 */}
      {activeTab === 'product' && !loading && (
        <div className="product-content">
          <div className="content-header">
            <h2>상품 관리</h2>
            <button
              onClick={() => handleOpenProductForm()}
              className="btn-create"
            >
              상품 등록
            </button>
          </div>

          <div className="search-section">
            <input
              type="text"
              value={productSearch.keyword}
              onChange={(e) => setProductSearch({ ...productSearch, keyword: e.target.value })}
              placeholder="상품명 검색"
              onKeyPress={(e) => e.key === 'Enter' && fetchProducts()}
            />
            <select
              value={productSearch.categoryId || ''}
              onChange={(e) => setProductSearch({ ...productSearch, categoryId: e.target.value ? parseInt(e.target.value) : null })}
            >
              <option value="">전체 카테고리</option>
              {categories.map((cat) => (
                <option key={cat.id} value={cat.id}>
                  {cat.categoryName}
                </option>
              ))}
            </select>
            <button onClick={fetchProducts}>검색</button>
            <button
              onClick={() => {
                setProductSearch({ keyword: '', categoryId: null });
                fetchProducts();
              }}
            >
              초기화
            </button>
          </div>

          {products.length === 0 ? (
            <div className="empty-message">등록된 상품이 없습니다.</div>
          ) : (
            <>
              <table className="data-table">
                <thead>
                  <tr>
                    <th>ID</th>
                    <th>상품명</th>
                    <th>카테고리</th>
                    <th>원산지</th>
                    <th>가격</th>
                    <th>이미지</th>
                    <th>작업</th>
                  </tr>
                </thead>
                <tbody>
                  {products.map((product) => (
                    <tr key={product.productId}>
                      <td>{product.productId}</td>
                      <td>{product.productName}</td>
                      <td>{product.category?.categoryName || '-'}</td>
                      <td>{product.originName || '-'}</td>
                      <td>{product.price?.toLocaleString()}원</td>
                      <td>
                        {product.imageUrl ? (
                          <img 
                            src={product.imageUrl.startsWith('http') ? product.imageUrl : `http://localhost:8080${product.imageUrl}`}
                            alt={product.productName} 
                            style={{ maxWidth: '50px', maxHeight: '50px' }}
                            onError={(e) => {
                              e.target.style.display = 'none';
                            }}
                          />
                        ) : (
                          <span>이미지 없음</span>
                        )}
                      </td>
                      <td>
                        <button onClick={() => handleViewProduct(product.productId)}>상세보기</button>
                        <button onClick={() => handleOpenProductForm(product)} style={{ marginLeft: '10px' }}>수정</button>
                        <button onClick={() => handleDeleteProduct(product.productId)} className="delete-btn" style={{ marginLeft: '10px' }}>
                          삭제
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>

              <div className="pagination">
                <button disabled={productPage === 1} onClick={() => setProductPage(productPage - 1)}>이전</button>
                <span>{productPage} / {productTotalPage}</span>
                <button disabled={productPage >= productTotalPage} onClick={() => setProductPage(productPage + 1)}>다음</button>
              </div>
            </>
          )}

          {/* 상품 상세보기 모달 */}
          {showProductDetail && selectedProduct && (
            <div className="modal-overlay" onClick={() => setShowProductDetail(false)}>
              <div className="modal-content" onClick={(e) => e.stopPropagation()} style={{ maxWidth: '800px', maxHeight: '90vh', overflowY: 'auto' }}>
                <div className="modal-header">
                  <h2>상품 상세보기</h2>
                  <button className="close-btn" onClick={() => setShowProductDetail(false)}>×</button>
                </div>
                <div style={{ padding: '20px' }}>
                  <div style={{ marginBottom: '20px', textAlign: 'center' }}>
                    {selectedProduct.imageUrl ? (
                      <div style={{ 
                        display: 'flex', 
                        justifyContent: 'center', 
                        alignItems: 'center',
                        marginBottom: '20px',
                        minHeight: '200px'
                      }}>
                        <img 
                          src={selectedProduct.imageUrl.startsWith('http') ? selectedProduct.imageUrl : `http://localhost:8080${selectedProduct.imageUrl}`}
                          alt={selectedProduct.productName} 
                          style={{ 
                            maxWidth: '100%', 
                            maxHeight: '500px', 
                            width: 'auto',
                            height: 'auto',
                            objectFit: 'contain'
                          }}
                          onError={(e) => {
                            e.target.style.display = 'none';
                            e.target.nextSibling.style.display = 'block';
                          }}
                        />
                        <div style={{ display: 'none', padding: '100px', backgroundColor: '#f0f0f0' }}>
                          이미지를 불러올 수 없습니다.
                        </div>
                      </div>
                    ) : (
                      <div style={{ padding: '100px', backgroundColor: '#f0f0f0', marginBottom: '20px' }}>
                        이미지 없음
                      </div>
                    )}
                  </div>
                  <div className="form-group">
                    <label><strong>상품 ID:</strong></label>
                    <p>{selectedProduct.productId}</p>
                  </div>
                  <div className="form-group">
                    <label><strong>상품명:</strong></label>
                    <p>{selectedProduct.productName}</p>
                  </div>
                  <div className="form-group">
                    <label><strong>카테고리:</strong></label>
                    <p>{selectedProduct.category?.categoryName || '-'}</p>
                  </div>
                  <div className="form-group">
                    <label><strong>원산지:</strong></label>
                    <p>{selectedProduct.originName || '-'}</p>
                  </div>
                  <div className="form-group">
                    <label><strong>가격:</strong></label>
                    <p>{selectedProduct.price?.toLocaleString()}원</p>
                  </div>
                  <div className="form-group">
                    <label><strong>내용:</strong></label>
                    <p style={{ whiteSpace: 'pre-wrap' }}>{selectedProduct.content || '-'}</p>
                  </div>
                  <div className="form-group">
                    <label><strong>이미지 URL:</strong></label>
                    <p>{selectedProduct.imageUrl || '-'}</p>
                  </div>
                  
                  {/* 리뷰 섹션 */}
                  <div className="form-group" style={{ marginTop: '30px', borderTop: '2px solid #e0e0e0', paddingTop: '20px' }}>
                    <label><strong>리뷰 목록:</strong></label>
                    {reviewsLoading ? (
                      <p>리뷰 로딩 중...</p>
                    ) : productReviews.length === 0 ? (
                      <p style={{ color: '#666', fontStyle: 'italic' }}>등록된 리뷰가 없습니다.</p>
                    ) : (
                      <div style={{ marginTop: '15px' }}>
                        {productReviews.map((review) => (
                          <div
                            key={review.reviewId}
                            style={{
                              padding: '15px',
                              marginBottom: '15px',
                              border: '1px solid #e0e0e0',
                              borderRadius: '8px',
                              backgroundColor: '#f9f9f9'
                            }}
                          >
                            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '10px' }}>
                              <div>
                                <span style={{ fontWeight: 'bold', marginRight: '10px' }}>
                                  {review.loginId || '익명'}
                                </span>
                                <span style={{ color: '#ff9800', fontWeight: 'bold' }}>
                                  ⭐ {review.rating}
                                </span>
                                {review.createdAt && (
                                  <span style={{ color: '#666', fontSize: '12px', marginLeft: '10px' }}>
                                    {review.createdAt}
                                  </span>
                                )}
                              </div>
                              <button
                                onClick={() => handleDeleteReview(review.reviewId)}
                                style={{
                                  padding: '5px 10px',
                                  backgroundColor: '#dc3545',
                                  color: 'white',
                                  border: 'none',
                                  borderRadius: '4px',
                                  cursor: 'pointer',
                                  fontSize: '12px'
                                }}
                              >
                                삭제
                              </button>
                            </div>
                            <div style={{ color: '#333', lineHeight: '1.6', marginBottom: '10px' }}>
                              {review.content}
                            </div>
                            {review.reviewImages && review.reviewImages.length > 0 && (
                              <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap', marginTop: '10px' }}>
                                {review.reviewImages.map((img, idx) => (
                                  <img
                                    key={idx}
                                    src={resolveImageUrl(img.imageUrl)}
                                    alt={`리뷰 이미지 ${idx + 1}`}
                                    style={{
                                      maxWidth: '150px',
                                      maxHeight: '150px',
                                      borderRadius: '4px',
                                      objectFit: 'cover',
                                      border: '1px solid #ddd'
                                    }}
                                  />
                                ))}
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  <div className="form-actions" style={{ marginTop: '20px' }}>
                    <button 
                      onClick={() => {
                        setShowProductDetail(false);
                        handleOpenProductForm(selectedProduct);
                      }}
                      className="btn-primary"
                    >
                      수정
                    </button>
                    <button 
                      onClick={() => {
                        if (confirm('정말 삭제하시겠습니까?')) {
                          handleDeleteProduct(selectedProduct.productId);
                        }
                      }}
                      className="delete-btn"
                      style={{ marginLeft: '10px' }}
                    >
                      삭제
                    </button>
                    <button
                      type="button"
                      className="btn-secondary"
                      onClick={() => setShowProductDetail(false)}
                      style={{ marginLeft: '10px' }}
                    >
                      닫기
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* 상품 등록/수정 폼 모달 */}
          {showProductForm && (
            <div className="modal-overlay" onClick={() => setShowProductForm(false)}>
              <div className="modal-content" onClick={(e) => e.stopPropagation()} style={{ maxWidth: '600px', maxHeight: '90vh', overflowY: 'auto' }}>
                <div className="modal-header">
                  <h2>{productFormMode === 'create' ? '상품 등록' : '상품 수정'}</h2>
                  <button className="close-btn" onClick={() => setShowProductForm(false)}>×</button>
                </div>
                <form onSubmit={handleSubmitProduct}>
                  <div className="form-group">
                    <label>상품명 *</label>
                    <input
                      type="text"
                      value={productFormData.productName}
                      onChange={(e) => setProductFormData({ ...productFormData, productName: e.target.value })}
                      required
                    />
                  </div>
                  <div className="form-group">
                    <label>카테고리 *</label>
                    <select
                      value={productFormData.categoryId || ''}
                      onChange={(e) => setProductFormData({ ...productFormData, categoryId: e.target.value ? parseInt(e.target.value) : null })}
                      required
                    >
                      <option value="">선택하세요</option>
                      {categories.map((cat) => (
                        <option key={cat.id} value={cat.id}>
                          {cat.categoryName}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div className="form-group">
                    <label>원산지</label>
                    <input
                      type="text"
                      value={productFormData.originName}
                      onChange={(e) => setProductFormData({ ...productFormData, originName: e.target.value })}
                    />
                  </div>
                  <div className="form-group">
                    <label>내용</label>
                    <textarea
                      value={productFormData.content}
                      onChange={(e) => setProductFormData({ ...productFormData, content: e.target.value })}
                      rows="5"
                    />
                  </div>
                  <div className="form-group">
                    <label>가격 *</label>
                    <input
                      type="number"
                      value={productFormData.price}
                      onChange={(e) => setProductFormData({ ...productFormData, price: e.target.value })}
                      required
                      min="0"
                    />
                  </div>
                  <div className="form-group">
                    <label>이미지 업로드</label>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleImageFileChange}
                    />
                    {productPreview && (
                      <div style={{ marginTop: '10px' }}>
                        <img src={productPreview} alt="미리보기" style={{ maxWidth: '200px', maxHeight: '200px' }} />
                      </div>
                    )}
                  </div>
                  <div className="form-group">
                    <label>또는 이미지 URL</label>
                    <input
                      type="url"
                      value={productFormData.imageUrl}
                      onChange={(e) => {
                        setProductFormData({ ...productFormData, imageUrl: e.target.value, imageFile: null });
                        setProductPreview(e.target.value || null);
                      }}
                      placeholder="이미지 URL을 입력하세요"
                    />
                  </div>
                  <div className="form-actions">
                    <button type="submit" className="btn-primary" disabled={loading}>
                      {productFormMode === 'create' ? '등록' : '수정'}
                    </button>
                    <button
                      type="button"
                      className="btn-secondary"
                      onClick={() => setShowProductForm(false)}
                    >
                      취소
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}
        </div>
      )}

      {/* 카테고리 관리 */}
      {activeTab === 'category' && !loading && (
        <div className="category-content">
          <button
            onClick={() => {
              setCategoryForm({ id: null, categoryName: '', parentId: null, depth: 1 });
              setCategoryFormMode('create');
              setShowCategoryForm(true);
            }}
            className="btn-create"
          >
            카테고리 등록
          </button>
          {categories.length === 0 ? (
            <div className="empty-message">등록된 카테고리가 없습니다.</div>
          ) : (
            <table className="data-table">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>카테고리명</th>
                  <th>부모 ID</th>
                  <th>깊이</th>
                  <th>작업</th>
                </tr>
              </thead>
              <tbody>
                {buildCategoryTree(categories).map((category) => renderCategoryNode(category))}
              </tbody>
            </table>
          )}
          {showCategoryForm && (
            <div className="modal-overlay" onClick={() => setShowCategoryForm(false)}>
              <div className="modal-content" onClick={(e) => e.stopPropagation()}>
                <h2>{categoryFormMode === 'create' ? '카테고리 등록' : '카테고리 수정'}</h2>
                <form onSubmit={handleSubmitCategory}>
                  <div className="form-group">
                    <label>카테고리명:</label>
                    <input
                      type="text"
                      value={categoryForm.categoryName}
                      onChange={(e) =>
                        setCategoryForm({ ...categoryForm, categoryName: e.target.value })
                      }
                      required
                    />
                  </div>
                  <div className="form-group">
                    <label>부모 ID:</label>
                    <input
                      type="number"
                      value={categoryForm.parentId || ''}
                      onChange={(e) =>
                        setCategoryForm({
                          ...categoryForm,
                          parentId: e.target.value ? Number(e.target.value) : null,
                        })
                      }
                    />
                  </div>
                  <div className="form-group">
                    <label>깊이:</label>
                    <input
                      type="number"
                      value={categoryForm.depth}
                      onChange={(e) =>
                        setCategoryForm({ ...categoryForm, depth: Number(e.target.value) })
                      }
                      min="1"
                      required
                    />
                  </div>
                  <div className="form-actions">
                    <button type="submit">{categoryFormMode === 'create' ? '등록' : '수정'}</button>
                    <button type="button" onClick={() => setShowCategoryForm(false)}>
                      취소
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}
        </div>
      )}

      {/* FAQ 관리 */}
      {activeTab === 'faq' && <AdminFaqPage />}
    </div>
  );
}

export default AdminPage;
