import { useState, useEffect } from 'react';
import { getRecentProductList, deleteRecentProduct } from '../api/productApi';
import { 
  getRecentProductsFromStorage, 
  deleteRecentProductFromStorage 
} from '../utils/recentProductStorage';
import './RecentProductPage.css';

function RecentProductPage({ user, onBack, onNavigateToPage }) {
  const [recentProductList, setRecentProductList] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const fetchRecentProductList = async () => {
    setLoading(true);
    setError(null);
    try {
      let allProducts = [];
      
      // 로컬스토리지에서 가져오기
      const localProducts = getRecentProductsFromStorage();
      allProducts = [...localProducts];
      
      // 로그인 상태일 경우 DB에서도 가져오기
      if (user?.id) {
        try {
          const dbProducts = await getRecentProductList(user.id);
          // DB 상품과 로컬스토리지 상품 합치기 (중복 제거)
          const localProductIds = new Set(localProducts.map(p => p.productId));
          const uniqueDbProducts = dbProducts.filter(p => !localProductIds.has(p.productId));
          allProducts = [...localProducts, ...uniqueDbProducts];
        } catch (err) {
          console.error('DB 최근 본 상품 조회 실패:', err);
          // DB 조회 실패해도 로컬스토리지 데이터는 표시
        }
      }
      
      setRecentProductList(allProducts);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchRecentProductList();
  }, [user]);

  const handleProductClick = (productId) => {
    // 상품 상세보기로 이동
    if (onNavigateToPage) {
      onNavigateToPage('product', productId);
    } else if (onBack) {
      // onNavigateToPage가 없으면 상품 목록으로 돌아가기
      onBack();
    }
  };

  const handleDeleteRecentProduct = async (e, productId) => {
    e.stopPropagation(); // 상품 클릭 이벤트 방지
    if (!confirm('최근 본 상품에서 제거하시겠습니까?')) return;

    try {
      // 로컬스토리지에서 삭제
      deleteRecentProductFromStorage(productId);
      
      // 로그인 상태일 경우 DB에서도 삭제
      if (user?.id) {
        try {
          await deleteRecentProduct(user.id, productId);
        } catch (err) {
          console.error('DB 최근 본 상품 삭제 실패:', err);
          // DB 삭제 실패해도 로컬스토리지 삭제는 반영
        }
      }
      
      alert('최근 본 상품에서 제거되었습니다.');
      fetchRecentProductList();
    } catch (err) {
      alert('삭제 실패: ' + err.message);
    }
  };

  return (
    <div className="recent-product-page">
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
        <h1>최근 본 상품</h1>
        {onBack && (
          <button onClick={onBack} style={{ padding: '8px 16px' }}>
            상품 목록으로
          </button>
        )}
      </div>

      <div className="user-section">
        {user ? (
          <span>사용자: {user.name} (ID: {user.id})</span>
        ) : (
          <span>비로그인 상태 (로컬스토리지 데이터만 표시)</span>
        )}
        <button onClick={fetchRecentProductList} style={{ marginLeft: '10px' }}>
          새로고침
        </button>
      </div>

      {error && <div className="error-message">{error}</div>}

      {loading ? (
        <div>로딩 중...</div>
      ) : (
        <>
          {recentProductList.length === 0 ? (
            <div className="empty-recent">최근 본 상품이 없습니다.</div>
          ) : (
            <div className="recent-product-grid">
              {recentProductList.map((product) => (
                <div 
                  key={product.productId} 
                  className="recent-product-item"
                  onClick={() => handleProductClick(product.productId)}
                  style={{ cursor: 'pointer' }}
                >
                  {product.imageUrl && (
                    <img 
                      src={product.imageUrl.startsWith('http') ? product.imageUrl : `http://localhost:8080${product.imageUrl}`}
                      alt={product.productName}
                      onError={(e) => {
                        e.target.style.display = 'none';
                      }}
                    />
                  )}
                  <h3>{product.productName}</h3>
                  <p className="price">{product.price?.toLocaleString()}원</p>
                  {product.category && (
                    <p className="category">{product.category.categoryName}</p>
                  )}
                  <button
                    onClick={(e) => handleDeleteRecentProduct(e, product.productId)}
                    className="delete-btn"
                  >
                    삭제
                  </button>
                </div>
              ))}
            </div>
          )}
        </>
      )}
    </div>
  );
}

export default RecentProductPage;
