import { useState, useEffect } from 'react';
import { getReviewsByUserId, getReview } from '../api/reviewApi';
import './ReviewPage.css';

// 이미지 URL 보정 함수 (상대경로면 백엔드 도메인 붙이기)
const resolveImageUrl = (url) => {
  if (!url) return '';
  return url.startsWith('http') ? url : `http://localhost:8080${url}`;
};

function ReviewPage({ user }) {
  const [reviews, setReviews] = useState([]);
  const [selectedReview, setSelectedReview] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  
  // 리뷰 작성 폼
  const [showReviewForm, setShowReviewForm] = useState(false);
  const [reviewForm, setReviewForm] = useState({
    userId: 1,
    productId: 1,
    content: '',
    rating: 5,
    images: null,
  });

  const fetchReviews = async () => {
    if (!user || !user.id) {
      setError('로그인이 필요합니다.');
      return;
    }
    setLoading(true);
    setError(null);
    try {
      console.log('사용자별 리뷰 조회 시작 - userId:', user.id);
      const data = await getReviewsByUserId(user.id);
      console.log('리뷰 조회 결과:', data);
      setReviews(data || []);
      if (!data || data.length === 0) {
        console.log('작성한 리뷰가 없습니다.');
      }
    } catch (err) {
      console.error('리뷰 조회 실패:', err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchReviews();
  }, [user?.id]);

  const handleViewReview = async (reviewId) => {
    try {
      const review = await getReview(reviewId);
      setSelectedReview(review);
    } catch (err) {
      setError(err.message);
    }
  };


  if (!user) {
    return (
      <div className="review-page">
        <h1>내 리뷰</h1>
        <div className="empty-message">로그인이 필요합니다.</div>
      </div>
    );
  }

  return (
    <div className="review-page">
      <h1>내 리뷰</h1>
      {error && <div className="error-message">{error}</div>}
      
      {loading ? (
        <div>로딩 중...</div>
      ) : (
        <div>
          <h2>작성한 리뷰 목록</h2>
          {reviews.length === 0 ? (
            <div className="empty-message">작성한 리뷰가 없습니다.</div>
          ) : (
            <div className="review-list">
              {reviews.map((review) => (
                <div key={review.reviewId} className="review-item">
                  <div className="review-header">
                    <span className="review-user">상품 ID: {review.productId}</span>
                    <span className="review-rating">평점: {review.rating}⭐</span>
                    {review.createdAt && <span className="review-date">{review.createdAt}</span>}
                  </div>
                  <div className="review-content">{review.content}</div>
                  {review.reviewImages && review.reviewImages.length > 0 && (
                    <div className="review-images">
                      {review.reviewImages.map((img, idx) => (
                        <img key={idx} src={resolveImageUrl(img.imageUrl)} alt={`리뷰 이미지 ${idx + 1}`} />
                      ))}
                    </div>
                  )}
                  <button className="btn-link" onClick={() => handleViewReview(review.reviewId)}>
                    상세보기
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {selectedReview && (
        <div className="modal">
          <div className="modal-content">
            <span className="close" onClick={() => setSelectedReview(null)}>&times;</span>
            <h2>리뷰 상세</h2>
            <div className="review-detail">
              <p><strong>리뷰 ID:</strong> {selectedReview.reviewId}</p>
              <p><strong>작성자:</strong> {selectedReview.loginId || '익명'}</p>
              <p><strong>평점:</strong> {selectedReview.rating}</p>
              <p><strong>내용:</strong> {selectedReview.content}</p>
              {selectedReview.createdAt && <p><strong>작성일:</strong> {selectedReview.createdAt}</p>}
              {selectedReview.reviewImages && selectedReview.reviewImages.length > 0 && (
                <div>
                  <strong>이미지:</strong>
                  <div className="review-images">
                    {selectedReview.reviewImages.map((img, idx) => (
                      <img key={idx} src={resolveImageUrl(img.imageUrl)} alt={`리뷰 이미지 ${idx + 1}`} />
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default ReviewPage;




