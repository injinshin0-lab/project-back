import { useState, useEffect } from 'react';
import { getOrderList } from '../api/productApi';
import { canWriteReview, insertReview } from '../api/reviewApi';
import './OrderPage.css';

function OrderPage({ user }) {
  const [orderList, setOrderList] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [userId, setUserId] = useState(user?.id || null);
  const [page, setPage] = useState(1);
  const [totalPage, setTotalPage] = useState(1);
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [reviewForm, setReviewForm] = useState({
    productId: null,
    productName: '',
    content: '',
    rating: 5,
    images: null,
  });
  const [showReviewForm, setShowReviewForm] = useState(false);
  const [canWriteMap, setCanWriteMap] = useState({});

  const fetchOrderList = async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await getOrderList({
        userId,
        startDate,
        endDate,
        page,
        size: 10,
      });
      setOrderList(response.list || []);
      setTotalPage(response.totalPage || 1);
      
      // 각 주문 항목에 대해 리뷰 작성 가능 여부 확인
      if (userId && response.list) {
        console.log('주문 목록:', response.list);
        const canWritePromises = [];
        const productIds = new Set();
        
        response.list.forEach(order => {
          if (order.orderItems && order.status === 'DELIVERED') {
            order.orderItems.forEach(item => {
              if (item.productId && !productIds.has(item.productId)) {
                productIds.add(item.productId);
                canWritePromises.push(
                  canWriteReview(userId, item.productId)
                    .then(canWrite => ({ productId: item.productId, canWrite }))
                    .catch(() => ({ productId: item.productId, canWrite: false }))
                );
              }
            });
          }
        });
        
        const results = await Promise.all(canWritePromises);
        const newCanWriteMap = {};
        results.forEach(({ productId, canWrite }) => {
          newCanWriteMap[productId] = canWrite;
        });
        setCanWriteMap(newCanWriteMap);
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (userId) {
      fetchOrderList();
    }
  }, [userId, page, startDate, endDate]);

  useEffect(() => {
    if (user?.id) {
      setUserId(user.id);
    }
  }, [user]);

  const handleOpenReviewForm = async (item) => {
    if (userId && item.productId) {
      try {
        const canWrite = await canWriteReview(userId, item.productId);
        if (!canWrite) {
          alert('리뷰를 작성할 수 없습니다. 배송완료한 상품에만 리뷰를 작성할 수 있으며, 이미 해당 상품에 대한 리뷰를 작성하셨습니다.');
          return;
        }
      } catch (err) {
        console.error('리뷰 작성 가능 여부 확인 실패:', err);
        alert('리뷰 작성 가능 여부를 확인하는데 실패했습니다.');
        return;
      }
    }
    
    setReviewForm({
      productId: item.productId,
      productName: item.productName,
      content: '',
      rating: 5,
      images: null,
    });
    setShowReviewForm(true);
  };

  const handleCloseReviewForm = () => {
    setShowReviewForm(false);
    setReviewForm({
      productId: null,
      productName: '',
      content: '',
      rating: 5,
      images: null,
    });
  };

  const handleSubmitReview = async (e) => {
    e.preventDefault();
    if (!user || !reviewForm.productId) return;
    
    try {
      const formData = new FormData();
      formData.append('userId', user.id);
      formData.append('productId', reviewForm.productId);
      formData.append('content', reviewForm.content);
      formData.append('rating', reviewForm.rating);
      if (reviewForm.images) {
        Array.from(reviewForm.images).forEach((file) => {
          formData.append('images', file);
        });
      }

      await insertReview(formData);
      alert('리뷰가 등록되었습니다.');
      handleCloseReviewForm();
      // 리뷰 작성 가능 여부 업데이트
      if (reviewForm.productId) {
        setCanWriteMap(prev => ({
          ...prev,
          [reviewForm.productId]: false
        }));
      }
      // 주문 목록 다시 불러오기
      await fetchOrderList();
    } catch (err) {
      alert('리뷰 작성에 실패했습니다: ' + err.message);
    }
  };

  if (!user) {
    return (
      <div className="order-page">
        <h1>주문 내역</h1>
        <p>로그인이 필요합니다.</p>
      </div>
    );
  }

  return (
    <div className="order-page">
      <h1>주문 내역</h1>

      <div className="user-section">
        <label>시작일: </label>
        <input
          type="date"
          value={startDate}
          onChange={(e) => setStartDate(e.target.value)}
          style={{ marginRight: '10px' }}
        />
        <label>종료일: </label>
        <input
          type="date"
          value={endDate}
          onChange={(e) => setEndDate(e.target.value)}
          style={{ marginRight: '10px' }}
        />
        <button onClick={fetchOrderList}>조회</button>
        <button
          onClick={() => {
            setStartDate('');
            setEndDate('');
            fetchOrderList();
          }}
          style={{ marginLeft: '10px' }}
        >
          초기화
        </button>
      </div>

      {error && <div className="error-message">{error}</div>}

      {loading ? (
        <div>로딩 중...</div>
      ) : (
        <>
          {orderList.length === 0 ? (
            <div className="empty-order">주문 내역이 없습니다.</div>
          ) : (
            <div className="order-list">
              {orderList.map((order) => (
                <div key={order.id} className="order-item">
                  <div className="order-header">
                    <h3>주문 #{order.id}</h3>
                    <span className={`status status-${order.status?.toLowerCase()}`}>
                      {order.status}
                    </span>
                  </div>
                  <div className="order-info">
                    <p><strong>결제 방법:</strong> {order.payType}</p>
                    <p><strong>총 금액:</strong> {order.totalPrice?.toLocaleString()}원</p>
                    <p><strong>주소:</strong> {order.postcode} {order.address} {order.detailAddress}</p>
                    <p><strong>주문일:</strong> {order.createdAt}</p>
                    {order.orderItems && order.orderItems.length > 0 && (
                      <div className="order-items">
                        <h4>주문 상품:</h4>
                        <ul style={{ listStyle: 'none', padding: 0 }}>
                          {order.orderItems.map((item, idx) => (
                            <li key={idx} style={{
                              padding: '10px',
                              marginBottom: '10px',
                              border: '1px solid #e0e0e0',
                              borderRadius: '4px',
                              display: 'flex',
                              justifyContent: 'space-between',
                              alignItems: 'center'
                            }}>
                              <div style={{ flex: 1 }}>
                                <strong>{item.productName}</strong> - {item.quantity}개 - {item.price?.toLocaleString()}원
                              </div>
                              <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                                {order.status === 'DELIVERED' && canWriteMap[item.productId] === true && (
                                  <button
                                    onClick={() => handleOpenReviewForm(item)}
                                    style={{
                                      padding: '10px 20px',
                                      backgroundColor: '#28a745',
                                      color: 'white',
                                      border: 'none',
                                      borderRadius: '4px',
                                      cursor: 'pointer',
                                      fontSize: '14px',
                                      fontWeight: 'bold',
                                      transition: 'background-color 0.3s',
                                      whiteSpace: 'nowrap'
                                    }}
                                    onMouseOver={(e) => e.target.style.backgroundColor = '#218838'}
                                    onMouseOut={(e) => e.target.style.backgroundColor = '#28a745'}
                                  >
                                    ✍️ 리뷰 작성
                                  </button>
                                )}
                                {order.status === 'DELIVERED' && canWriteMap[item.productId] === false && (
                                  <span style={{
                                    padding: '10px 20px',
                                    color: '#28a745',
                                    fontSize: '14px',
                                    fontWeight: 'bold',
                                    backgroundColor: '#d4edda',
                                    borderRadius: '4px',
                                    whiteSpace: 'nowrap'
                                  }}>
                                    ✓ 리뷰 작성 완료
                                  </span>
                                )}
                                {order.status !== 'DELIVERED' && (
                                  <span style={{
                                    padding: '10px 20px',
                                    color: '#999',
                                    fontSize: '14px',
                                    backgroundColor: '#f8f9fa',
                                    borderRadius: '4px',
                                    whiteSpace: 'nowrap'
                                  }}>
                                    ⏳ 배송 대기 중
                                  </span>
                                )}
                              </div>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}

          <div className="pagination">
            <button disabled={page === 1} onClick={() => setPage(page - 1)}>이전</button>
            <span>{page} / {totalPage}</span>
            <button disabled={page >= totalPage} onClick={() => setPage(page + 1)}>다음</button>
          </div>
        </>
      )}

      {showReviewForm && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          backgroundColor: 'rgba(0, 0, 0, 0.5)',
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          zIndex: 1000
        }}>
          <div style={{
            backgroundColor: 'white',
            padding: '30px',
            borderRadius: '8px',
            maxWidth: '500px',
            width: '90%',
            maxHeight: '90vh',
            overflow: 'auto'
          }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '20px' }}>
              <h2>리뷰 작성</h2>
              <button
                onClick={handleCloseReviewForm}
                style={{
                  background: 'none',
                  border: 'none',
                  fontSize: '24px',
                  cursor: 'pointer',
                  color: '#666'
                }}
              >
                ×
              </button>
            </div>
            <p style={{ marginBottom: '20px', color: '#666' }}>
              <strong>상품:</strong> {reviewForm.productName}
            </p>
            <form onSubmit={handleSubmitReview}>
              <div style={{ marginBottom: '15px' }}>
                <label style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>평점:</label>
                <input
                  type="number"
                  min="1"
                  max="5"
                  step="0.5"
                  value={reviewForm.rating}
                  onChange={(e) => setReviewForm({ ...reviewForm, rating: parseFloat(e.target.value) || 5 })}
                  style={{ width: '100px', padding: '5px' }}
                  required
                />
              </div>
              <div style={{ marginBottom: '15px' }}>
                <label style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>내용:</label>
                <textarea
                  value={reviewForm.content}
                  onChange={(e) => setReviewForm({ ...reviewForm, content: e.target.value })}
                  rows="5"
                  style={{ width: '100%', padding: '10px', border: '1px solid #ddd', borderRadius: '4px' }}
                  required
                />
              </div>
              <div style={{ marginBottom: '15px' }}>
                <label style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>이미지:</label>
                <input
                  type="file"
                  multiple
                  accept="image/*"
                  onChange={(e) => setReviewForm({ ...reviewForm, images: e.target.files })}
                />
              </div>
              <div style={{ display: 'flex', gap: '10px' }}>
                <button
                  type="submit"
                  style={{
                    padding: '10px 20px',
                    backgroundColor: '#28a745',
                    color: 'white',
                    border: 'none',
                    borderRadius: '4px',
                    cursor: 'pointer',
                    fontSize: '16px',
                    flex: 1
                  }}
                >
                  리뷰 등록
                </button>
                <button
                  type="button"
                  onClick={handleCloseReviewForm}
                  style={{
                    padding: '10px 20px',
                    backgroundColor: '#6c757d',
                    color: 'white',
                    border: 'none',
                    borderRadius: '4px',
                    cursor: 'pointer',
                    fontSize: '16px',
                    flex: 1
                  }}
                >
                  취소
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

export default OrderPage;




