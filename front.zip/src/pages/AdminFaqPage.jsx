import { useState, useEffect } from 'react';
import {
  getAdminFaqList,
  getAdminFaq,
  createAdminFaq,
  updateAdminFaq,
  deleteAdminFaq,
} from '../api/adminFaqApi';
import './AdminFaqPage.css';

function AdminFaqPage() {
  const [faqs, setFaqs] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPage, setTotalPage] = useState(1);
  const [pageSize] = useState(10);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  // 검색 상태
  const [searchKeyword, setSearchKeyword] = useState('');

  // FAQ 등록/수정 폼 상태
  const [showForm, setShowForm] = useState(false);
  const [editingFaq, setEditingFaq] = useState(null);
  const [formData, setFormData] = useState({
    title: '',
    content: '',
  });

  // FAQ 목록 로드
  useEffect(() => {
    loadFaqs();
  }, [currentPage]);

  const loadFaqs = async () => {
    setLoading(true);
    setError(null);
    try {
      const params = {
        page: currentPage,
        size: pageSize,
        keyword: searchKeyword || undefined,
      };
      const data = await getAdminFaqList(params);
      setFaqs(data.list || []);
      setTotalPage(data.totalPage || 1);
      setCurrentPage(data.currentPage || 1);
    } catch (err) {
      setError(err.message);
      console.error('FAQ 목록 로드 실패:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = () => {
    setCurrentPage(1);
    loadFaqs();
  };

  const handleReset = () => {
    setSearchKeyword('');
    setCurrentPage(1);
  };

  const handleCreate = () => {
    setEditingFaq(null);
    setFormData({
      title: '',
      content: '',
    });
    setShowForm(true);
  };

  const handleEdit = async (faqId) => {
    try {
      const faq = await getAdminFaq(faqId);
      setEditingFaq(faq);
      setFormData({
        title: faq.title || '',
        content: faq.content || '',
      });
      setShowForm(true);
    } catch (err) {
      setError(err.message);
      console.error('FAQ 상세 로드 실패:', err);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      const faqData = {
        faqId: editingFaq?.faqId || null,
        title: formData.title,
        content: formData.content,
      };

      if (editingFaq) {
        await updateAdminFaq(faqData);
        alert('FAQ가 수정되었습니다.');
      } else {
        await createAdminFaq(faqData);
        alert('FAQ가 등록되었습니다.');
      }

      setShowForm(false);
      loadFaqs();
    } catch (err) {
      setError(err.message);
      console.error('FAQ 저장 실패:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (faqId) => {
    if (!confirm('정말 삭제하시겠습니까?')) {
      return;
    }

    try {
      const result = await deleteAdminFaq(faqId);
      if (result === 1) {
        alert('FAQ가 삭제되었습니다.');
        loadFaqs();
      } else {
        alert('삭제에 실패했습니다.');
      }
    } catch (err) {
      setError(err.message);
      console.error('FAQ 삭제 실패:', err);
    }
  };

  const formatDate = (dateString) => {
    if (!dateString) return '-';
    try {
      return new Date(dateString).toLocaleString('ko-KR', {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit',
      });
    } catch (e) {
      return dateString;
    }
  };

  return (
    <div className="admin-faq-page">
      <div className="admin-faq-header">
        <h1>FAQ 관리</h1>
        <button className="btn-primary" onClick={handleCreate}>
          FAQ 등록
        </button>
      </div>

      {error && <div className="error-message">{error}</div>}

      {/* 검색 영역 */}
      <div className="search-filter-section">
        <div className="search-group">
          <input
            type="text"
            placeholder="제목, 내용 검색"
            value={searchKeyword}
            onChange={(e) => setSearchKeyword(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
            className="search-input"
          />
          <button className="btn-search" onClick={handleSearch}>
            검색
          </button>
          <button className="btn-reset" onClick={handleReset}>
            초기화
          </button>
        </div>
      </div>

      {/* FAQ 목록 */}
      {loading ? (
        <div className="loading">로딩 중...</div>
      ) : (
        <>
          <div className="faq-table-container">
            <table className="faq-table">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>제목</th>
                  <th>내용</th>
                  <th>작성일</th>
                  <th>수정일</th>
                  <th>작업</th>
                </tr>
              </thead>
              <tbody>
                {faqs.length === 0 ? (
                  <tr>
                    <td colSpan="6" className="no-data">
                      등록된 FAQ가 없습니다.
                    </td>
                  </tr>
                ) : (
                  faqs.map((faq) => (
                    <tr key={faq.faqId}>
                      <td>{faq.faqId}</td>
                      <td className="title-cell">{faq.title}</td>
                      <td className="content-cell">
                        {faq.content && faq.content.length > 50
                          ? `${faq.content.substring(0, 50)}...`
                          : faq.content}
                      </td>
                      <td>{formatDate(faq.createdAt)}</td>
                      <td>{formatDate(faq.updatedAt)}</td>
                      <td>
                        <button
                          className="btn-edit"
                          onClick={() => handleEdit(faq.faqId)}
                        >
                          수정
                        </button>
                        <button
                          className="btn-delete"
                          onClick={() => handleDelete(faq.faqId)}
                        >
                          삭제
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>

          {/* 페이지네이션 */}
          {totalPage > 1 && (
            <div className="pagination">
              <button
                onClick={() => setCurrentPage(currentPage - 1)}
                disabled={currentPage === 1}
                className="page-btn"
              >
                이전
              </button>
              <span className="page-info">
                {currentPage} / {totalPage}
              </span>
              <button
                onClick={() => setCurrentPage(currentPage + 1)}
                disabled={currentPage === totalPage}
                className="page-btn"
              >
                다음
              </button>
            </div>
          )}
        </>
      )}

      {/* FAQ 등록/수정 모달 */}
      {showForm && (
        <div className="modal-overlay" onClick={() => setShowForm(false)}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <h2>{editingFaq ? 'FAQ 수정' : 'FAQ 등록'}</h2>
              <button className="close-btn" onClick={() => setShowForm(false)}>
                ×
              </button>
            </div>
            <form onSubmit={handleSubmit}>
              <div className="form-group">
                <label>제목 *</label>
                <input
                  type="text"
                  value={formData.title}
                  onChange={(e) =>
                    setFormData({ ...formData, title: e.target.value })
                  }
                  required
                />
              </div>
              <div className="form-group">
                <label>내용 *</label>
                <textarea
                  value={formData.content}
                  onChange={(e) =>
                    setFormData({ ...formData, content: e.target.value })
                  }
                  rows="10"
                  required
                />
              </div>
              <div className="form-actions">
                <button type="submit" className="btn-primary" disabled={loading}>
                  {editingFaq ? '수정' : '등록'}
                </button>
                <button
                  type="button"
                  className="btn-secondary"
                  onClick={() => setShowForm(false)}
                >
                  취소
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

export default AdminFaqPage;













