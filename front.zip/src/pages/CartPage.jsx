import { useState, useEffect } from 'react';
import { getCartList, removeCartItem, removeCart, createOrder } from '../api/productApi';
import { getAddressList } from '../api/userProfileApi';
import './CartPage.css';

function CartPage({ user }) {
  const [cartList, setCartList] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [userId, setUserId] = useState(user?.id || null);
  const [showOrderForm, setShowOrderForm] = useState(false);
  const [orderFormData, setOrderFormData] = useState({
    payType: 'CARD',
    addressId: null,
  });
  const [addressList, setAddressList] = useState([]);

  const fetchCartList = async () => {
    setLoading(true);
    setError(null);
    try {
      const cartData = await getCartList(userId);
      setCartList(cartData || []);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (user?.id) {
      setUserId(user.id);
    }
  }, [user]);

  useEffect(() => {
    if (userId) {
      fetchCartList();
      fetchAddressList();
    }
  }, [userId]);

  useEffect(() => {
    if (showOrderForm && user?.id) {
      fetchAddressList();
    }
  }, [showOrderForm, user]);

  const fetchAddressList = async () => {
    if (!user?.id) return;
    try {
      const addresses = await getAddressList(user.id);
      setAddressList(addresses || []);
      if (addresses && addresses.length > 0) {
        const defaultAddress = addresses.find(addr => addr.isDefault) || addresses[0];
        setOrderFormData(prev => ({ ...prev, addressId: defaultAddress.addressId }));
      }
    } catch (err) {
      console.error('주소 목록 조회 실패:', err);
    }
  };

  const handleRemoveCartItem = async (productId) => {
    if (!confirm('장바구니에서 제거하시겠습니까?')) return;

    try {
      await removeCartItem({ userId, productId });
      alert('장바구니에서 제거되었습니다.');
      fetchCartList();
    } catch (err) {
      alert('장바구니 제거 실패: ' + err.message);
    }
  };

  const handleRemoveCart = async () => {
    if (!confirm('장바구니를 모두 비우시겠습니까?')) return;

    try {
      await removeCart({ userId });
      alert('장바구니가 비워졌습니다.');
      fetchCartList();
    } catch (err) {
      alert('장바구니 비우기 실패: ' + err.message);
    }
  };

  const handleOrder = async () => {
    if (!user) {
      alert('로그인이 필요합니다.');
      return;
    }

    if (cartList.length === 0) {
      alert('장바구니가 비어있습니다.');
      return;
    }

    if (!orderFormData.addressId) {
      alert('배송 주소를 선택해주세요.');
      return;
    }

    if (!confirm('주문하시겠습니까?')) return;

    try {
      const totalPrice = cartList.reduce((sum, item) => sum + (item.price * item.quantity), 0);
      await createOrder({
        userId: user.id,
        payType: orderFormData.payType,
        addressId: orderFormData.addressId,
        totalPrice: totalPrice,
        cartItems: cartList.map(item => ({
          productId: item.productId,
          productName: item.productName,
          price: item.price,
          quantity: item.quantity,
          imageUrl: item.imageUrl
        }))
      });
      alert('주문이 완료되었습니다.');
      setShowOrderForm(false);
      fetchCartList();
    } catch (err) {
      console.error('주문 실패:', err);
      alert('주문에 실패했습니다: ' + err.message);
    }
  };

  const totalPrice = cartList.reduce((sum, item) => sum + (item.price * item.quantity), 0);

  if (!user) {
    return (
      <div className="cart-page">
        <h1>장바구니</h1>
        <p>로그인이 필요합니다.</p>
      </div>
    );
  }

  return (
    <div className="cart-page">
      <h1>장바구니</h1>

      {error && <div className="error-message">{error}</div>}

      <div className="cart-actions">
        {cartList.length > 0 && (
          <>
            <button onClick={handleRemoveCart} className="remove-all">
              전체 삭제
            </button>
            <button
              onClick={() => setShowOrderForm(true)}
              className="order-button"
              style={{ marginLeft: '10px', padding: '10px 20px', fontSize: '16px', backgroundColor: '#007bff', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer' }}
            >
              주문하기
            </button>
          </>
        )}
      </div>

      {loading ? (
        <div>로딩 중...</div>
      ) : (
        <>
          {cartList.length === 0 ? (
            <div className="empty-cart">장바구니가 비어있습니다.</div>
          ) : (
            <div className="cart-list">
              <table>
                <thead>
                  <tr>
                    <th>상품명</th>
                    <th>가격</th>
                    <th>수량</th>
                    <th>합계</th>
                    <th>작업</th>
                  </tr>
                </thead>
                <tbody>
                  {cartList.map((item) => (
                    <tr key={`${item.userId}-${item.productId}`}>
                      <td>
                        {item.imageUrl && (
                          <img src={item.imageUrl} alt={item.productName} className="cart-image" />
                        )}
                        {item.productName}
                      </td>
                      <td>{item.price?.toLocaleString()}원</td>
                      <td>{item.quantity}</td>
                      <td>{(item.price * item.quantity)?.toLocaleString()}원</td>
                      <td>
                        <button onClick={() => handleRemoveCartItem(item.productId)}>삭제</button>
                      </td>
                    </tr>
                  ))}
                </tbody>
                <tfoot>
                  <tr>
                    <td colSpan="3"><strong>총합</strong></td>
                    <td><strong>{totalPrice.toLocaleString()}원</strong></td>
                    <td></td>
                  </tr>
                </tfoot>
              </table>
            </div>
          )}

          {showOrderForm && (
            <div className="order-form" style={{ marginTop: '30px', padding: '20px', border: '1px solid #ddd', borderRadius: '8px', backgroundColor: '#f9f9f9' }}>
              <h3>주문하기</h3>
              <div className="order-summary" style={{ marginBottom: '20px' }}>
                <h4>주문 상품</h4>
                <ul style={{ listStyle: 'none', padding: 0 }}>
                  {cartList.map((item) => (
                    <li key={`${item.userId}-${item.productId}`} style={{ padding: '5px 0', borderBottom: '1px solid #eee' }}>
                      {item.productName} - {item.quantity}개 - {(item.price * item.quantity).toLocaleString()}원
                    </li>
                  ))}
                </ul>
                <p style={{ marginTop: '10px', fontSize: '18px', fontWeight: 'bold' }}>
                  총 금액: {totalPrice.toLocaleString()}원
                </p>
              </div>
              <div className="form-group" style={{ marginBottom: '15px' }}>
                <label style={{ display: 'block', marginBottom: '5px' }}>결제 방법: </label>
                <select
                  value={orderFormData.payType}
                  onChange={(e) => setOrderFormData({ ...orderFormData, payType: e.target.value })}
                  style={{ padding: '5px', width: '200px' }}
                >
                  <option value="CARD">카드</option>
                  <option value="BANK">계좌이체</option>
                  <option value="CASH">현금</option>
                </select>
              </div>
              <div className="form-group" style={{ marginBottom: '15px' }}>
                <label style={{ display: 'block', marginBottom: '5px' }}>배송 주소: </label>
                {addressList.length === 0 ? (
                  <p style={{ color: '#d32f2f' }}>등록된 주소가 없습니다. 회원정보에서 주소를 등록해주세요.</p>
                ) : (
                  <select
                    value={orderFormData.addressId || ''}
                    onChange={(e) => setOrderFormData({ ...orderFormData, addressId: parseInt(e.target.value) })}
                    style={{ padding: '5px', width: '100%', maxWidth: '500px' }}
                  >
                    <option value="">주소를 선택하세요</option>
                    {addressList.map((address) => (
                      <option key={address.addressId} value={address.addressId}>
                        {address.isDefault && '[기본] '}
                        [{address.postcode}] {address.address} {address.detailAddress}
                        {address.recipient && ` (${address.recipient})`}
                      </option>
                    ))}
                  </select>
                )}
              </div>
              <div style={{ marginTop: '20px' }}>
                <button
                  onClick={handleOrder}
                  disabled={!orderFormData.addressId || addressList.length === 0}
                  style={{ padding: '10px 20px', fontSize: '16px', backgroundColor: '#28a745', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer', marginRight: '10px' }}
                >
                  주문하기
                </button>
                <button
                  onClick={() => setShowOrderForm(false)}
                  style={{ padding: '10px 20px', fontSize: '16px', backgroundColor: '#6c757d', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer' }}
                >
                  취소
                </button>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}

export default CartPage;




