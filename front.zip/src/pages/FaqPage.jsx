import { useState, useEffect } from 'react';
import { getFaqList, getFaq, createFaq, updateFaq, deleteFaq } from '../api/faqApi';
import './FaqPage.css';

function FaqPage() {
  const [faqList, setFaqList] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [keyword, setKeyword] = useState('');
  const [page, setPage] = useState(1);
  const [totalPage, setTotalPage] = useState(1);

  const fetchFaqList = async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await getFaqList({ keyword, page, size: 10 });
      setFaqList(response.list || []);
      setTotalPage(response.totalPage || 1);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchFaqList();
  }, [page]);

  useEffect(() => {
    if (keyword === '') {
      fetchFaqList();
    }
  }, [keyword]);

  return (
    <div className="faq-page">
      <h1>FAQ 관리</h1>
      {error && <div className="error-message">{error}</div>}
      {loading ? (
        <div>로딩 중...</div>
      ) : (
        <div>
          <div className="search-section">
            <input
              type="text"
              value={keyword}
              onChange={(e) => setKeyword(e.target.value)}
              placeholder="검색어"
              onKeyPress={(e) => e.key === 'Enter' && fetchFaqList()}
            />
            <button onClick={fetchFaqList}>검색</button>
          </div>
          {faqList.length === 0 ? (
            <div className="empty-faq">등록된 FAQ가 없습니다.</div>
          ) : (
            <div className="faq-list">
              {faqList.map((faq) => (
                <div key={faq.faqId} className="faq-item">
                  <h3>{faq.title}</h3>
                  <p>{faq.content}</p>
                  {faq.createdAt && <p className="faq-date">{faq.createdAt}</p>}
                </div>
              ))}
            </div>
          )}
          <div className="pagination">
            <button disabled={page === 1} onClick={() => setPage(page - 1)}>이전</button>
            <span>{page} / {totalPage}</span>
            <button disabled={page >= totalPage} onClick={() => setPage(page + 1)}>다음</button>
          </div>
        </div>
      )}
    </div>
  );
}

export default FaqPage;





