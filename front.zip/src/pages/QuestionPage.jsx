import { useState, useEffect } from 'react';
import { getQuestionList, getQuestion, insertQuestion } from '../api/questionApi';
import './QuestionPage.css';

// 이미지 URL 보정 함수 (상대경로면 백엔드 도메인 붙이기)
const resolveImageUrl = (url) => {
  if (!url) return '';
  return url.startsWith('http') ? url : `http://localhost:8080${url}`;
};

function QuestionPage({ user }) {
  const [userId, setUserId] = useState(user?.id || null);
  const [questions, setQuestions] = useState([]);
  const [selectedQuestion, setSelectedQuestion] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  
  // 문의 작성 폼
  const [showQuestionForm, setShowQuestionForm] = useState(false);
  const [questionForm, setQuestionForm] = useState({
    userId: user?.id || null,
    productId: 1,
    title: '',
    content: '',
    type: 'PRODUCT',
    images: null,
  });

  const fetchQuestions = async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await getQuestionList(userId);
      setQuestions(data || []);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (user?.id) {
      setUserId(user.id);
      setQuestionForm(prev => ({ ...prev, userId: user.id }));
    }
  }, [user]);

  useEffect(() => {
    if (userId) {
      fetchQuestions();
    }
  }, [userId]);

  const handleViewQuestion = async (questionId) => {
    try {
      const question = await getQuestion(questionId);
      setSelectedQuestion(question);
    } catch (err) {
      setError(err.message);
    }
  };

  const handleSubmitQuestion = async (e) => {
    e.preventDefault();
    setError(null);
    try {
      const formData = new FormData();
      formData.append('userId', questionForm.userId);
      formData.append('productId', questionForm.productId);
      formData.append('title', questionForm.title);
      formData.append('content', questionForm.content);
      formData.append('type', questionForm.type);
      if (questionForm.images) {
        Array.from(questionForm.images).forEach((file) => {
          formData.append('images', file);
        });
      }

      await insertQuestion(formData);
      alert('문의가 등록되었습니다.');
      setShowQuestionForm(false);
      setQuestionForm({ userId: user?.id || null, productId: 1, title: '', content: '', type: 'PRODUCT', images: null });
      fetchQuestions();
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <div className="question-page">
      <h1>문의 관리</h1>
      {error && <div className="error-message">{error}</div>}
      
      <div className="control-section">
        <button className="btn-primary" onClick={() => setShowQuestionForm(!showQuestionForm)}>
          {showQuestionForm ? '닫기' : '문의 작성'}
        </button>
      </div>

      {showQuestionForm && (
        <div className="question-form">
          <h2>문의 작성</h2>
          <form onSubmit={handleSubmitQuestion}>
            <div className="form-group">
              <label>상품 ID:</label>
              <input
                type="number"
                value={questionForm.productId}
                onChange={(e) => setQuestionForm({ ...questionForm, productId: parseInt(e.target.value) || 1 })}
                min="1"
              />
            </div>
            <div className="form-group">
              <label>문의 유형:</label>
              <select
                value={questionForm.type}
                onChange={(e) => setQuestionForm({ ...questionForm, type: e.target.value })}
              >
                <option value="PRODUCT">상품 문의</option>
                <option value="ORDER">주문 문의</option>
                <option value="DELIVERY">배송 문의</option>
                <option value="ETC">기타</option>
              </select>
            </div>
            <div className="form-group">
              <label>제목:</label>
              <input
                type="text"
                value={questionForm.title}
                onChange={(e) => setQuestionForm({ ...questionForm, title: e.target.value })}
                required
              />
            </div>
            <div className="form-group">
              <label>내용:</label>
              <textarea
                value={questionForm.content}
                onChange={(e) => setQuestionForm({ ...questionForm, content: e.target.value })}
                rows="5"
                required
              />
            </div>
            <div className="form-group">
              <label>이미지:</label>
              <input
                type="file"
                multiple
                onChange={(e) => setQuestionForm({ ...questionForm, images: e.target.files })}
                accept="image/*"
              />
            </div>
            <button type="submit" className="btn-primary">등록</button>
          </form>
        </div>
      )}

      {loading ? (
        <div>로딩 중...</div>
      ) : (
        <div>
          <h2>문의 목록</h2>
          {questions.length === 0 ? (
            <div className="empty-message">등록된 문의가 없습니다.</div>
          ) : (
            <div className="question-list">
              {questions.map((question) => (
                <div key={question.questionId} className="question-item">
                  <div className="question-header">
                    <span className="question-title">{question.title}</span>
                    <span className={`question-status status-${question.questionStatus?.toLowerCase()}`}>
                      {question.questionStatus || 'PENDING'}
                    </span>
                  </div>
                  <div className="question-info">
                    <span className="question-type">{question.type}</span>
                    {question.createdAt && <span className="question-date">{question.createdAt}</span>}
                  </div>
                  <div className="question-content">{question.content}</div>
                  {question.questionImages && question.questionImages.length > 0 && (
                    <div className="question-images">
                      {question.questionImages.map((img, idx) => (
                        <img key={idx} src={resolveImageUrl(img.imageUrl)} alt={`문의 이미지 ${idx + 1}`} />
                      ))}
                    </div>
                  )}
                  <button className="btn-link" onClick={() => handleViewQuestion(question.questionId)}>
                    상세보기
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {selectedQuestion && (
        <div className="modal">
          <div className="modal-content">
            <span className="close" onClick={() => setSelectedQuestion(null)}>&times;</span>
            <h2>문의 상세</h2>
            <div className="question-detail">
              <p><strong>문의 ID:</strong> {selectedQuestion.questionId}</p>
              <p><strong>사용자 ID:</strong> {selectedQuestion.userId}</p>
              <p><strong>상품 ID:</strong> {selectedQuestion.productId}</p>
              <p><strong>제목:</strong> {selectedQuestion.title}</p>
              <p><strong>내용:</strong> {selectedQuestion.content}</p>
              <p><strong>유형:</strong> {selectedQuestion.type}</p>
              <p><strong>상태:</strong> {selectedQuestion.questionStatus || 'PENDING'}</p>
              {selectedQuestion.createdAt && <p><strong>작성일:</strong> {selectedQuestion.createdAt}</p>}
              {selectedQuestion.questionImages && selectedQuestion.questionImages.length > 0 && (
                <div>
                  <strong>이미지:</strong>
                  <div className="question-images">
                    {selectedQuestion.questionImages.map((img, idx) => (
                      <img key={idx} src={resolveImageUrl(img.imageUrl)} alt={`문의 이미지 ${idx + 1}`} />
                    ))}
                  </div>
                </div>
              )}
              {selectedQuestion.answer && selectedQuestion.answer.content && (
                <div className="answer-section">
                  <strong>답변:</strong>
                  <div className="answer-content">{selectedQuestion.answer.content}</div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default QuestionPage;

